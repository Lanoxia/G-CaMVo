#!/usr/bin/env python3
"""Run the frozen Mordor Atomic-112 tactic protocol without provider calls."""

from __future__ import annotations

import csv
import json
import math
from collections import Counter, defaultdict
from pathlib import Path
from statistics import mean
from typing import Any

import matplotlib.pyplot as plt
import numpy as np

from camvo.config import CaMVoConfig
from camvo.router import CaMVoRouter
from camvo.types import AnnotationItem, ModelPricing, ModelResponse
from run_large232_validation_camvo import CachedEmbedder, PreCallCostClient


ROOT = Path(__file__).resolve().parents[2]
MODOR = ROOT / "repo/modor"
PROTOCOL = MODOR / "protocols/mordor_atomic171_expansion_protocol_v1"
DATA = MODOR / "data/mordor_large232_one_view_v1"
RUN = MODOR / "runs/mordor_large232_full_corpus_matrix_20260805/blind_atomic_test"
TAXONOMY = MODOR / "data/attack_taxonomy/enterprise-attack-8.2.json"
PRICES = MODOR / "price_snapshot_20260805.json"
OUT = MODOR / "results/mordor_atomic112_frozen_tactic_20260811"

MODELS = (
    "deepseek-v4-flash",
    "deepseek-v4-pro",
    "gemini-3.5-flash-lite",
    "glm-5.2",
    "minimax-m3",
)
MODEL_DISPLAY = {
    "deepseek-v4-flash": "DeepSeek V4 Flash",
    "deepseek-v4-pro": "DeepSeek V4 Pro",
    "gemini-3.5-flash-lite": "Gemini 3.5 Flash-Lite",
    "glm-5.2": "GLM 5.2",
    "minimax-m3": "MiniMax M3",
    "full_vote_uniform": "Full vote (uniform)",
    "full_vote_calibration_weighted": "Full vote (calibration weighted)",
    "full_vote_online_learned": "Full vote (online learned)",
    "camvo_delta-0.80_k-3": "CaMVo (δ=0.80, kmin=3)",
}
PHASE_TO_TACTIC = {
    "reconnaissance": "TA0043", "resource-development": "TA0042",
    "initial-access": "TA0001", "execution": "TA0002", "persistence": "TA0003",
    "privilege-escalation": "TA0004", "defense-evasion": "TA0005", "stealth": "TA0005",
    "credential-access": "TA0006", "discovery": "TA0007", "lateral-movement": "TA0008",
    "collection": "TA0009", "command-and-control": "TA0011", "exfiltration": "TA0010",
    "impact": "TA0040",
}
BOOTSTRAP_SEED = 20260811


def rows(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def technique_tactics_v8() -> dict[str, set[str]]:
    result: dict[str, set[str]] = defaultdict(set)
    payload = json.loads(TAXONOMY.read_text(encoding="utf-8"))
    for obj in payload["objects"]:
        if obj.get("type") != "attack-pattern":
            continue
        attack_id = next(
            (
                ref.get("external_id")
                for ref in obj.get("external_references", [])
                if ref.get("source_name") == "mitre-attack"
            ),
            None,
        )
        if not attack_id:
            continue
        for phase in obj.get("kill_chain_phases", []):
            tactic = PHASE_TO_TACTIC.get(str(phase.get("phase_name") or ""))
            if tactic:
                result[str(attack_id).upper()].add(tactic)
    return result


def primary_technique(response: dict[str, Any]) -> str:
    return str(response.get("prediction", {}).get("primary_vote_label") or "INSUFFICIENT").upper()


def response_tactic(response: dict[str, Any], mapping: dict[str, set[str]]) -> str:
    technique = primary_technique(response)
    candidates = mapping.get(technique, set())
    if not candidates:
        return "INSUFFICIENT"
    declared = response.get("prediction", {}).get("attack_tactics") or []
    first = str(declared[0].get("tactic_id") or "").upper() if declared else ""
    return first if first in candidates else sorted(candidates)[0]


def token(row: dict[str, Any], *names: str) -> int:
    usage = row.get("metadata", {}).get("usage", {}) or {}
    for name in names:
        if usage.get(name) is not None:
            return int(usage[name])
    return 0


def load_prices() -> dict[str, ModelPricing]:
    payload = json.loads(PRICES.read_text(encoding="utf-8"))["models"]
    output = {}
    for model in MODELS:
        item = payload[model]
        output[model] = ModelPricing(
            input_per_million=float(item.get("input", item.get("input_cache_miss"))),
            output_per_million=float(item["output"]),
        )
    return output


def deterministic_vote(predictions: dict[str, str], weights: dict[str, float]) -> str:
    totals: Counter[str] = Counter()
    for model, prediction in predictions.items():
        totals[prediction] += weights[model]
    maximum = max(totals.values())
    tied = {label for label, value in totals.items() if abs(value - maximum) < 1e-12}
    priority = sorted(predictions, key=lambda model: (-weights[model], model))
    return next(predictions[model] for model in priority if predictions[model] in tied)


def cluster_ci(correct: dict[str, bool], sources: dict[str, str]) -> tuple[float, float]:
    grouped: dict[str, list[str]] = defaultdict(list)
    for case_id, source in sources.items():
        grouped[source].append(case_id)
    names = sorted(grouped)
    rng = np.random.default_rng(BOOTSTRAP_SEED)
    estimates = []
    for _ in range(10_000):
        sampled = rng.choice(names, len(names), replace=True)
        sampled_cases = [case_id for name in sampled for case_id in grouped[str(name)]]
        estimates.append(sum(correct[case_id] for case_id in sampled_cases) / len(sampled_cases))
    return float(np.quantile(estimates, 0.025)), float(np.quantile(estimates, 0.975))


def exact_mcnemar(left: dict[str, bool], right: dict[str, bool]) -> dict[str, Any]:
    left_only = sum(left[c] and not right[c] for c in left)
    right_only = sum(right[c] and not left[c] for c in left)
    discordant = left_only + right_only
    if discordant == 0:
        p_value = 1.0
    else:
        smaller = min(left_only, right_only)
        p_value = min(
            1.0,
            2.0 * sum(math.comb(discordant, k) for k in range(smaller + 1)) / (2**discordant),
        )
    return {"left_only_correct": left_only, "right_only_correct": right_only, "exact_two_sided_p": p_value}


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    protocol = json.loads((PROTOCOL / "PREREGISTRATION.json").read_text(encoding="utf-8"))
    if protocol["primary_evaluation"]["primary_camvo_operating_point"] != {"delta": 0.80, "k_min": 3}:
        raise RuntimeError("unexpected frozen operating point")

    atomic_all = rows(PROTOCOL / "atomic171_all.jsonl")
    test_manifest = rows(PROTOCOL / "atomic_test.jsonl")
    test_ids = [row["case_id"] for row in test_manifest]
    calibration_ids = [row["case_id"] for row in atomic_all if row["protocol_split"] == "calibration"]
    if len(test_ids) != 112 or len({row["source_case_id"] for row in test_manifest}) != 32:
        raise RuntimeError("unexpected frozen Atomic test scope")

    all_prompts = {row["case_id"]: row for row in rows(DATA / "prompt_instances_one_view_v1.jsonl")}
    tactic_map = technique_tactics_v8()
    gold = {row["case_id"]: set(row["official_scoring_tactics_v8_2"]) for row in test_manifest}
    sources = {row["case_id"]: row["source_case_id"] for row in test_manifest}

    raw: dict[str, dict[str, dict[str, Any]]] = {case_id: {} for case_id in test_ids + calibration_ids}
    for model in MODELS:
        by_id = {row["case_id"]: row for row in rows(RUN / model / "responses.jsonl")}
        for case_id in raw:
            raw[case_id][model] = by_id[case_id]
    if any(len(raw[case_id]) != 5 for case_id in raw):
        raise RuntimeError("incomplete five-model response matrix")

    predictions_by_model = {
        model: {case_id: response_tactic(raw[case_id][model], tactic_map) for case_id in raw}
        for model in MODELS
    }
    labels = tuple(sorted(
        {"INSUFFICIENT"}
        | {predictions_by_model[m][c] for m in MODELS for c in raw}
        | set().union(*gold.values())
    ))
    calibration_gold = {
        row["case_id"]: set(row["official_scoring_tactics_v8_2"])
        for row in atomic_all if row["protocol_split"] == "calibration"
    }
    calibration_correct = {
        model: sum(predictions_by_model[model][case_id] in calibration_gold[case_id] for case_id in calibration_ids)
        for model in MODELS
    }
    calibration_weights = {
        model: (calibration_correct[model] + 1) / (len(calibration_ids) + 2)
        for model in MODELS
    }

    prices = load_prices()
    expected_output = {
        model: mean(token(raw[c][model], "completion_tokens", "candidatesTokenCount") for c in calibration_ids)
        for model in MODELS
    }
    responses = {
        model: {
            case_id: ModelResponse(
                label=predictions_by_model[model][case_id],
                input_tokens=token(raw[case_id][model], "prompt_tokens", "promptTokenCount"),
                output_tokens=token(raw[case_id][model], "completion_tokens", "candidatesTokenCount"),
                raw=raw[case_id][model],
            )
            for case_id in test_ids
        }
        for model in MODELS
    }
    items = {
        case_id: AnnotationItem(
            item_id=case_id,
            text=json.dumps(
                {"events": all_prompts[case_id]["events"], "relations": all_prompts[case_id]["relations"]},
                ensure_ascii=False,
                sort_keys=True,
                separators=(",", ":"),
            ),
            labels=labels,
            metadata={"source_case_id": sources[case_id]},
        )
        for case_id in test_ids
    }

    def response_cost(model: str, case_id: str) -> float:
        value = responses[model][case_id]
        return prices[model].cost(value.input_tokens, value.output_tokens)

    method_predictions: dict[str, dict[str, str]] = {}
    method_selections: dict[str, dict[str, list[str]]] = {}
    for model in MODELS:
        method_predictions[model] = {case_id: predictions_by_model[model][case_id] for case_id in test_ids}
        method_selections[model] = {case_id: [model] for case_id in test_ids}

    uniform = {model: 1.0 for model in MODELS}
    method_predictions["full_vote_uniform"] = {
        case_id: deterministic_vote({m: predictions_by_model[m][case_id] for m in MODELS}, uniform)
        for case_id in test_ids
    }
    method_predictions["full_vote_calibration_weighted"] = {
        case_id: deterministic_vote(
            {m: predictions_by_model[m][case_id] for m in MODELS}, calibration_weights
        )
        for case_id in test_ids
    }
    for method in ("full_vote_uniform", "full_vote_calibration_weighted"):
        method_selections[method] = {case_id: list(MODELS) for case_id in test_ids}

    online_predictions: dict[str, str] = {}
    online_observations: Counter[str] = Counter()
    online_agreements: Counter[str] = Counter()
    online_trace = []
    for round_index, case_id in enumerate(test_ids, start=1):
        weights = {
            model: online_agreements[model] / online_observations[model]
            if online_observations[model]
            else 1.0
            for model in MODELS
        }
        current = {model: predictions_by_model[model][case_id] for model in MODELS}
        prediction = deterministic_vote(current, weights)
        online_predictions[case_id] = prediction
        for model in MODELS:
            online_observations[model] += 1
            online_agreements[model] += int(current[model] == prediction)
        online_trace.append({
            "round": round_index,
            "case_id": case_id,
            "prediction": prediction,
            "weights_before_round": weights,
            "correct": prediction in gold[case_id],
        })
    method_predictions["full_vote_online_learned"] = online_predictions
    method_selections["full_vote_online_learned"] = {case_id: list(MODELS) for case_id in test_ids}

    embedder = CachedEmbedder()
    clients = [
        PreCallCostClient(
            model,
            prices[model],
            responses[model],
            expected_output_tokens=float(expected_output[model]),
        )
        for model in MODELS
    ]
    router = CaMVoRouter(
        clients,
        embedder,
        CaMVoConfig(
            embedding_dim=embedder.dimension,
            confidence_threshold=0.80,
            min_models=3,
            linucb_regularization=1.0,
            exploration_alpha=0.25,
            laplace_regularization=1.0,
            warmup_rounds=0,
            confidence_method="beta_cdf",
            update_single_model_rounds=False,
        ),
    )
    camvo_predictions: dict[str, str] = {}
    camvo_selections: dict[str, list[str]] = {}
    camvo_costs: dict[str, float] = {}
    camvo_trace = []
    cumulative_correct = 0
    cumulative_cost = 0.0
    for round_index, case_id in enumerate(test_ids, start=1):
        result = router.route(items[case_id])
        correct = result.label in gold[case_id]
        camvo_predictions[case_id] = result.label
        camvo_selections[case_id] = list(result.selected_models)
        camvo_costs[case_id] = float(result.actual_cost)
        cumulative_correct += int(correct)
        cumulative_cost += float(result.actual_cost)
        camvo_trace.append({
            "round": round_index,
            "case_id": case_id,
            "source_case_id": sources[case_id],
            "decision_time": test_manifest[round_index - 1]["decision_time"],
            "prediction": result.label,
            "gold_tactics": sorted(gold[case_id]),
            "correct": correct,
            "selected_models": list(result.selected_models),
            "models_queried": len(result.selected_models),
            "actual_cost_usd": float(result.actual_cost),
            "cumulative_accuracy": cumulative_correct / round_index,
            "cumulative_cost_usd_per_1k": cumulative_cost / round_index * 1000,
        })
    method = "camvo_delta-0.80_k-3"
    method_predictions[method] = camvo_predictions
    method_selections[method] = camvo_selections

    method_order = [
        *MODELS,
        "full_vote_uniform",
        "full_vote_calibration_weighted",
        "full_vote_online_learned",
        method,
    ]
    result_rows = []
    correctness: dict[str, dict[str, bool]] = {}
    for name in method_order:
        correct = {
            case_id: method_predictions[name][case_id] in gold[case_id]
            for case_id in test_ids
        }
        correctness[name] = correct
        low, high = cluster_ci(correct, sources)
        costs = {
            case_id: camvo_costs[case_id]
            if name == method
            else sum(response_cost(model, case_id) for model in method_selections[name][case_id])
            for case_id in test_ids
        }
        total_cost = sum(costs.values())
        result_rows.append({
            "method": name,
            "display_name": MODEL_DISPLAY[name],
            "items": len(test_ids),
            "source_groups": len(set(sources.values())),
            "correct": sum(correct.values()),
            "tactic_accuracy": sum(correct.values()) / len(test_ids),
            "cluster_ci_low": low,
            "cluster_ci_high": high,
            "actual_cost_usd": total_cost,
            "cost_usd_per_1k": total_cost / len(test_ids) * 1000,
            "average_models": mean(len(method_selections[name][case_id]) for case_id in test_ids),
            "calls": sum(len(method_selections[name][case_id]) for case_id in test_ids),
        })
    full_cost = next(row["actual_cost_usd"] for row in result_rows if row["method"] == "full_vote_online_learned")
    for row in result_rows:
        row["saving_vs_online_full"] = 1.0 - row["actual_cost_usd"] / full_cost

    by_name = {row["method"]: row for row in result_rows}
    best_single_name = max(MODELS, key=lambda name: by_name[name]["tactic_accuracy"])
    target = 0.80 * by_name["full_vote_online_learned"]["tactic_accuracy"]
    comparisons = {
        "camvo_vs_best_single": exact_mcnemar(correctness[method], correctness[best_single_name]),
        "camvo_vs_online_full": exact_mcnemar(correctness[method], correctness["full_vote_online_learned"]),
        "online_full_vs_best_single": exact_mcnemar(correctness["full_vote_online_learned"], correctness[best_single_name]),
    }
    mapping_audit = {
        model: {
            "insufficient_after_v8_mapping": sum(predictions_by_model[model][case_id] == "INSUFFICIENT" for case_id in test_ids),
            "distinct_tactic_labels": sorted(set(predictions_by_model[model][case_id] for case_id in test_ids)),
        }
        for model in MODELS
    }
    summary = {
        "schema_version": 1,
        "state": "complete",
        "provider_calls": 0,
        "protocol_id": protocol["protocol_id"],
        "split": "atomic_test",
        "items": len(test_ids),
        "source_groups": len(set(sources.values())),
        "task": protocol["primary_evaluation"]["task"],
        "taxonomy": "Enterprise ATT&CK 8.2",
        "test_order": "cold-start, decision_time ascending",
        "gold_visible_to_router": False,
        "calibration_gold_use": "fixed full-vote weights only; never supplied to online full vote or CaMVo",
        "camvo_operating_point": {"delta": 0.80, "k_min": 3},
        "camvo_target_accuracy": target,
        "camvo_target_met": by_name[method]["tactic_accuracy"] + 1e-12 >= target,
        "best_single_model": best_single_name,
        "calibration_correct": calibration_correct,
        "calibration_laplace_weights": calibration_weights,
        "results": result_rows,
        "paired_exact_mcnemar": comparisons,
        "prediction_mapping_audit": mapping_audit,
        "interpretation_boundary": protocol["interpretation_boundary"],
    }
    (OUT / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with (OUT / "atomic112_tactic_results.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(result_rows[0]))
        writer.writeheader()
        writer.writerows(result_rows)
    with (OUT / "camvo_trace.jsonl").open("w", encoding="utf-8") as handle:
        for row in camvo_trace:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    with (OUT / "online_full_vote_trace.jsonl").open("w", encoding="utf-8") as handle:
        for row in online_trace:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")

    report = [
        "# Mordor Atomic-112 冻结 tactic 实验", "",
        "性质：完全离线回放；新增模型调用 0。", "",
        "## 主结果", "",
        "| 方法 | 正确/112 | Top-1 tactic accuracy | Source-group 95% CI | Cost/1K | 相对在线全量节省 | 平均模型数 |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in result_rows:
        report.append(
            f"| {row['display_name']} | {row['correct']}/112 | {row['tactic_accuracy']:.1%} | "
            f"{row['cluster_ci_low']:.1%}–{row['cluster_ci_high']:.1%} | ${row['cost_usd_per_1k']:.2f} | "
            f"{row['saving_vs_online_full']:.1%} | {row['average_models']:.2f} |"
        )
    report += [
        "", "## 解释边界", "",
        f"CaMVo 的目标为 0.80 × online full vote = {target:.1%}，实际为 {by_name[method]['tactic_accuracy']:.1%}，target_met={summary['camvo_target_met']}。",
        "该实验扩大了在线决策次数，但 112 个决策来自 32 个已存在于 Primary101 的官方源组；因此是 source-grouped decision-level replay，不表述为 112 个全新官方场景或 prospective untouched holdout。",
        "固定权重 full vote 使用 calibration gold；online full vote 与 CaMVo 均不读取 gold，并在 test 首轮冷启动。",
    ]
    (OUT / "REPORT_ZH.md").write_text("\n".join(report) + "\n", encoding="utf-8")

    report_en = [
        "# Mordor Atomic-112 tactic-level online replay", "",
        "## Protocol", "",
        "The evaluation replays 112 chronological decisions from 32 official Mordor source groups. "
        "Each decision is scored by whether its predicted ATT&CK technique maps to an official tactic for that decision under frozen Enterprise ATT&CK 8.2. "
        "The test stream starts from a cold state. Subset selection occurs before the current model responses are revealed, and neither online full vote nor CaMVo receives evaluator labels.",
        "", "## Main results", "",
        "| Method | Correct / 112 | Top-1 tactic accuracy | Source-group 95% CI | Cost / 1K decisions | Saving vs. online full vote | Avg. models |",
        "|---|---:|---:|---:|---:|---:|---:|",
    ]
    for row in result_rows:
        report_en.append(
            f"| {row['display_name']} | {row['correct']}/112 | {row['tactic_accuracy']:.1%} | "
            f"{row['cluster_ci_low']:.1%}–{row['cluster_ci_high']:.1%} | ${row['cost_usd_per_1k']:.2f} | "
            f"{row['saving_vs_online_full']:.1%} | {row['average_models']:.2f} |"
        )
    report_en += [
        "", "## Interpretation", "",
        f"At the preregistered operating point (δ=0.80, k_min=3), CaMVo obtains {by_name[method]['correct']}/112 "
        f"({by_name[method]['tactic_accuracy']:.1%}) while using {by_name[method]['average_models']:.2f} models per decision and reducing estimated cost by "
        f"{by_name[method]['saving_vs_online_full']:.1%} relative to online full vote. Online full vote obtains "
        f"{by_name['full_vote_online_learned']['correct']}/112 ({by_name['full_vote_online_learned']['tactic_accuracy']:.1%}), and the strongest individual model obtains "
        f"{by_name[summary['best_single_model']]['correct']}/112 ({by_name[summary['best_single_model']]['tactic_accuracy']:.1%}).",
        "",
        "The paired differences are small and are not statistically significant at this scale. Confidence intervals are therefore clustered by official source group, rather than treating all derived decisions as independent. "
        "This result supports an accuracy–cost trade-off claim; it does not support a claim that CaMVo is significantly more accurate than either comparator.",
        "",
        "The 112 decisions are decision-level anchors derived from 32 official source groups already represented in the earlier Mordor benchmark. They increase chronological decision coverage but are not 112 newly independent official scenarios or a prospective untouched holdout.",
    ]
    (OUT / "REPORT_EN.md").write_text("\n".join(report_en) + "\n", encoding="utf-8")

    def latex_escape(value: str) -> str:
        return (value.replace("\\", r"\textbackslash{}")
                     .replace("&", r"\&")
                     .replace("%", r"\%")
                     .replace("_", r"\_")
                     .replace("δ", r"$\delta$")
                     .replace("kmin", r"$k_{\min}$"))

    latex = [
        r"\begin{table}[t]",
        r"\centering",
        r"\small",
        r"\caption{Mordor Atomic-112 tactic-level accuracy--cost results. Confidence intervals use source-group bootstrap resampling.}",
        r"\label{tab:mordor-atomic112}",
        r"\begin{tabular}{lrrrrr}",
        r"\toprule",
        r"Method & Correct & Acc. (\%) & Cost/1K (\$) & Saving (\%) & Models/decision \\",
        r"\midrule",
    ]
    for row in result_rows:
        latex.append(
            f"{latex_escape(row['display_name'])} & {row['correct']}/112 & {100*row['tactic_accuracy']:.1f} & "
            f"{row['cost_usd_per_1k']:.2f} & {100*row['saving_vs_online_full']:.1f} & {row['average_models']:.2f} \\\\"
        )
    latex += [
        r"\bottomrule",
        r"\end{tabular}",
        r"\end{table}",
    ]
    (OUT / "ATOMIC112_TACTIC_ACCURACY_COST_TABLE.tex").write_text("\n".join(latex) + "\n", encoding="utf-8")

    # Paper-style table figure.
    table_rows = [[
        row["display_name"],
        f"{row['correct']}/112",
        f"{100*row['tactic_accuracy']:.1f}%",
        f"{100*row['cluster_ci_low']:.1f}–{100*row['cluster_ci_high']:.1f}%",
        f"${row['cost_usd_per_1k']:.2f}",
        f"{100*row['saving_vs_online_full']:.1f}%",
        f"{row['average_models']:.2f}",
    ] for row in result_rows]
    fig, ax = plt.subplots(figsize=(15.5, 6.6))
    ax.axis("off")
    fig.suptitle("Mordor Atomic-112: online tactic accuracy–cost results", x=0.04, y=0.97, ha="left", fontsize=18, fontweight="bold", color="#17324D")
    fig.text(0.04, 0.91, "112 chronological decisions · 32 source groups · Enterprise ATT&CK 8.2", fontsize=10, color="#526474")
    table = ax.table(
        cellText=table_rows,
        colLabels=["Method", "Correct", "Accuracy", "Cluster 95% CI", "Cost / 1K", "Saving", "Avg models"],
        cellLoc="center", colLoc="center", loc="center",
        colWidths=[0.25, 0.09, 0.10, 0.14, 0.11, 0.10, 0.10],
    )
    table.auto_set_font_size(False); table.set_fontsize(9.5); table.scale(1, 1.75)
    for (r, c), cell in table.get_celld().items():
        cell.set_edgecolor("#B9C8D6"); cell.set_linewidth(0.7)
        if r == 0:
            cell.set_facecolor("#DCE7F1"); cell.set_text_props(weight="bold", color="#17324D")
        elif result_rows[r-1]["method"] == method:
            cell.set_facecolor("#DDF1E8"); cell.set_text_props(weight="bold")
        elif result_rows[r-1]["method"] == "full_vote_online_learned":
            cell.set_facecolor("#E8EEF4")
        elif r % 2 == 0:
            cell.set_facecolor("#F6F8FA")
    fig.text(0.04, 0.035, "Accuracy is Top-1 tactic membership. Test begins from a cold start; online full vote and CaMVo receive no evaluator labels.", fontsize=9, color="#687785")
    fig.tight_layout(rect=(0.02, 0.07, 0.98, 0.88))
    fig.savefig(OUT / "01_atomic112_tactic_accuracy_cost_table.png", dpi=220, bbox_inches="tight")
    fig.savefig(OUT / "01_atomic112_tactic_accuracy_cost_table.pdf", bbox_inches="tight")
    plt.close(fig)

    # Chronological trajectory figure.
    full_correct = correctness["full_vote_online_learned"]
    full_cumulative, camvo_cumulative = [], []
    fsum = csum = 0
    for index, case_id in enumerate(test_ids, start=1):
        fsum += int(full_correct[case_id]); csum += int(correctness[method][case_id])
        full_cumulative.append(fsum / index); camvo_cumulative.append(csum / index)
    x = np.arange(1, len(test_ids) + 1)
    fig, ax1 = plt.subplots(figsize=(14.5, 7.4))
    ax1.plot(x, 100*np.asarray(camvo_cumulative), color="#176DB2", linewidth=2.5, label="CaMVo cumulative accuracy")
    ax1.plot(x, 100*np.asarray(full_cumulative), color="#6F8192", linewidth=2.0, linestyle="--", label="Online full-vote cumulative accuracy")
    ax1.axhline(100*target, color="#228B66", linewidth=1.8, label=f"CaMVo target ({100*target:.1f}%)")
    ax1.set_xlabel("Chronological Atomic test decision")
    ax1.set_ylabel("Cumulative Top-1 tactic accuracy (%)", color="#176DB2")
    ax1.set_ylim(0, 100); ax1.grid(alpha=0.2)
    ax2 = ax1.twinx()
    ax2.plot(x, [row["cumulative_cost_usd_per_1k"] for row in camvo_trace], color="#C65338", linewidth=2.2, label="CaMVo cumulative cost / 1K")
    ax2.set_ylabel("Cumulative estimated cost (USD / 1K)", color="#C65338")
    lines = ax1.get_lines() + ax2.get_lines()
    ax1.legend(lines, [line.get_label() for line in lines], frameon=False, loc="center right")
    fig.suptitle("Mordor Atomic-112 chronological online replay", x=0.07, y=0.98, ha="left", fontsize=18, fontweight="bold", color="#17324D")
    fig.text(0.07, 0.935, "Cold-start replay; subset selection precedes current responses; reliability updates use assigned consensus only.", fontsize=9.5, color="#526474")
    fig.tight_layout(rect=(0.03, 0.04, 0.98, 0.91))
    fig.savefig(OUT / "02_atomic112_online_trajectory.png", dpi=220, bbox_inches="tight")
    fig.savefig(OUT / "02_atomic112_online_trajectory.pdf", bbox_inches="tight")
    plt.close(fig)

    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
