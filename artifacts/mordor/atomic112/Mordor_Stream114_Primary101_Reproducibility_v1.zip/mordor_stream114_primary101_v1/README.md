# Mordor Stream114 / Primary101 reproducibility bundle

This directory freezes the exact data used for the reported 114-round online
stream and 101-scenario headline accuracy.  The remaining 13 rounds are retained
because they enter the chronological online history even though they are not in
the accuracy denominator.

## Primary entry points

- `dataset_manifest.jsonl`: one row per stream round with evaluator partition,
  source, prompt-row hash and gold labels;
- `dataset/`: exact model-visible prompt inputs and construction audits;
- `evaluator/`: evaluator-only labels, never included in prompts;
- `frozen_matrix/`: the exact 114 x 5 response matrix and source response seeds;
- `prompt_response_binding.csv`: case-ID join with per-row hashes;
- `source_files.tsv`: normalized official source paths and verified hashes;
- `MANIFEST_SHA256.txt`: package-wide file integrity manifest.

## Reproduction boundary

The raw OTRF payloads are not duplicated in this GitHub-ready package.  Obtain
the official repository at commit `d9d40ef123d2c87d5d3df28c96bcab4f0faccc87`
and verify it using `provenance/OFFICIAL_OTRF_SHA256SUMS_20260731.txt`.  The
package includes the exact prompts and frozen response matrix, so the offline
aggregation and figures can be reproduced without new provider calls.

The official ATT&CK 8.2 taxonomy is frozen for scoring.  The current taxonomy
and explicit crosswalk are retained only for modern-ID display and audit.

## Important limitation

The historical provider rows did not contain `prompt_sha256` when collected.
This package hashes and joins the frozen prompt and response rows by their unique
case IDs, but does not misrepresent that join as a collection-time cryptographic
binding.
