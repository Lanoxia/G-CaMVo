#!/usr/bin/env python3
"""Paper-faithful CaMVo replay over all 114 official Mordor scenarios.

The frozen 114x5 response matrix is reused, so this script makes zero provider
calls.  Online routing never receives official labels.  Scenario labels are
used only after each decision to calculate evaluator metrics.

Primary correctness is the official ATT&CK technique-family hit rate: the
parent family of the voted primary technique must belong to the official
scenario technique set.  Exact current-technique membership is retained as a
strict secondary audit metric.
"""

from __future__ import annotations

import csv
import json
from collections import Counter
from pathlib import Path
from statistics import mean
from typing import Any

import numpy as np

from camvo.config import CaMVoConfig
from camvo.embeddings.base import EmbeddingProvider
from camvo.embeddings.sentence_transformer import SentenceTransformerEmbedder
from camvo.router import CaMVoRouter
from camvo.security.formal_experiment import FrozenResponseMatrixClient
from camvo.types import AnnotationItem, ModelPricing, ModelResponse

from replay_full114_paper_faithful_camvo import CachedEmbedder
from replay_full114_real_price_camvo import FX_CNY_PER_USD, PRICE_SNAPSHOT


ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "REPO/modor/data"
OUT = ROOT / "REPO/modor/results/full114_official_gold_camvo_20260803"
PROMPTS_PATH = DATA / "full114_v1c/prompt_instances_full114_v1c.jsonl"
MATRIX_PATH = ROOT / "REPO/modor/results/full114_v1c_matrix_20260803/responses_matrix_114x5.jsonl"
CROSSWALK_PATH = DATA / "attack_taxonomy/enterprise_attack_id_crosswalk_v8_to_current.json"
GOLD_PATHS = (
    DATA / "benchmark_official_v2/gold_core_atomic.jsonl",
    DATA / "benchmark_official_v2/gold_compound_stress.jsonl",
    DATA / "benchmark_official_v2/gold_campaign_research.jsonl",
)

DELTAS = (0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 0.97, 0.99)
MIN_MODELS = (1, 3)


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def family(label: str) -> str:
    return label.split(".", 1)[0] if label.startswith("T") and "." in label else label


def usage_tokens(row: dict[str, Any]) -> tuple[int, int]:
    usage = row.get("metadata", {}).get("usage", {})
    return (
        int(usage.get("prompt_tokens") or usage.get("promptTokenCount") or 0),
        int(usage.get("completion_tokens") or usage.get("candidatesTokenCount") or 0),
    )


class PricedFrozenClient(FrozenResponseMatrixClient):
    """Pre-call estimate uses frozen prompt length and the public input rate."""

    def estimate_cost(self, item: AnnotationItem) -> float:
        response = self._responses[item.item_id]
        return self.pricing.cost(response.input_tokens, 0)


def build_data() -> tuple[
    list[AnnotationItem],
    dict[str, dict[str, ModelResponse]],
    dict[str, dict[str, Any]],
    list[str],
]:
    prompts = read_jsonl(PROMPTS_PATH)
    prompt_by_case = {str(row["case_id"]): row for row in prompts}
    prompt_position = {str(row["case_id"]): index for index, row in enumerate(prompts)}

    crosswalk_doc = json.loads(CROSSWALK_PATH.read_text(encoding="utf-8"))
    crosswalk = {
        str(row["source_attack_id"]): str(row["target_attack_id"])
        for row in crosswalk_doc["mappings"]
        if row.get("target_attack_id")
    }

    def canonical(label: str) -> str:
        return crosswalk.get(str(label).strip(), str(label).strip())

    gold_rows = [row for path in GOLD_PATHS for row in read_jsonl(path)]
    gold: dict[str, dict[str, Any]] = {}
    for row in gold_rows:
        exact = sorted({canonical(value) for value in row.get("gold_attack_techniques", [])})
        gold[str(row["case_id"])] = {
            **row,
            "gold_current_techniques": exact,
            "gold_current_families": sorted({family(value) for value in exact}),
        }

    response_rows = read_jsonl(MATRIX_PATH)
    model_ids = sorted({str(row["model_alias"]) for row in response_rows})
    matrix: dict[str, dict[str, ModelResponse]] = {case_id: {} for case_id in gold}
    strict_prediction: dict[str, dict[str, str]] = {case_id: {} for case_id in gold}
    for row in response_rows:
        case_id = str(row["case_id"])
        model = str(row["model_alias"])
        exact = canonical(str(row["prediction"]["primary_vote_label"]))
        input_tokens, output_tokens = usage_tokens(row)
        matrix[case_id][model] = ModelResponse(
            label=family(exact),
            input_tokens=input_tokens,
            output_tokens=output_tokens,
        )
        strict_prediction[case_id][model] = exact

    if len(gold) != 114 or set(gold) != set(prompt_by_case) or set(gold) != set(matrix):
        raise RuntimeError("official gold, compact prompts, and frozen matrix must cover the same 114 cases")
    if any(set(matrix[case_id]) != set(model_ids) for case_id in gold):
        raise RuntimeError("expected a complete 114x5 response matrix")
    if set(model_ids) != set(PRICE_SNAPSHOT):
        raise RuntimeError("price snapshot does not match the frozen model pool")

    labels = tuple(
        sorted(
            {response.label for row in matrix.values() for response in row.values()}
            | {value for row in gold.values() for value in row["gold_current_families"]}
        )
    )
    items: list[AnnotationItem] = []
    for case_id, position in sorted(prompt_position.items(), key=lambda pair: pair[1]):
        prompt = prompt_by_case[case_id]
        text = json.dumps(
            {
                "events": prompt.get("events", []),
                "relations": prompt.get("relations", []),
                "platforms": prompt.get("platforms", []),
            },
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        items.append(
            AnnotationItem(
                item_id=case_id,
                text=text,
                labels=labels,
                metadata={
                    "global_position": position,
                    "partition": gold[case_id]["partition"],
                    "official_title": gold[case_id].get("official_title"),
                    "gold_exact": gold[case_id]["gold_current_techniques"],
                    "gold_families": gold[case_id]["gold_current_families"],
                    "strict_prediction": strict_prediction[case_id],
                },
            )
        )
    return items, matrix, gold, model_ids


def make_router(
    model_ids: list[str],
    matrix: dict[str, dict[str, ModelResponse]],
    embedder: EmbeddingProvider,
    *,
    delta: float,
    min_models: int,
) -> CaMVoRouter:
    clients = []
    for model in model_ids:
        price = PRICE_SNAPSHOT[model]
        clients.append(
            PricedFrozenClient(
                model,
                ModelPricing(
                    input_per_million=float(price["input_usd_per_million"]),
                    output_per_million=float(price["output_usd_per_million"]),
                ),
                {case_id: responses[model] for case_id, responses in matrix.items()},
            )
        )
    return CaMVoRouter(
        clients,
        embedder,
        CaMVoConfig(
            embedding_dim=384,
            confidence_threshold=delta,
            min_models=min_models,
            linucb_regularization=1.0,
            exploration_alpha=0.25,
            laplace_regularization=1.0,
            warmup_rounds=0,
            confidence_method="beta_cdf",
            update_single_model_rounds=False,
        ),
    )


def call_cost(row: dict[str, ModelResponse], models: list[str], include_output: bool) -> float:
    total = 0.0
    for model in models:
        price = PRICE_SNAPSHOT[model]
        total += row[model].input_tokens * float(price["input_usd_per_million"])
        if include_output:
            total += row[model].output_tokens * float(price["output_usd_per_million"])
    return total / 1_000_000


def summarize(traces: list[dict[str, Any]], model_count: int) -> dict[str, Any]:
    calls = sum(len(row["selected_models"]) for row in traces)
    return {
        "scenarios": len(traces),
        "correct": sum(bool(row["correct_family"]) for row in traces),
        "accuracy": mean(bool(row["correct_family"]) for row in traces),
        "strict_exact_correct": sum(bool(row["correct_exact_if_unanimous_primary"]) for row in traces),
        "strict_exact_accuracy": mean(bool(row["correct_exact_if_unanimous_primary"]) for row in traces),
        "calls": calls,
        "average_models": calls / len(traces),
        "call_savings_vs_full": 1.0 - calls / (len(traces) * model_count),
        "paper_input_rate_usd_per_million": mean(
            float(row["selected_input_rate_usd_per_million"]) for row in traces
        ),
        "input_cost_usd_114": sum(float(row["input_cost_usd"]) for row in traces),
        "billed_cost_usd_114": sum(float(row["billed_cost_usd"]) for row in traces),
        "subset_size_counts": dict(sorted(Counter(len(row["selected_models"]) for row in traces).items())),
    }


def replay(
    items: list[AnnotationItem],
    matrix: dict[str, dict[str, ModelResponse]],
    model_ids: list[str],
    embedder: EmbeddingProvider,
    *,
    delta: float,
    min_models: int,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    router = make_router(model_ids, matrix, embedder, delta=delta, min_models=min_models)
    traces: list[dict[str, Any]] = []
    correct_so_far = 0
    billed_so_far = 0.0
    for round_index, item in enumerate(items, start=1):
        result = router.route(item)
        selected = list(result.selected_models)
        row = matrix[item.item_id]
        correct_family = result.label in item.metadata["gold_families"]

        # Exact correctness is only meaningful when every selected model that
        # supports the winning family names the same exact technique.  This is
        # a deliberately conservative strict audit, not the primary metric.
        winning_exact = {
            item.metadata["strict_prediction"][model]
            for model in selected
            if row[model].label == result.label
        }
        exact_correct = len(winning_exact) == 1 and next(iter(winning_exact)) in item.metadata["gold_exact"]
        billed = call_cost(row, selected, True)
        correct_so_far += int(correct_family)
        billed_so_far += billed
        traces.append(
            {
                "round": round_index,
                "case_id": item.item_id,
                "partition": item.metadata["partition"],
                "prediction": result.label,
                "gold_families": item.metadata["gold_families"],
                "correct_family": correct_family,
                "correct_exact_if_unanimous_primary": exact_correct,
                "selected_models": selected,
                "subset_confidence": result.subset_confidence,
                "subset_feasible": len(selected) < len(model_ids),
                "selected_input_rate_usd_per_million": sum(
                    float(PRICE_SNAPSHOT[model]["input_usd_per_million"]) for model in selected
                ),
                "input_cost_usd": call_cost(row, selected, False),
                "billed_cost_usd": billed,
                "cumulative_accuracy": correct_so_far / round_index,
                "cumulative_mean_billed_cost_usd": billed_so_far / round_index,
            }
        )
    return summarize(traces, len(model_ids)), traces


def single_model_rows(
    items: list[AnnotationItem],
    matrix: dict[str, dict[str, ModelResponse]],
    model_ids: list[str],
) -> list[dict[str, Any]]:
    rows = []
    for model in model_ids:
        correct = [matrix[item.item_id][model].label in item.metadata["gold_families"] for item in items]
        exact = [
            item.metadata["strict_prediction"][model] in item.metadata["gold_exact"]
            for item in items
        ]
        input_cost = sum(call_cost(matrix[item.item_id], [model], False) for item in items)
        billed = sum(call_cost(matrix[item.item_id], [model], True) for item in items)
        rows.append(
            {
                "method": f"Single: {model}",
                "accuracy": mean(correct),
                "strict_exact_accuracy": mean(exact),
                "calls": len(items),
                "average_models": 1.0,
                "paper_input_rate_usd_per_million": float(
                    PRICE_SNAPSHOT[model]["input_usd_per_million"]
                ),
                "input_cost_usd_114": input_cost,
                "billed_cost_usd_114": billed,
            }
        )
    return rows


def full_vote_reference(
    items: list[AnnotationItem],
    matrix: dict[str, dict[str, ModelResponse]],
    model_ids: list[str],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    # Match the CaMVo paper reference: full-panel weights are proportional to
    # each model's measured accuracy.  This is explicitly a post-hoc baseline.
    weights = {
        model: mean(
            matrix[item.item_id][model].label in item.metadata["gold_families"] for item in items
        )
        for model in model_ids
    }
    traces = []
    correct_so_far = 0
    billed_so_far = 0.0
    for round_index, item in enumerate(items, start=1):
        totals: dict[str, float] = Counter()
        for model in model_ids:
            totals[matrix[item.item_id][model].label] += weights[model]
        maximum = max(totals.values())
        prediction = sorted(label for label, value in totals.items() if np.isclose(value, maximum))[0]
        correct = prediction in item.metadata["gold_families"]
        winning_exact = {
            item.metadata["strict_prediction"][model]
            for model in model_ids
            if matrix[item.item_id][model].label == prediction
        }
        exact_correct = len(winning_exact) == 1 and next(iter(winning_exact)) in item.metadata["gold_exact"]
        billed = call_cost(matrix[item.item_id], model_ids, True)
        correct_so_far += int(correct)
        billed_so_far += billed
        traces.append(
            {
                "round": round_index,
                "case_id": item.item_id,
                "prediction": prediction,
                "gold_families": item.metadata["gold_families"],
                "correct_family": correct,
                "correct_exact_if_unanimous_primary": exact_correct,
                "selected_models": model_ids,
                "selected_input_rate_usd_per_million": sum(
                    float(PRICE_SNAPSHOT[model]["input_usd_per_million"]) for model in model_ids
                ),
                "input_cost_usd": call_cost(matrix[item.item_id], model_ids, False),
                "billed_cost_usd": billed,
                "cumulative_accuracy": correct_so_far / round_index,
                "cumulative_mean_billed_cost_usd": billed_so_far / round_index,
            }
        )
    return {**summarize(traces, len(model_ids)), "weights": weights}, traces


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    items, matrix, _gold, model_ids = build_data()
    embedder = CachedEmbedder(SentenceTransformerEmbedder())
    single_rows = single_model_rows(items, matrix, model_ids)
    reference, reference_traces = full_vote_reference(items, matrix, model_ids)

    grid: list[dict[str, Any]] = []
    traces_by_run: dict[str, list[dict[str, Any]]] = {}
    for min_models in MIN_MODELS:
        for delta in DELTAS:
            metrics, traces = replay(
                items,
                matrix,
                model_ids,
                embedder,
                delta=delta,
                min_models=min_models,
            )
            run_id = f"delta-{delta:.3f}_k-{min_models}"
            target = delta * float(reference["accuracy"])
            grid.append(
                {
                    "method": f"CaMVo δ={delta:.2f}, k_min={min_models}",
                    "run_id": run_id,
                    "delta": delta,
                    "min_models": min_models,
                    "target_accuracy": target,
                    "target_met": float(metrics["accuracy"]) + 1e-12 >= target,
                    **metrics,
                }
            )
            traces_by_run[run_id] = traces

    full_row = {
        "method": "Full vote (paper weighted reference)",
        "target_accuracy": None,
        "target_met": None,
        **reference,
    }
    full_cost = float(reference["billed_cost_usd_114"])
    for row in single_rows:
        row["cost_savings_vs_full"] = 1.0 - float(row["billed_cost_usd_114"]) / full_cost
    for row in grid:
        row["cost_savings_vs_full"] = 1.0 - float(row["billed_cost_usd_114"]) / full_cost
    full_row["cost_savings_vs_full"] = 0.0

    selected = sorted(
        grid,
        key=lambda row: (
            not bool(row["target_met"]),
            -float(row["accuracy"]),
            float(row["billed_cost_usd_114"]),
        ),
    )[0]
    summary = {
        "state": "complete",
        "provider_calls": 0,
        "dataset": "all 114 official OTRF/Mordor scenarios",
        "primary_metric": "official scenario ATT&CK technique-family hit rate",
        "strict_secondary_metric": "exact current-technique hit when winning-family voters are exact-unanimous",
        "online_protocol": "frozen order; labels excluded from routing; CaMVo updates from assigned consensus only",
        "target_definition": "delta times full-panel paper-weighted reference accuracy",
        "price_snapshot_date": "2026-08-03",
        "fx_cny_per_usd": FX_CNY_PER_USD,
        "price_snapshot": PRICE_SNAPSHOT,
        "single_models": single_rows,
        "full_vote": full_row,
        "camvo_grid": grid,
        "selected_run": selected,
    }
    (OUT / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    combined_rows = single_rows + [full_row] + grid
    columns = sorted({key for row in combined_rows for key in row})
    with (OUT / "all_methods_table.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(combined_rows)
    with (OUT / "full_vote_traces.jsonl").open("w", encoding="utf-8") as handle:
        for row in reference_traces:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    for run_id, traces in traces_by_run.items():
        with (OUT / f"traces_{run_id}.jsonl").open("w", encoding="utf-8") as handle:
            for row in traces:
                handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")

    print(json.dumps({"out": str(OUT), "selected": selected, "full_vote": full_row}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
