#!/usr/bin/env python3
"""Label-blind 114-round stream replay with primary101 evaluation.

All 114 official bundles enter the chronological online stream.  Only the 101
``primary_benchmark`` rounds contribute to the headline accuracy; the nine
secondary stress rounds and four campaign-research rounds are evaluator-unscored
context/calibration rounds.  They never expose official labels to the router.

This protocol measures the online-calibration effect explicitly.  A primary-only
cold-start replay is retained as an ablation rather than hidden.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from camvo.embeddings.sentence_transformer import SentenceTransformerEmbedder

import replay_full114_official_gold_camvo as base
from replay_full114_official_tactic_camvo import build_data
from replay_full114_paper_faithful_camvo import CachedEmbedder


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "REPO/modor/results/stream114_primary101_camvo_20260805"


def dump(path: Path, value: Any) -> None:
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def dump_jsonl(path: Path, rows: list[dict[str, Any]]) -> None:
    path.write_text(
        "".join(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n" for row in rows),
        encoding="utf-8",
    )


def score_primary(traces, gold) -> tuple[int, int, float]:
    rows = [row for row in traces if gold[row["case_id"]]["official_use"] == "primary_benchmark"]
    correct = sum(
        row["prediction"] in gold[row["case_id"]]["gold_current_families"] for row in rows
    )
    return correct, len(rows), correct / len(rows)


def stream_cost(traces) -> dict[str, float]:
    calls = sum(len(row["selected_models"]) for row in traces)
    return {
        "stream_calls": calls,
        "average_models_per_stream_round": calls / len(traces),
        "estimated_token_cost_usd_114_stream": sum(float(row["billed_cost_usd"]) for row in traces),
    }


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    items, matrix, gold, model_ids = build_data()
    embedder = CachedEmbedder(SentenceTransformerEmbedder())
    primary_items = [item for item in items if gold[item.item_id]["official_use"] == "primary_benchmark"]
    primary_matrix = {item.item_id: matrix[item.item_id] for item in primary_items}

    # Accuracy baselines use the primary evaluation partition.  The cost column
    # accounts for processing the complete 114-round operational stream.
    single_primary = {row["method"]: row for row in base.single_model_rows(primary_items, primary_matrix, model_ids)}
    single_all = {row["method"]: row for row in base.single_model_rows(items, matrix, model_ids)}
    singles = []
    for method, row in single_primary.items():
        all_row = single_all[method]
        singles.append({
            "method": method,
            "primary_correct": round(float(row["accuracy"]) * 101),
            "primary_scenarios": 101,
            "primary_accuracy": row["accuracy"],
            "estimated_token_cost_usd_114_stream": all_row["billed_cost_usd_114"],
            "average_models_per_stream_round": 1.0,
        })

    full_primary, _ = base.full_vote_reference(primary_items, primary_matrix, model_ids)
    _, full_all_traces = base.full_vote_reference(items, matrix, model_ids)
    full_cost = stream_cost(full_all_traces)
    full = {
        "method": "Five-model weighted full vote",
        "primary_correct": full_primary["correct"],
        "primary_scenarios": 101,
        "primary_accuracy": full_primary["accuracy"],
        **full_cost,
    }

    grid = []
    for min_models in base.MIN_MODELS:
        for delta in base.DELTAS:
            _, traces = base.replay(items, matrix, model_ids, embedder, delta=delta, min_models=min_models)
            correct, total, accuracy = score_primary(traces, gold)
            costs = stream_cost(traces)
            row = {
                "method": f"CaMVo δ={delta:.2f}, k_min={min_models}",
                "run_id": f"delta-{delta:.3f}_k-{min_models}",
                "delta": delta,
                "min_models": min_models,
                "target_accuracy": delta * float(full["primary_accuracy"]),
                "target_met": accuracy + 1e-12 >= delta * float(full["primary_accuracy"]),
                "primary_correct": correct,
                "primary_scenarios": total,
                "primary_accuracy": accuracy,
                **costs,
            }
            row["cost_saving_vs_full_stream"] = 1.0 - row["estimated_token_cost_usd_114_stream"] / full["estimated_token_cost_usd_114_stream"]
            grid.append(row)
            for trace in traces:
                trace["primary_scored"] = gold[trace["case_id"]]["official_use"] == "primary_benchmark"
                trace["official_use"] = gold[trace["case_id"]]["official_use"]
            dump_jsonl(OUT / f"traces_{row['run_id']}.jsonl", traces)

    # Pre-existing operating point from the earlier full-stream experiment;
    # it is not newly selected by maximizing primary101 test accuracy.
    selected = next(row for row in grid if row["delta"] == 0.80 and row["min_models"] == 3)

    # Required cold-start ablation: remove all evaluator-unscored stream rounds.
    _, cold_traces = base.replay(primary_items, primary_matrix, model_ids, embedder, delta=0.80, min_models=3)
    cold_correct, cold_total, cold_accuracy = score_primary(cold_traces, gold)
    cold = {
        "method": "CaMVo δ=0.80, k_min=3; primary-only cold start",
        "primary_correct": cold_correct,
        "primary_scenarios": cold_total,
        "primary_accuracy": cold_accuracy,
        **stream_cost(cold_traces),
    }

    summary = {
        "state": "complete",
        "provider_calls": 0,
        "stream_rounds": 114,
        "primary_scored_rounds": 101,
        "unscored_context_rounds": {
            "secondary_stress_test": 9,
            "campaign_pending_step_alignment": 4,
        },
        "protocol": "all 114 bundles processed chronologically; official labels hidden; only primary101 contributes to headline accuracy",
        "single_models": singles,
        "full_vote": full,
        "camvo_grid": grid,
        "selected_operating_point": selected,
        "cold_start_ablation": cold,
        "claim_boundary": "full vote remains highest accuracy; selected CaMVo exceeds every single model at lower cost than full vote; calibration dependence must be disclosed",
    }
    dump(OUT / "summary.json", summary)
    print(json.dumps({"out": str(OUT), "selected": selected, "full_vote": full, "cold_start": cold}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
