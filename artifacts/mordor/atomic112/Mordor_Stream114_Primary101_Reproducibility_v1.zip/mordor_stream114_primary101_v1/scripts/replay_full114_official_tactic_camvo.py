#!/usr/bin/env python3
"""PPT-aligned CaMVo replay on the primary ATT&CK tactic for all 114 cases.

This provider-free replay uses the primary tactic already emitted by each of
the five frozen model responses.  Official scenario tactics remain evaluator
only.  CaMVo therefore learns/routs over tactic labels, rather than scoring a
post-hoc tactic conversion of a technique-family replay.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path
from typing import Any

from camvo.embeddings.sentence_transformer import SentenceTransformerEmbedder
from camvo.types import AnnotationItem, ModelResponse

import replay_full114_official_gold_camvo as base
from replay_full114_paper_faithful_camvo import CachedEmbedder


ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "REPO/modor/data"
OUT = ROOT / "REPO/modor/results/full114_official_tactic_camvo_20260803"


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line]


def primary_tactic(prediction: dict[str, Any]) -> str:
    tactics = prediction.get("attack_tactics") or []
    if not tactics:
        return "insufficient"
    value = str(tactics[0].get("tactic_id") or "").strip()
    return value if value.startswith("TA") else "insufficient"


def build_data() -> tuple[
    list[AnnotationItem],
    dict[str, dict[str, ModelResponse]],
    dict[str, dict[str, Any]],
    list[str],
]:
    prompts = read_jsonl(base.PROMPTS_PATH)
    prompt_by_case = {str(row["case_id"]): row for row in prompts}
    prompt_position = {str(row["case_id"]): index for index, row in enumerate(prompts)}

    crosswalk_doc = json.loads(base.CROSSWALK_PATH.read_text(encoding="utf-8"))
    crosswalk = {
        str(row["source_attack_id"]): str(row["target_attack_id"])
        for row in crosswalk_doc["mappings"]
        if row.get("target_attack_id")
    }

    def canonical(label: str) -> str:
        return crosswalk.get(str(label).strip(), str(label).strip())

    gold_rows = [row for path in base.GOLD_PATHS for row in read_jsonl(path)]
    gold: dict[str, dict[str, Any]] = {}
    for row in gold_rows:
        exact = sorted({canonical(value) for value in row.get("gold_attack_techniques", [])})
        gold[str(row["case_id"])] = {
            **row,
            "gold_current_techniques": exact,
            # Reuse the base replay's generic membership field for tactics.
            "gold_current_families": sorted(set(row.get("gold_attack_tactics", []))),
        }

    response_rows = read_jsonl(base.MATRIX_PATH)
    model_ids = sorted({str(row["model_alias"]) for row in response_rows})
    matrix: dict[str, dict[str, ModelResponse]] = {case_id: {} for case_id in gold}
    strict_prediction: dict[str, dict[str, str]] = {case_id: {} for case_id in gold}
    for row in response_rows:
        case_id = str(row["case_id"])
        model = str(row["model_alias"])
        prediction = row["prediction"]
        input_tokens, output_tokens = base.usage_tokens(row)
        matrix[case_id][model] = ModelResponse(
            label=primary_tactic(prediction),
            input_tokens=input_tokens,
            output_tokens=output_tokens,
        )
        strict_prediction[case_id][model] = canonical(str(prediction["primary_vote_label"]))

    if len(gold) != 114 or set(gold) != set(prompt_by_case) or set(gold) != set(matrix):
        raise RuntimeError("gold, prompts, and matrix must cover the same 114 cases")
    if any(set(matrix[case_id]) != set(model_ids) for case_id in gold):
        raise RuntimeError("expected a complete 114x5 matrix")

    labels = tuple(sorted(
        {response.label for row in matrix.values() for response in row.values()}
        | {value for row in gold.values() for value in row["gold_current_families"]}
    ))
    items: list[AnnotationItem] = []
    for case_id, position in sorted(prompt_position.items(), key=lambda pair: pair[1]):
        prompt = prompt_by_case[case_id]
        text = json.dumps(
            {
                "events": prompt.get("events", []),
                "relations": prompt.get("relations", []),
                "platforms": prompt.get("platforms", []),
            },
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        items.append(AnnotationItem(
            item_id=case_id,
            text=text,
            labels=labels,
            metadata={
                "global_position": position,
                "partition": gold[case_id]["partition"],
                "official_title": gold[case_id].get("official_title"),
                "gold_exact": gold[case_id]["gold_current_techniques"],
                "gold_families": gold[case_id]["gold_current_families"],
                "strict_prediction": strict_prediction[case_id],
            },
        ))
    return items, matrix, gold, model_ids


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    items, matrix, _gold, model_ids = build_data()
    embedder = CachedEmbedder(SentenceTransformerEmbedder())
    singles = base.single_model_rows(items, matrix, model_ids)
    reference, reference_traces = base.full_vote_reference(items, matrix, model_ids)

    grid: list[dict[str, Any]] = []
    traces_by_run: dict[str, list[dict[str, Any]]] = {}
    for min_models in base.MIN_MODELS:
        for delta in base.DELTAS:
            metrics, traces = base.replay(
                items, matrix, model_ids, embedder, delta=delta, min_models=min_models
            )
            run_id = f"delta-{delta:.3f}_k-{min_models}"
            target = delta * float(reference["accuracy"])
            grid.append({
                "method": f"CaMVo δ={delta:.2f}, k_min={min_models}",
                "run_id": run_id,
                "delta": delta,
                "min_models": min_models,
                "target_accuracy": target,
                "target_met": float(metrics["accuracy"]) + 1e-12 >= target,
                **metrics,
            })
            traces_by_run[run_id] = traces

    full_row = {
        "method": "Full vote (paper weighted reference)",
        "target_accuracy": None,
        "target_met": None,
        **reference,
    }
    full_cost = float(reference["billed_cost_usd_114"])
    for row in singles:
        row["cost_savings_vs_full"] = 1.0 - float(row["billed_cost_usd_114"]) / full_cost
    for row in grid:
        row["cost_savings_vs_full"] = 1.0 - float(row["billed_cost_usd_114"]) / full_cost
    full_row["cost_savings_vs_full"] = 0.0

    selected = sorted(
        grid,
        key=lambda row: (
            not bool(row["target_met"]),
            -float(row["accuracy"]),
            float(row["billed_cost_usd_114"]),
        ),
    )[0]
    summary = {
        "state": "complete",
        "provider_calls": 0,
        "dataset": "all 114 official OTRF/Mordor scenarios",
        "primary_metric": "primary ATT&CK tactic accuracy against official scenario tactic set",
        "strict_secondary_metric": "exact current-technique audit retained separately",
        "online_protocol": "frozen order; labels excluded from routing; CaMVo updates from assigned consensus only",
        "target_definition": "delta times full-panel paper-weighted tactic accuracy",
        "price_snapshot_date": "2026-08-03",
        "single_models": singles,
        "full_vote": full_row,
        "camvo_grid": grid,
        "selected_run": selected,
    }
    (OUT / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    combined = singles + [full_row] + grid
    columns = sorted({key for row in combined for key in row})
    with (OUT / "all_methods_table.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(combined)
    with (OUT / "full_vote_traces.jsonl").open("w", encoding="utf-8") as handle:
        for row in reference_traces:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    for run_id, traces in traces_by_run.items():
        with (OUT / f"traces_{run_id}.jsonl").open("w", encoding="utf-8") as handle:
            for row in traces:
                handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    print(json.dumps({"out": str(OUT), "selected": selected, "full_vote": full_row}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
