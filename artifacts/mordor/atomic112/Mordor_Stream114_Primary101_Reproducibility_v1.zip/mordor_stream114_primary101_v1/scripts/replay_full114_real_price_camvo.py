#!/usr/bin/env python3
"""Replay paper-faithful CaMVo with a dated, public API-price snapshot.

No provider calls are made.  The immutable 114x5 response matrix is replayed
chronologically.  The router sees prompt text, past consensus feedback, and
pre-call token-cost estimates only.  Human-reviewed gold remains post-hoc.

Primary reporting follows the professor's request: accuracy is the fraction of
correctly labelled, evidence-observable data points, and the target is
``delta * full-panel accuracy``.  Coverage is always reported alongside this
selective accuracy so the smaller observable subset cannot be mistaken for the
whole benchmark.
"""

from __future__ import annotations

import csv
import json
from collections import Counter
from pathlib import Path
from statistics import mean
from typing import Any

from camvo.config import CaMVoConfig
from camvo.embeddings.base import EmbeddingProvider
from camvo.embeddings.sentence_transformer import SentenceTransformerEmbedder
from camvo.router import CaMVoRouter
from camvo.security.formal_experiment import FrozenResponseMatrixClient
from camvo.types import AnnotationItem, ModelPricing, ModelResponse

from replay_full114_paper_faithful_camvo import CachedEmbedder
from replay_full114_reviewed_camvo import build_data


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "REPO/modor/results/full114_real_price_camvo_20260803"
FX_CNY_PER_USD = 7.20
DELTAS = (0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 0.97, 0.99)
MIN_MODELS = (1, 3)

# Standard, non-batch public API rates observed on 2026-08-03.  Input cache
# discounts are excluded from routing because a future hit is not guaranteed.
# CNY list prices are converted with a fixed, disclosed analysis rate.
PRICE_SNAPSHOT = {
    "deepseek-v4-flash": {
        "input_usd_per_million": 0.14,
        "output_usd_per_million": 0.28,
        "native": {"currency": "USD", "input": 0.14, "output": 0.28},
        "source": "https://api-docs.deepseek.com/quick_start/pricing",
    },
    "deepseek-v4-pro": {
        "input_usd_per_million": 0.435,
        "output_usd_per_million": 0.87,
        "native": {"currency": "USD", "input": 0.435, "output": 0.87},
        "source": "https://api-docs.deepseek.com/quick_start/pricing",
    },
    "gemini-3.5-flash-lite": {
        "input_usd_per_million": 0.30,
        "output_usd_per_million": 2.50,
        "native": {"currency": "USD", "input": 0.30, "output": 2.50},
        "source": "https://ai.google.dev/gemini-api/docs/pricing",
    },
    "glm-5.2": {
        "input_usd_per_million": 8.0 / FX_CNY_PER_USD,
        "output_usd_per_million": 28.0 / FX_CNY_PER_USD,
        "native": {"currency": "CNY", "input": 8.0, "output": 28.0},
        "source": "https://bigmodel.cn/pricing",
    },
    "MiniMax-M3": {
        "input_usd_per_million": 2.10 / FX_CNY_PER_USD,
        "output_usd_per_million": 8.40 / FX_CNY_PER_USD,
        "native": {"currency": "CNY", "input": 2.10, "output": 8.40},
        "source": "https://platform.minimaxi.com/docs/guides/pricing-paygo",
    },
}


class PricedFrozenClient(FrozenResponseMatrixClient):
    """Estimate the next call from its frozen prompt-token count."""

    def estimate_cost(self, item: AnnotationItem) -> float:
        response = self._responses[item.item_id]
        return self.pricing.cost(response.input_tokens, 0)


def macro_f1(gold: list[str], predicted: list[str]) -> float | None:
    labels = sorted(set(gold))
    if not labels:
        return None
    scores: list[float] = []
    for label in labels:
        tp = sum(g == label and p == label for g, p in zip(gold, predicted))
        fp = sum(g != label and p == label for g, p in zip(gold, predicted))
        fn = sum(g == label and p != label for g, p in zip(gold, predicted))
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        scores.append(2 * precision * recall / (precision + recall) if precision + recall else 0.0)
    return mean(scores)


def make_router(
    model_ids: list[str],
    matrix: dict[str, dict[str, ModelResponse]],
    embedder: EmbeddingProvider,
    *,
    delta: float,
    min_models: int,
) -> CaMVoRouter:
    clients = []
    for model_id in model_ids:
        price = PRICE_SNAPSHOT[model_id]
        clients.append(
            PricedFrozenClient(
                model_id,
                ModelPricing(
                    input_per_million=float(price["input_usd_per_million"]),
                    output_per_million=float(price["output_usd_per_million"]),
                ),
                {case_id: responses[model_id] for case_id, responses in matrix.items()},
            )
        )
    return CaMVoRouter(
        clients,
        embedder,
        CaMVoConfig(
            embedding_dim=384,
            confidence_threshold=delta,
            min_models=min_models,
            linucb_regularization=1.0,
            exploration_alpha=0.25,
            laplace_regularization=1.0,
            warmup_rounds=0,
            confidence_method="beta_cdf",
            update_single_model_rounds=False,
        ),
    )


def summarize(traces: list[dict[str, Any]], model_count: int) -> dict[str, Any]:
    reviewed = [row for row in traces if row["reviewed"]]
    observable = [row for row in reviewed if row["observable"]]
    gold = [row["gold_primary_family"] for row in reviewed]
    predicted = [row["prediction"] for row in reviewed]
    calls = sum(len(row["selected_models"]) for row in traces)
    input_cost = sum(float(row["input_cost_usd"]) for row in traces)
    total_cost = sum(float(row["total_cost_usd"]) for row in traces)
    full_input_cost = sum(float(row["full_panel_input_cost_usd"]) for row in traces)
    full_total_cost = sum(float(row["full_panel_total_cost_usd"]) for row in traces)
    return {
        "stream_cases": len(traces),
        "reviewed_cases": len(reviewed),
        "observable_cases": len(observable),
        "observable_coverage_of_reviewed": len(observable) / len(reviewed),
        "reviewed_primary_accuracy": sum(g == p for g, p in zip(gold, predicted)) / len(reviewed),
        "reviewed_primary_macro_f1": macro_f1(gold, predicted),
        "observable_family_accuracy": (
            sum(row["prediction"] in row["acceptable_families"] for row in observable)
            / len(observable)
        ),
        "calls": calls,
        "average_models": calls / len(traces),
        "call_savings": 1.0 - calls / (len(traces) * model_count),
        "mean_selected_input_rate_usd_per_million": mean(
            row["selected_input_rate_usd_per_million"] for row in traces
        ),
        "input_cost_usd_114": input_cost,
        "total_cost_usd_114": total_cost,
        "full_panel_input_cost_usd_114": full_input_cost,
        "full_panel_total_cost_usd_114": full_total_cost,
        "input_cost_savings": 1.0 - input_cost / full_input_cost,
        "total_cost_savings": 1.0 - total_cost / full_total_cost,
        "subset_size_counts": dict(sorted(Counter(len(row["selected_models"]) for row in traces).items())),
    }


def replay(
    all_items: list[AnnotationItem],
    matrix: dict[str, dict[str, ModelResponse]],
    model_ids: list[str],
    embedder: EmbeddingProvider,
    *,
    delta: float,
    min_models: int,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    router = make_router(model_ids, matrix, embedder, delta=delta, min_models=min_models)
    traces: list[dict[str, Any]] = []
    for round_index, item in enumerate(all_items, start=1):
        result = router.route(item)
        selected = list(result.selected_models)
        row = matrix[item.item_id]

        def cost(models: list[str], include_output: bool) -> float:
            total = 0.0
            for model in models:
                price = PRICE_SNAPSHOT[model]
                total += row[model].input_tokens * float(price["input_usd_per_million"])
                if include_output:
                    total += row[model].output_tokens * float(price["output_usd_per_million"])
            return total / 1_000_000

        traces.append(
            {
                "round": round_index,
                "case_id": item.item_id,
                "reviewed": "gold_primary_family" in item.metadata,
                "observable": bool(item.metadata.get("observable", False)),
                "gold_primary_family": item.metadata.get("gold_primary_family"),
                "acceptable_families": item.metadata.get("acceptable_families", []),
                "prediction": result.label,
                "correct_primary": (
                    result.label == item.metadata.get("gold_primary_family")
                    if "gold_primary_family" in item.metadata
                    else None
                ),
                "correct_observable": (
                    result.label in item.metadata.get("acceptable_families", [])
                    if item.metadata.get("observable", False)
                    else None
                ),
                "selected_models": selected,
                "subset_confidence": result.subset_confidence,
                "subset_feasible": len(selected) < len(model_ids),
                "selected_input_rate_usd_per_million": sum(
                    float(PRICE_SNAPSHOT[model]["input_usd_per_million"])
                    for model in selected
                ),
                "input_cost_usd": cost(selected, False),
                "total_cost_usd": cost(selected, True),
                "full_panel_input_cost_usd": cost(model_ids, False),
                "full_panel_total_cost_usd": cost(model_ids, True),
            }
        )
    return summarize(traces, len(model_ids)), traces


def full_vote_reference(
    all_items: list[AnnotationItem],
    matrix: dict[str, dict[str, ModelResponse]],
    model_ids: list[str],
) -> dict[str, Any]:
    # Paper reference: fixed weights proportional to each model's true
    # reviewed-set accuracy.  This is a post-hoc reference, never router input.
    weights = {}
    for model in model_ids:
        rows = [item for item in all_items if "gold_primary_family" in item.metadata]
        weights[model] = sum(
            matrix[item.item_id][model].label == item.metadata["gold_primary_family"]
            for item in rows
        ) / len(rows)
    traces = []
    for round_index, item in enumerate(all_items, start=1):
        totals: dict[str, float] = Counter()
        for model in model_ids:
            totals[matrix[item.item_id][model].label] += weights[model]
        maximum = max(totals.values())
        prediction = sorted(label for label, score in totals.items() if score == maximum)[0]
        traces.append(
            {
                "reviewed": "gold_primary_family" in item.metadata,
                "observable": bool(item.metadata.get("observable", False)),
                "gold_primary_family": item.metadata.get("gold_primary_family"),
                "acceptable_families": item.metadata.get("acceptable_families", []),
                "prediction": prediction,
                "selected_models": model_ids,
                "selected_input_rate_usd_per_million": sum(
                    float(PRICE_SNAPSHOT[model]["input_usd_per_million"])
                    for model in model_ids
                ),
                "input_cost_usd": sum(
                    matrix[item.item_id][model].input_tokens
                    * float(PRICE_SNAPSHOT[model]["input_usd_per_million"])
                    for model in model_ids
                ) / 1_000_000,
                "total_cost_usd": sum(
                    matrix[item.item_id][model].input_tokens
                    * float(PRICE_SNAPSHOT[model]["input_usd_per_million"])
                    + matrix[item.item_id][model].output_tokens
                    * float(PRICE_SNAPSHOT[model]["output_usd_per_million"])
                    for model in model_ids
                ) / 1_000_000,
                "full_panel_input_cost_usd": sum(
                    matrix[item.item_id][model].input_tokens
                    * float(PRICE_SNAPSHOT[model]["input_usd_per_million"])
                    for model in model_ids
                ) / 1_000_000,
                "full_panel_total_cost_usd": sum(
                    matrix[item.item_id][model].input_tokens
                    * float(PRICE_SNAPSHOT[model]["input_usd_per_million"])
                    + matrix[item.item_id][model].output_tokens
                    * float(PRICE_SNAPSHOT[model]["output_usd_per_million"])
                    for model in model_ids
                ) / 1_000_000,
            }
        )
    return {**summarize(traces, len(model_ids)), "weights": weights, "posthoc_reference": True}


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    split_items, matrix, _gold, model_ids = build_data()
    all_items = sorted(
        [item for partition in split_items.values() for item in partition],
        key=lambda item: (int(item.metadata["global_position"]), item.item_id),
    )
    if len(all_items) != 114 or any(len(matrix[item.item_id]) != 5 for item in all_items):
        raise RuntimeError("expected a complete frozen 114x5 matrix")
    if set(model_ids) != set(PRICE_SNAPSHOT):
        raise RuntimeError("price snapshot does not match frozen model pool")

    embedder = CachedEmbedder(SentenceTransformerEmbedder())
    reference = full_vote_reference(all_items, matrix, model_ids)
    reference_accuracy = float(reference["observable_family_accuracy"])
    grid: list[dict[str, Any]] = []
    traces_by_run: dict[str, list[dict[str, Any]]] = {}
    for min_models in MIN_MODELS:
        for delta in DELTAS:
            metrics, traces = replay(
                all_items,
                matrix,
                model_ids,
                embedder,
                delta=delta,
                min_models=min_models,
            )
            run_id = f"delta-{delta:.3f}_k-{min_models}"
            target = delta * reference_accuracy
            row = {
                "run_id": run_id,
                "delta": delta,
                "min_models": min_models,
                "target_observable_family_accuracy": target,
                "target_met": float(metrics["observable_family_accuracy"]) + 1e-12 >= target,
                **metrics,
            }
            grid.append(row)
            traces_by_run[run_id] = traces

    # Highest target met, then lowest input cost, then k=1.  Selection uses the
    # complete frozen grid only for this professor-facing descriptive replay.
    feasible = [row for row in grid if row["target_met"]]
    selected = sorted(
        feasible,
        key=lambda row: (
            -float(row["target_observable_family_accuracy"]),
            float(row["input_cost_usd_114"]),
            int(row["min_models"]),
        ),
    )[0]

    summary = {
        "state": "complete",
        "provider_calls": 0,
        "dataset": "Mordor official scenarios, frozen 114x5 response matrix",
        "evaluation": {
            "stream_cases": 114,
            "reviewed_cases": 47,
            "evidence_observable_cases": 20,
            "observable_coverage_of_reviewed": 20 / 47,
            "primary_accuracy_definition": (
                "fraction of evidence-observable reviewed cases whose predicted "
                "ATT&CK technique family is in the reviewed acceptable-family set"
            ),
            "target_definition": "delta times full-panel reference observable-family accuracy",
        },
        "price_snapshot_date": "2026-08-03",
        "fx_cny_per_usd": FX_CNY_PER_USD,
        "price_snapshot": PRICE_SNAPSHOT,
        "cost_notes": {
            "primary_table_cost": "mean sum of selected input USD rates per 1M tokens",
            "actual_spend": "frozen per-provider token usage times public input/output list rates",
            "cache_discount": "excluded; conservative because a future cache hit is not guaranteed",
        },
        "full_panel_reference": reference,
        "selected_run_id": selected["run_id"],
        "selected": selected,
        "grid": grid,
        "guardrail": (
            "A visually clear result is not a guarantee that CaMVo beats the best single model. "
            "All target failures remain visible in the exported table."
        ),
    }
    (OUT / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    with (OUT / "target_accuracy_cost_table.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(grid[0]))
        writer.writeheader()
        writer.writerows(grid)
    for run_id, traces in traces_by_run.items():
        with (OUT / f"traces_{run_id}.jsonl").open("w", encoding="utf-8") as handle:
            for row in traces:
                handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")

    print(json.dumps({"out": str(OUT), "selected": selected, "reference": reference}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
