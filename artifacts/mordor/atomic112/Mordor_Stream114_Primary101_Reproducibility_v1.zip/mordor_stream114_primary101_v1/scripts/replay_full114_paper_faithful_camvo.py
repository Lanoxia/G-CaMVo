#!/usr/bin/env python3
"""Paper-faithful, provider-free CaMVo replay on the frozen Mordor 114x5 matrix.

This script deliberately keeps gold labels outside the online router.  All 114
official scenarios are replayed in their frozen order; the 47 reviewed cases
are scored only after their routing decisions have been made.

The personal-provider price fields were not frozen at collection time.  The
primary run therefore gives every model the same USD-per-input-token rate.
This preserves observed tokenizer differences and exercises the paper's cost
oracle, but the resulting values are normalized cost proxies rather than
provider invoices.
"""

from __future__ import annotations

import csv
import json
from collections import Counter
from pathlib import Path
from statistics import mean
from typing import Any

import numpy as np

from camvo.config import CaMVoConfig
from camvo.embeddings.base import EmbeddingProvider
from camvo.embeddings.sentence_transformer import SentenceTransformerEmbedder
from camvo.router import CaMVoRouter
from camvo.security.formal_experiment import FrozenResponseMatrixClient
from camvo.types import AnnotationItem, ModelPricing, ModelResponse

from replay_full114_reviewed_camvo import build_data


ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "REPO/modor/results/full114_paper_faithful_camvo_20260803"
DELTAS = (0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 0.955, 0.96, 0.965, 0.97, 0.975, 0.98, 0.99)
MIN_MODELS = (1, 3)


class CachedEmbedder(EmbeddingProvider):
    def __init__(self, backend: EmbeddingProvider) -> None:
        self.backend = backend
        self.cache: dict[str, np.ndarray] = {}

    @property
    def dimension(self) -> int:
        return self.backend.dimension

    def embed(self, text: str) -> np.ndarray:
        if text not in self.cache:
            self.cache[text] = np.asarray(self.backend.embed(text), dtype=np.float64)
        return self.cache[text].copy()


class InputTokenCostClient(FrozenResponseMatrixClient):
    """Pre-call input-token cost using the frozen response token count."""

    def estimate_cost(self, item: AnnotationItem) -> float:
        response = self._responses[item.item_id]
        return self.pricing.cost(response.input_tokens, 0)


def make_router(
    model_ids: list[str],
    matrix: dict[str, dict[str, ModelResponse]],
    embedder: EmbeddingProvider,
    *,
    delta: float,
    min_models: int,
    force_full_panel: bool = False,
) -> CaMVoRouter:
    # Equal normalized input-token price for every model.  Output is ignored,
    # exactly as in the paper, because provider prices were not frozen.
    pricing = ModelPricing(input_per_million=1.0, output_per_million=0.0)
    clients = [
        InputTokenCostClient(
            model_id,
            pricing,
            {case_id: responses[model_id] for case_id, responses in matrix.items()},
        )
        for model_id in model_ids
    ]
    return CaMVoRouter(
        clients,
        embedder,
        CaMVoConfig(
            embedding_dim=384,
            confidence_threshold=delta,
            min_models=min_models,
            linucb_regularization=1.0,
            exploration_alpha=0.25,
            laplace_regularization=1.0,
            warmup_rounds=10**9 if force_full_panel else 0,
            confidence_method="beta_cdf",
            update_single_model_rounds=False,
        ),
    )


def macro_f1(gold: list[str], predicted: list[str]) -> float | None:
    labels = sorted(set(gold))
    if not labels:
        return None
    scores: list[float] = []
    for label in labels:
        tp = sum(g == label and p == label for g, p in zip(gold, predicted))
        fp = sum(g != label and p == label for g, p in zip(gold, predicted))
        fn = sum(g == label and p != label for g, p in zip(gold, predicted))
        precision = tp / (tp + fp) if tp + fp else 0.0
        recall = tp / (tp + fn) if tp + fn else 0.0
        scores.append(2 * precision * recall / (precision + recall) if precision + recall else 0.0)
    return mean(scores)


def summarize(traces: list[dict[str, Any]], model_count: int) -> dict[str, Any]:
    reviewed = [row for row in traces if row["reviewed"]]
    observable = [row for row in reviewed if row["observable"]]
    gold = [row["gold_primary_family"] for row in reviewed]
    predicted = [row["prediction"] for row in reviewed]
    calls = sum(len(row["selected_models"]) for row in traces)
    normalized_cost = sum(float(row["normalized_input_cost"]) for row in traces)
    full_cost = sum(float(row["full_panel_normalized_input_cost"]) for row in traces)
    return {
        "stream_cases": len(traces),
        "reviewed_cases": len(reviewed),
        "observable_cases": len(observable),
        "reviewed_primary_accuracy": (
            sum(g == p for g, p in zip(gold, predicted)) / len(reviewed) if reviewed else None
        ),
        "reviewed_primary_macro_f1": macro_f1(gold, predicted),
        "observable_family_hit_at_1": (
            sum(row["prediction"] in row["acceptable_families"] for row in observable)
            / len(observable)
            if observable else None
        ),
        "calls": calls,
        "full_panel_calls": len(traces) * model_count,
        "average_models": calls / len(traces),
        "call_savings": 1.0 - calls / (len(traces) * model_count),
        "normalized_input_cost": normalized_cost,
        "full_panel_normalized_input_cost": full_cost,
        "normalized_input_cost_savings": 1.0 - normalized_cost / full_cost,
        "subset_size_counts": dict(sorted(Counter(len(row["selected_models"]) for row in traces).items())),
    }


def replay(
    all_items: list[AnnotationItem],
    matrix: dict[str, dict[str, ModelResponse]],
    model_ids: list[str],
    embedder: EmbeddingProvider,
    *,
    delta: float,
    min_models: int,
    force_full_panel: bool = False,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    router = make_router(
        model_ids,
        matrix,
        embedder,
        delta=delta,
        min_models=min_models,
        force_full_panel=force_full_panel,
    )
    traces: list[dict[str, Any]] = []
    for round_index, item in enumerate(all_items, start=1):
        result = router.route(item)
        selected = list(result.selected_models)
        row = matrix[item.item_id]
        reviewed = "gold_primary_family" in item.metadata
        full_cost = sum(row[model].input_tokens for model in model_ids) / 1_000_000
        traces.append(
            {
                "round": round_index,
                "case_id": item.item_id,
                "reviewed": reviewed,
                "observable": bool(item.metadata.get("observable", False)) if reviewed else False,
                "gold_primary_family": item.metadata.get("gold_primary_family"),
                "acceptable_families": item.metadata.get("acceptable_families", []),
                "prediction": result.label,
                "selected_models": selected,
                "subset_confidence": result.subset_confidence,
                "subset_feasible": len(selected) < len(model_ids),
                "normalized_input_cost": sum(row[model].input_tokens for model in selected) / 1_000_000,
                "full_panel_normalized_input_cost": full_cost,
            }
        )
    return summarize(traces, len(model_ids)), traces


def uniform_plurality(
    all_items: list[AnnotationItem],
    matrix: dict[str, dict[str, ModelResponse]],
    model_ids: list[str],
) -> dict[str, Any]:
    traces: list[dict[str, Any]] = []
    for round_index, item in enumerate(all_items, start=1):
        counts = Counter(matrix[item.item_id][model].label for model in model_ids)
        maximum = max(counts.values())
        prediction = sorted(label for label, count in counts.items() if count == maximum)[0]
        traces.append(
            {
                "round": round_index,
                "case_id": item.item_id,
                "reviewed": "gold_primary_family" in item.metadata,
                "observable": bool(item.metadata.get("observable", False)),
                "gold_primary_family": item.metadata.get("gold_primary_family"),
                "acceptable_families": item.metadata.get("acceptable_families", []),
                "prediction": prediction,
                "selected_models": model_ids,
                "normalized_input_cost": sum(
                    matrix[item.item_id][model].input_tokens for model in model_ids
                ) / 1_000_000,
                "full_panel_normalized_input_cost": sum(
                    matrix[item.item_id][model].input_tokens for model in model_ids
                ) / 1_000_000,
            }
        )
    return summarize(traces, len(model_ids))


def weighted_full_vote(
    all_items: list[AnnotationItem],
    matrix: dict[str, dict[str, ModelResponse]],
    model_ids: list[str],
    weights: dict[str, float],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Full-panel vote with fixed weights, including the paper's oracle baseline."""

    traces: list[dict[str, Any]] = []
    for round_index, item in enumerate(all_items, start=1):
        totals: dict[str, float] = Counter()
        for model in model_ids:
            totals[matrix[item.item_id][model].label] += weights[model]
        maximum = max(totals.values())
        prediction = sorted(label for label, value in totals.items() if np.isclose(value, maximum))[0]
        full_cost = sum(matrix[item.item_id][model].input_tokens for model in model_ids) / 1_000_000
        traces.append(
            {
                "round": round_index,
                "case_id": item.item_id,
                "reviewed": "gold_primary_family" in item.metadata,
                "observable": bool(item.metadata.get("observable", False)),
                "gold_primary_family": item.metadata.get("gold_primary_family"),
                "acceptable_families": item.metadata.get("acceptable_families", []),
                "prediction": prediction,
                "selected_models": model_ids,
                "normalized_input_cost": full_cost,
                "full_panel_normalized_input_cost": full_cost,
            }
        )
    return summarize(traces, len(model_ids)), traces


def baseline_algorithm2(
    all_items: list[AnnotationItem],
    matrix: dict[str, dict[str, ModelResponse]],
    model_ids: list[str],
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    """Appendix-C Algorithm 2: query all, weight only by past consensus."""

    observations = {model: 0 for model in model_ids}
    agreements = {model: 0 for model in model_ids}
    traces: list[dict[str, Any]] = []
    for round_index, item in enumerate(all_items, start=1):
        # The pseudocode leaves t=1 undefined (0/0).  Equal weights are the
        # neutral initialization; subsequent rounds use the exact empirical
        # agreement fraction in Algorithm 2.
        weights = {
            model: agreements[model] / observations[model] if observations[model] else 1.0
            for model in model_ids
        }
        totals: dict[str, float] = Counter()
        for model in model_ids:
            totals[matrix[item.item_id][model].label] += weights[model]
        maximum = max(totals.values())
        prediction = sorted(label for label, value in totals.items() if np.isclose(value, maximum))[0]
        for model in model_ids:
            observations[model] += 1
            agreements[model] += int(matrix[item.item_id][model].label == prediction)
        full_cost = sum(matrix[item.item_id][model].input_tokens for model in model_ids) / 1_000_000
        traces.append(
            {
                "round": round_index,
                "case_id": item.item_id,
                "reviewed": "gold_primary_family" in item.metadata,
                "observable": bool(item.metadata.get("observable", False)),
                "gold_primary_family": item.metadata.get("gold_primary_family"),
                "acceptable_families": item.metadata.get("acceptable_families", []),
                "prediction": prediction,
                "selected_models": model_ids,
                "weights_before_round": weights,
                "normalized_input_cost": full_cost,
                "full_panel_normalized_input_cost": full_cost,
            }
        )
    return summarize(traces, len(model_ids)), traces


def single_model(
    model_id: str,
    all_items: list[AnnotationItem],
    matrix: dict[str, dict[str, ModelResponse]],
    model_ids: list[str],
) -> dict[str, Any]:
    traces: list[dict[str, Any]] = []
    for round_index, item in enumerate(all_items, start=1):
        traces.append(
            {
                "round": round_index,
                "case_id": item.item_id,
                "reviewed": "gold_primary_family" in item.metadata,
                "observable": bool(item.metadata.get("observable", False)),
                "gold_primary_family": item.metadata.get("gold_primary_family"),
                "acceptable_families": item.metadata.get("acceptable_families", []),
                "prediction": matrix[item.item_id][model_id].label,
                "selected_models": [model_id],
                "normalized_input_cost": matrix[item.item_id][model_id].input_tokens / 1_000_000,
                "full_panel_normalized_input_cost": sum(
                    matrix[item.item_id][model].input_tokens for model in model_ids
                ) / 1_000_000,
            }
        )
    return summarize(traces, len(model_ids))


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    split_items, matrix, _gold, model_ids = build_data()
    all_items = sorted(
        [item for partition in split_items.values() for item in partition],
        key=lambda item: (int(item.metadata["global_position"]), item.item_id),
    )
    if len(all_items) != 114 or any(len(matrix[item.item_id]) != 5 for item in all_items):
        raise RuntimeError("expected a complete frozen 114x5 matrix")

    embedder = CachedEmbedder(SentenceTransformerEmbedder())

    uniform_full = uniform_plurality(all_items, matrix, model_ids)
    singles = {model: single_model(model, all_items, matrix, model_ids) for model in model_ids}
    oracle_weights = {
        model: float(singles[model]["reviewed_primary_accuracy"]) for model in model_ids
    }
    oracle_full, oracle_full_traces = weighted_full_vote(
        all_items, matrix, model_ids, oracle_weights
    )
    algorithm2, algorithm2_traces = baseline_algorithm2(all_items, matrix, model_ids)

    grid: list[dict[str, Any]] = []
    traces_by_run: dict[str, list[dict[str, Any]]] = {}
    for min_models in MIN_MODELS:
        for delta in DELTAS:
            metrics, traces = replay(
                all_items,
                matrix,
                model_ids,
                embedder,
                delta=delta,
                min_models=min_models,
            )
            run_id = f"delta-{delta:.3f}_k-{min_models}"
            target = delta * float(oracle_full["reviewed_primary_accuracy"])
            grid.append(
                {
                    "run_id": run_id,
                    "delta": delta,
                    "min_models": min_models,
                    "target_vs_majority_vote": target,
                    "target_met_on_reviewed_primary": (
                        float(metrics["reviewed_primary_accuracy"]) + 1e-12 >= target
                    ),
                    **metrics,
                }
            )
            traces_by_run[run_id] = traces

    summary = {
        "state": "complete",
        "provider_calls": 0,
        "algorithm": "paper-faithful CaMVo mechanics",
        "stream": "all 114 frozen official scenarios in frozen prompt order",
        "reviewed_posthoc_only": 47,
        "observable_posthoc_only": 20,
        "models": model_ids,
        "paper_parameters": {
            "embedder": "sentence-transformers/all-MiniLM-L6-v2",
            "embedding_dim": 384,
            "exploration_alpha": 0.25,
            "linucb_regularization": 1.0,
            "laplace_regularization": 1.0,
            "confidence_method": "beta_cdf",
            "warmup_rounds": 0,
            "gold_feedback": False,
            "update_single_model_rounds": False,
            "deltas": list(DELTAS),
            "min_models": list(MIN_MODELS),
        },
        "cost_semantics": {
            "kind": "normalized input-token cost",
            "rates": "all models = 1 normalized unit / million input tokens",
            "output_tokens_ignored": True,
            "why_not_usd": "personal-provider price fields were null at collection time",
        },
        "majority_vote_true_accuracy_weighted_reference": {
            **oracle_full,
            "weights_from_reviewed_primary_accuracy": oracle_weights,
            "posthoc_oracle_only": True,
        },
        "baseline_algorithm2_online_weighted_majority": algorithm2,
        "uniform_full_panel_descriptive": uniform_full,
        "single_model_descriptive": singles,
        "grid": grid,
        "interpretation_guardrail": (
            "CaMVo target accuracy is delta times the paper-style true-accuracy-weighted "
            "full-panel Majority Vote. The paper does not guarantee higher raw accuracy "
            "than the best single model."
        ),
    }
    (OUT / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    fields = list(grid[0])
    with (OUT / "grid.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(grid)
    with (OUT / "majority_vote_oracle_weighted_traces.jsonl").open("w", encoding="utf-8") as handle:
        for row in oracle_full_traces:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    with (OUT / "baseline_algorithm2_traces.jsonl").open("w", encoding="utf-8") as handle:
        for row in algorithm2_traces:
            handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")
    for run_id, traces in traces_by_run.items():
        with (OUT / f"traces_{run_id}.jsonl").open("w", encoding="utf-8") as handle:
            for row in traces:
                handle.write(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n")

    print(json.dumps({
        "out": str(OUT),
        "majority_vote_oracle_weighted": oracle_full,
        "baseline_algorithm2": algorithm2,
        "grid": grid,
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
