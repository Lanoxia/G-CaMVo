#!/usr/bin/env python3
"""Reproduce the online-weighted full-panel baseline for the Mordor-114 pilot.

This script makes no provider calls. It reads the frozen five-model response
matrix, applies the CaMVo-paper Algorithm 2 full-panel update, and scores only
the 101 primary benchmark scenarios while all 114 rounds remain in the stream.
"""

from __future__ import annotations

import csv
import json
from pathlib import Path

from replay_full114_official_tactic_camvo import build_data
from replay_full114_paper_faithful_camvo import baseline_algorithm2
from replay_stream114_primary101_camvo import score_primary


ROOT = Path(__file__).resolve().parents[2]
STATIC_SUMMARY = ROOT / "outputs/Mordor_CaMVo_Professor_Reply_StreamCalibrated_Audited_20260805/summary.json"
OUT = ROOT / "repo/modor/results/stream114_online_full_vote_followup_20260807"


def main() -> int:
    items, matrix, gold, model_ids = build_data()
    _summary, traces = baseline_algorithm2(items, matrix, model_ids)
    correct, scored, accuracy = score_primary(traces, gold)
    static = json.loads(STATIC_SUMMARY.read_text(encoding="utf-8"))
    full_cost = float(static["full_vote"]["estimated_token_cost_usd_114_stream"])
    selected = static["selected_operating_point"]
    result = {
        "state": "complete",
        "provider_calls": 0,
        "stream_rounds": len(items),
        "primary_scored_rounds": scored,
        "baseline": "CaMVo paper Appendix-C Algorithm 2 full-panel weighted majority",
        "weight_update": "equal initialization; past agreement with assigned aggregate consensus only",
        "current_or_future_gold_used_for_weight_update": False,
        "online_full_vote": {
            "correct": correct,
            "accuracy": accuracy,
            "calls": len(items) * len(model_ids),
            "average_models_per_round": float(len(model_ids)),
            "estimated_cost_usd_114_stream": full_cost,
            "initial_weights": traces[0]["weights_before_round"],
            "weights_before_final_round": traces[-1]["weights_before_round"],
        },
        "static_ground_truth_weighted_reference": static["full_vote"],
        "camvo_selected_pilot_point": {
            "delta": selected["delta"],
            "k_min": selected["min_models"],
            "correct": selected["primary_correct"],
            "accuracy": selected["primary_accuracy"],
            "average_models_per_round": selected["average_models_per_stream_round"],
            "estimated_cost_usd_114_stream": selected["estimated_token_cost_usd_114_stream"],
            "cost_saving_vs_online_full_vote": 1.0 - float(selected["estimated_token_cost_usd_114_stream"]) / full_cost,
        },
    }
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT / "summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with (OUT / "online_full_vote_round_traces.jsonl").open("w", encoding="utf-8") as handle:
        for trace in traces:
            row = dict(trace)
            row["official_use"] = gold[row["case_id"]]["official_use"]
            row["primary_scored"] = row["official_use"] == "primary_benchmark"
            handle.write(json.dumps(row, ensure_ascii=False) + "\n")

    comparison_rows = [
        {
            "method": "Online-weighted full vote",
            "correct": correct,
            "scored_scenarios": scored,
            "accuracy": accuracy,
            "estimated_cost_usd_114_stream": full_cost,
            "average_models_per_round": float(len(model_ids)),
            "cost_saving_vs_online_full_vote": 0.0,
        },
        {
            "method": "Static ground-truth-weighted full vote (post-hoc)",
            "correct": static["full_vote"]["primary_correct"],
            "scored_scenarios": static["full_vote"]["primary_scenarios"],
            "accuracy": static["full_vote"]["primary_accuracy"],
            "estimated_cost_usd_114_stream": full_cost,
            "average_models_per_round": float(len(model_ids)),
            "cost_saving_vs_online_full_vote": 0.0,
        },
        {
            "method": "CaMVo delta=0.80 k_min=3",
            "correct": selected["primary_correct"],
            "scored_scenarios": selected["primary_scenarios"],
            "accuracy": selected["primary_accuracy"],
            "estimated_cost_usd_114_stream": selected["estimated_token_cost_usd_114_stream"],
            "average_models_per_round": selected["average_models_per_stream_round"],
            "cost_saving_vs_online_full_vote": result["camvo_selected_pilot_point"]["cost_saving_vs_online_full_vote"],
        },
    ]
    with (OUT / "online_baseline_comparison.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(comparison_rows[0]))
        writer.writeheader()
        writer.writerows(comparison_rows)
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
