# Mordor Large-232 One-View V1 正式候选集

生成日期：2026-08-05  
上游数据：`mordor_large1121_v2`  
生成脚本：`repo/modor/freeze_mordor_large1121_one_view_v1.py`

## 这一步解决了什么

上游 1,121 条数据包含同一在线决策锚点的多种上下文长度，适合比较 Prompt 表示，
不适合直接作为 1,121 个独立样本报告。本目录在任何新增模型调用之前，为每个锚点
冻结一个且仅一个输入，使实验分母回到真实的在线决策次数。

## 冻结规则

规则完全不读取模型回答或官方 gold：

1. 锚点存在 `context_06` 时固定使用该视图；
2. 不存在 `context_06` 时使用 `anchor_only`；
3. 当前仅有3个 fallback，它们均为各自流中的首事件（`e001`），没有可用的过去事件。

规则来源于冻结前的配对诊断：在同一批 Tier-A anchors 上，DeepSeek V4 Flash 的
`context_06` strict technique Top-1 为47.4%，高于 anchor-only、context-10 和
context-16。该选择在补齐其他模型及正式 test 之前完成，后续不得按模型或测试结果
为不同样本切换上下文。

## 规模和划分

| 项目 | 数量 |
|---|---:|
| Online decision anchors / bundles | 232 |
| Source groups | 58 |
| Atomic reviewed anchors | 171 |
| Compound aligned-step anchors | 61 |
| `context_06` | 229 |
| `anchor_only` no-history fallback | 3 |
| Events | 1,369 |
| Relations | 1,319 |
| Five-model response cells | 1,160 |

| Split | Anchors | Source groups | 用途 |
|---|---:|---:|---|
| Calibration | 29 | 11 | 参数估计 |
| Validation | 30 | 11 | 冻结运行点 |
| Test | 112 | 32 | 一次性主评估 |
| Compound stress | 61 | 4 | 独立压力测试 |

同一个 source group 只属于一个 split。Compound campaign 不进入 atomic 主结果分母。

## 在线和防泄漏审计

- `past_only_validated=true`；
- 所有事件不晚于当前 `decision_time`；
- 官方标签不在模型 Prompt 中；
- 选择规则不使用模型回答；
- 选择规则不使用 evaluator gold；
- source-group split leakage 为0；
- 混合 Unix 秒和 ISO-8601 时间已统一解析为UTC后排序；
- 自动测试6项通过（包含上游 Large-1121 契约测试）。

## 文件

- `prompt_instances_one_view_v1.jsonl`：可发给模型的232个冻结输入；
- `case_list_one_view_v1.jsonl`：完整 case list；
- `case_list_{split}_one_view_v1.jsonl`：分区清单；
- `bundle_audit_one_view_v1.jsonl`：past-only与锚点审计；
- `evaluator_gold_DO_NOT_SEND_one_view_v1.jsonl`：评估器专用，禁止进入Prompt；
- `summary_one_view_v1.json`：规模、分层、哈希与约束摘要；
- `MANIFEST.json`：冻结文件哈希。
- `reusable_deepseek_flash_responses.jsonl`：从旧 Large-1121 运行中按完全相同 case ID
  提取的合法 DeepSeek V4 Flash 回答；
- `reusable_response_summary.json`：缓存来源哈希、分区覆盖和冲突审计。

## 下一门槛

先在 calibration 的小型五模型矩阵上验证模型互补性、strict primary technique、
acceptable-technique hit、证据支持、成本与输出稳定性。该口径直接对应教授 PPT 中
Mordor 的 ATT&CK technique accuracy、evidence support 和 scenario-level correctness。
门槛通过后才进入 validation 冻结 CaMVo 运行点，最后一次性运行 test；所有分析复用
冻结回答，不重复发起模型调用。
