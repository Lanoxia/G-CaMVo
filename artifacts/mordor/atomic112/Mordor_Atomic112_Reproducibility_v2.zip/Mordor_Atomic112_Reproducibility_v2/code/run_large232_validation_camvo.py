#!/usr/bin/env python3
"""Select the frozen Large-232 CaMVo operating point on validation only."""

from __future__ import annotations

import csv
import argparse
import json
from collections import Counter
from pathlib import Path
from statistics import mean

import numpy as np

from camvo.config import CaMVoConfig
from camvo.embeddings.base import EmbeddingProvider
from camvo.embeddings.sentence_transformer import SentenceTransformerEmbedder
from camvo.router import CaMVoRouter
from camvo.security.formal_experiment import FrozenResponseMatrixClient
from camvo.types import AnnotationItem, ModelPricing, ModelResponse


ROOT = Path(__file__).resolve().parents[2]
DATA = ROOT / "repo/modor/data/mordor_large232_one_view_v1"
CAL_RUN = ROOT / "repo/modor/runs/mordor_large232_calibration_gate_20260805"
VAL_RUN = ROOT / "repo/modor/runs/mordor_large232_validation_matrix_20260805"
OUT_BASE = ROOT / "repo/modor/results"
PRICE_PATH = ROOT / "repo/modor/price_snapshot_20260805.json"
MODELS = (
    "deepseek-v4-flash",
    "deepseek-v4-pro",
    "gemini-3.5-flash-lite",
    "glm-5.2",
    "minimax-m3",
)
DELTAS = (0.70, 0.75, 0.80, 0.85, 0.90, 0.95, 0.97, 0.99)
K_MINS = (1, 3)


def read_jsonl(path: Path) -> list[dict]:
    return [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]


def token_usage(row: dict, *names: str) -> int:
    usage = row.get("metadata", {}).get("usage", {}) or {}
    for name in names:
        if usage.get(name) is not None:
            return int(usage[name])
    return 0


class CachedEmbedder(EmbeddingProvider):
    def __init__(self) -> None:
        self.backend = SentenceTransformerEmbedder()
        self.cache: dict[str, np.ndarray] = {}

    @property
    def dimension(self) -> int:
        return self.backend.dimension

    def embed(self, text: str) -> np.ndarray:
        if text not in self.cache:
            self.cache[text] = np.asarray(self.backend.embed(text), dtype=np.float64)
        return self.cache[text].copy()


class PreCallCostClient(FrozenResponseMatrixClient):
    """Estimate before calling from known input length plus calibration mean output."""

    def __init__(self, *args, expected_output_tokens: float, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.expected_output_tokens = expected_output_tokens

    def estimate_cost(self, item: AnnotationItem) -> float:
        row = self._responses[item.item_id]
        return self.pricing.cost(row.input_tokens, round(self.expected_output_tokens))


def load_prices() -> dict[str, ModelPricing]:
    raw = json.loads(PRICE_PATH.read_text(encoding="utf-8"))["models"]
    result = {}
    for model in MODELS:
        row = raw[model]
        input_price = row.get("input", row.get("input_cache_miss"))
        result[model] = ModelPricing(float(input_price), float(row["output"]))
    return result


def load_split_ids(split: str) -> list[str]:
    return [row["case_id"] for row in read_jsonl(DATA / f"case_list_{split}_one_view_v1.jsonl")]


def response_map(run_root: Path, case_ids: list[str]) -> dict[str, dict[str, dict]]:
    matrix = {case_id: {} for case_id in case_ids}
    for model in MODELS:
        slug = model
        rows = read_jsonl(run_root / slug / "responses.jsonl")
        values = {row["case_id"]: row for row in rows}
        if set(values) != set(case_ids) or len(rows) != len(case_ids):
            raise ValueError(f"incomplete or duplicate {run_root.name}/{model}")
        for case_id in case_ids:
            matrix[case_id][model] = values[case_id]
    return matrix


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--calibration-feedback",
        choices=("consensus", "gold"),
        default="consensus",
        help="Gold is a supervised calibration extension; validation/test remain evaluator-only.",
    )
    args = parser.parse_args()
    OUT = OUT_BASE / (
        "mordor_large232_validation_camvo_20260805"
        if args.calibration_feedback == "consensus"
        else "mordor_large232_validation_calibrated_camvo_20260805"
    )
    OUT.mkdir(parents=True, exist_ok=True)
    cal_ids = load_split_ids("calibration")
    val_ids = load_split_ids("validation")
    prompts = {row["case_id"]: row for row in read_jsonl(DATA / "prompt_instances_one_view_v1.jsonl")}
    gold = {row["case_id"]: row for row in read_jsonl(DATA / "evaluator_gold_DO_NOT_SEND_one_view_v1.jsonl")}
    cal = response_map(CAL_RUN, cal_ids)
    val = response_map(VAL_RUN, val_ids)
    all_rows = {**cal, **val}

    label_universe = {"INSUFFICIENT"}
    for case_id in cal_ids + val_ids:
        label_universe.add(str(gold[case_id]["primary_vote_label"]).upper())
        label_universe.update(str(x).upper() for x in gold[case_id]["acceptable_technique_labels"])
        label_universe.update(
            str(all_rows[case_id][model]["prediction"]["primary_vote_label"]).upper()
            for model in MODELS
        )
    labels = tuple(sorted(label_universe))

    items = {}
    for position, case_id in enumerate(cal_ids + val_ids, start=1):
        prompt = prompts[case_id]
        text = json.dumps(
            {"events": prompt["events"], "relations": prompt["relations"]},
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        items[case_id] = AnnotationItem(
            item_id=case_id,
            text=text,
            labels=labels,
            metadata={"position": position, "split": "calibration" if case_id in set(cal_ids) else "validation"},
        )

    prices = load_prices()
    expected_output = {
        model: mean(token_usage(cal[c][model], "completion_tokens", "candidatesTokenCount") for c in cal_ids)
        for model in MODELS
    }
    responses = {
        model: {
            case_id: ModelResponse(
                label=str(all_rows[case_id][model]["prediction"]["primary_vote_label"]).upper(),
                input_tokens=token_usage(all_rows[case_id][model], "prompt_tokens", "promptTokenCount"),
                output_tokens=token_usage(all_rows[case_id][model], "completion_tokens", "candidatesTokenCount"),
                raw=all_rows[case_id][model],
            )
            for case_id in cal_ids + val_ids
        }
        for model in MODELS
    }

    cal_correct = {
        model: sum(responses[model][case_id].label == str(gold[case_id]["primary_vote_label"]).upper() for case_id in cal_ids)
        for model in MODELS
    }
    calibration_weights = {model: (cal_correct[model] + 1) / (len(cal_ids) + 2) for model in MODELS}

    def score(predictions: dict[str, str], selected: dict[str, list[str]]) -> dict:
        correct = sum(predictions[c] == str(gold[c]["primary_vote_label"]).upper() for c in val_ids)
        cost = sum(sum(prices[m].cost(responses[m][c].input_tokens, responses[m][c].output_tokens) for m in selected[c]) for c in val_ids)
        full_cost = sum(sum(prices[m].cost(responses[m][c].input_tokens, responses[m][c].output_tokens) for m in MODELS) for c in val_ids)
        calls = sum(len(selected[c]) for c in val_ids)
        return {
            "correct": correct,
            "items": len(val_ids),
            "strict_accuracy": correct / len(val_ids),
            "actual_cost_usd": cost,
            "cost_usd_per_1k": cost / len(val_ids) * 1000,
            "saving_vs_full": 1 - cost / full_cost,
            "average_models": calls / len(val_ids),
            "calls": calls,
        }

    single = {}
    for model in MODELS:
        single[model] = score(
            {c: responses[model][c].label for c in val_ids},
            {c: [model] for c in val_ids},
        )

    def full_vote(weights: dict[str, float]) -> tuple[dict, dict[str, str]]:
        predictions = {}
        for case_id in val_ids:
            totals = Counter()
            for model in MODELS:
                totals[responses[model][case_id].label] += weights[model]
            best = max(totals.values())
            predictions[case_id] = sorted(k for k, value in totals.items() if np.isclose(value, best))[0]
        return score(predictions, {c: list(MODELS) for c in val_ids}), predictions

    unweighted, _ = full_vote({model: 1.0 for model in MODELS})
    weighted, weighted_predictions = full_vote(calibration_weights)

    embedder = CachedEmbedder()
    grid = []
    trace_by_run = {}
    for k_min in K_MINS:
        for delta in DELTAS:
            clients = [
                PreCallCostClient(
                    model,
                    prices[model],
                    responses[model],
                    expected_output_tokens=expected_output[model],
                )
                for model in MODELS
            ]
            router = CaMVoRouter(
                clients,
                embedder,
                CaMVoConfig(
                    embedding_dim=embedder.dimension,
                    confidence_threshold=delta,
                    min_models=k_min,
                    linucb_regularization=1.0,
                    exploration_alpha=0.25,
                    laplace_regularization=1.0,
                    warmup_rounds=len(cal_ids),
                    confidence_method="beta_cdf",
                    update_single_model_rounds=False,
                ),
            )
            for case_id in cal_ids:
                if args.calibration_feedback == "gold":
                    router.observe_complete_feedback(
                        items[case_id],
                        {model: responses[model][case_id] for model in MODELS},
                        str(gold[case_id]["primary_vote_label"]).upper(),
                    )
                else:
                    router.route(items[case_id])
            predictions = {}
            selected = {}
            traces = []
            for round_index, case_id in enumerate(val_ids, start=1):
                result = router.route(items[case_id])
                predictions[case_id] = result.label
                selected[case_id] = list(result.selected_models)
                traces.append({
                    "round": round_index,
                    "case_id": case_id,
                    "prediction": result.label,
                    "gold": str(gold[case_id]["primary_vote_label"]).upper(),
                    "correct": result.label == str(gold[case_id]["primary_vote_label"]).upper(),
                    "selected_models": list(result.selected_models),
                    "subset_confidence": result.subset_confidence,
                    "actual_cost_usd": result.actual_cost,
                })
            metrics = score(predictions, selected)
            target = delta * weighted["strict_accuracy"]
            run_id = f"delta-{delta:.2f}_k-{k_min}"
            row = {
                "run_id": run_id,
                "delta": delta,
                "k_min": k_min,
                "target_accuracy": target,
                "target_met": metrics["strict_accuracy"] + 1e-12 >= target,
                **metrics,
            }
            grid.append(row)
            trace_by_run[run_id] = traces

    best_single_accuracy = max(row["strict_accuracy"] for row in single.values())
    eligible = [
        row for row in grid
        if row["strict_accuracy"] + 1e-12 >= best_single_accuracy
        and row["strict_accuracy"] + 1e-12 >= weighted["strict_accuracy"] - 0.02
        and row["saving_vs_full"] > 0
    ]
    eligible.sort(key=lambda row: (row["actual_cost_usd"], -row["strict_accuracy"], row["delta"], row["k_min"]))
    selected_point = eligible[0] if eligible else None

    summary = {
        "schema_version": 1,
        "state": "complete",
        "provider_calls": 0,
        "calibration_feedback": args.calibration_feedback,
        "method_name": (
            "CaMVo"
            if args.calibration_feedback == "consensus"
            else "Calibrated-CaMVo (supervised warm-start extension)"
        ),
        "split": "validation",
        "calibration_items": len(cal_ids),
        "validation_items": len(val_ids),
        "models": list(MODELS),
        "calibration_strict_correct": cal_correct,
        "calibration_laplace_weights": calibration_weights,
        "expected_output_tokens_from_calibration": expected_output,
        "single_models": single,
        "unweighted_full_vote": unweighted,
        "calibration_weighted_full_vote": weighted,
        "grid": grid,
        "selection_rule": "lowest validation cost with accuracy >= strongest single and >= weighted full vote - 2pp, and positive saving",
        "selected_operating_point": selected_point,
        "gate_passed": selected_point is not None,
        "guardrail": "Validation chooses once; atomic test remains untouched and cannot change this selection.",
    }
    (OUT / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    with (OUT / "validation_grid.csv").open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(grid[0]))
        writer.writeheader()
        writer.writerows(grid)
    for run_id, traces in trace_by_run.items():
        (OUT / f"traces_{run_id}.jsonl").write_text(
            "".join(json.dumps(row, ensure_ascii=False, separators=(",", ":")) + "\n" for row in traces),
            encoding="utf-8",
        )
    report = [
        "# Mordor Large-232 Validation CaMVo 门控",
        "",
        f"- Validation：{len(val_ids)} anchors；本分析不产生provider calls。",
        f"- 最强单模型：{best_single_accuracy:.1%}。",
        f"- Calibration-weighted full vote：{weighted['strict_accuracy']:.1%}，成本 ${weighted['cost_usd_per_1k']:.2f}/1K。",
        f"- Gate passed：{'yes' if selected_point else 'no'}。",
    ]
    if selected_point:
        report += [
            f"- 冻结运行点：delta={selected_point['delta']:.2f}, k_min={selected_point['k_min']}。",
            f"- Validation strict：{selected_point['strict_accuracy']:.1%}；成本 ${selected_point['cost_usd_per_1k']:.2f}/1K；节省 {selected_point['saving_vs_full']:.1%}。",
        ]
    (OUT / "VALIDATION_REPORT_ZH.md").write_text("\n".join(report) + "\n", encoding="utf-8")
    print(json.dumps({"out": str(OUT), "gate_passed": selected_point is not None, "selected": selected_point}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
