"""Explicit, non-logging API credential loader."""

from __future__ import annotations

import os
from pathlib import Path

try:
    from dotenv import load_dotenv
except ModuleNotFoundError:
    def load_dotenv(path: str | Path, *, override: bool = False) -> bool:
        """Minimal fallback for restricted Notebook environments."""

        loaded = False
        for raw_line in Path(path).read_text(encoding="utf-8").splitlines():
            line = raw_line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            name, value = line.split("=", 1)
            name = name.strip()
            value = value.strip()
            if value[:1] == value[-1:] and value[:1] in {"'", '"'}:
                value = value[1:-1]
            if name and (override or name not in os.environ):
                os.environ[name] = value
                loaded = True
        return loaded

KNOWN_API_KEY_NAMES = (
    "OPENAI_API_KEY",
    "ANTHROPIC_API_KEY",
    "GOOGLE_API_KEY",
    "OPENROUTER_API_KEY",
    "AZURE_OPENAI_API_KEY",
    "AZURE_OPENAI_ENDPOINT",
    "CUSTOM_LLM_BASE_URL",
    "CUSTOM_LLM_API_KEY",
    "INTERNAL_LLM_API_KEY",
    "DIFY_WORKFLOW_API_KEY",
    "ADAMS_PLATFORM_USER",
    "ADAMS_USER_TOKEN",
)


def load_api_keys(
    path: str | Path = "config/api_keys.env",
    *,
    override: bool = False,
) -> dict[str, str]:
    """Load the dedicated local key file and return only configured values.

    This function never prints values and checkpoints never include them.
    """

    key_file = Path(path)
    if key_file.exists():
        load_dotenv(key_file, override=override)
    return {name: os.environ[name] for name in KNOWN_API_KEY_NAMES if os.environ.get(name)}
