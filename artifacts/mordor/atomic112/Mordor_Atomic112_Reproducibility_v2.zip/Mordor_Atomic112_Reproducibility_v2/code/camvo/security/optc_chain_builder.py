"""Build a frozen OpTC attack-chain manifest from local eCAR shards.

The builder makes one streaming pass over each attack/benign corpus into a
compact SQLite index.  All subsequent anchor selection and past-only graph
queries are local and deterministic.  No model or network call is involved.
"""

from __future__ import annotations

import hashlib
import heapq
import json
import math
import sqlite3
import time
from collections import Counter, defaultdict
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Iterable, Iterator

from camvo.security.optc import (
    OptcAttackLabel,
    OptcEvent,
    iter_optc_events,
    load_optc_attack_labels,
    load_optc_scenarios,
)
from camvo.security.optc_chain_dataset import (
    estimate_optc_chain_record_tokens,
    load_optc_chain_dataset,
)

_SUPPORTED_SUFFIXES = (
    ".json",
    ".jsonl",
    ".ndjson",
    ".json.gz",
    ".jsonl.gz",
    ".ndjson.gz",
)
_PROPERTY_ALLOWLIST = frozenset(
    {
        "acuity_level",
        "command_line",
        "dest_ip",
        "dest_port",
        "direction",
        "file_path",
        "image_path",
        "key",
        "l4protocol",
        "module_path",
        "path",
        "reg_key",
        "reg_value",
        "src_ip",
        "src_port",
        "target_path",
        "value",
    }
)
_HARD_NEGATIVE_PAIRS = frozenset(
    {
        ("PROCESS", "CREATE"),
        ("SHELL", "COMMAND"),
        ("REGISTRY", "ADD"),
        ("REGISTRY", "MODIFY"),
        ("THREAD", "REMOTE_CREATE"),
        ("FLOW", "START"),
        ("FLOW", "MESSAGE"),
        ("FILE", "CREATE"),
        ("FILE", "WRITE"),
        ("MODULE", "LOAD"),
    }
)


@dataclass(frozen=True, slots=True)
class OptcChainBuildConfig:
    attack_path: Path
    benign_path: Path
    labels_path: Path
    scenario_manifest: Path
    output_path: Path
    stage_db_path: Path
    scenario_id: str = "optc-day3-malicious-upgrade"
    target_items: int = 1_200
    seed: int = 17
    history_minutes: int = 5
    hops: int = 2
    group_minutes: int = 30
    max_nodes: int = 100
    max_edges: int = 250
    max_estimated_tokens: int = 12_000
    utc_offset_minutes: int = -240
    padding_minutes: int = 10
    manifest_version: str = "optc-chain-v1"
    checksum_mode: str = "full"
    overwrite: bool = False
    rebuild_stage: bool = False

    def __post_init__(self) -> None:
        if self.target_items < 3:
            raise ValueError("target_items must be at least 3")
        for name in (
            "history_minutes",
            "hops",
            "group_minutes",
            "max_nodes",
            "max_edges",
            "max_estimated_tokens",
        ):
            if int(getattr(self, name)) <= 0:
                raise ValueError(f"{name} must be positive")
        if self.checksum_mode not in {"full", "stat"}:
            raise ValueError("checksum_mode must be 'full' or 'stat'")
        if not self.manifest_version.strip():
            raise ValueError("manifest_version must not be empty")


@dataclass(frozen=True, slots=True)
class _IndexedEvent:
    corpus: str
    event_id: str
    timestamp_ms: int
    hostname: str
    object_id: str
    object_type: str
    action: str
    actor_id: str
    pid: int | None
    ppid: int | None
    principal: str | None
    properties: dict[str, Any]
    source_path: str
    source_line: int

    @classmethod
    def from_row(cls, row: sqlite3.Row) -> "_IndexedEvent":
        properties = json.loads(str(row["properties_json"]))
        if not isinstance(properties, dict):
            raise ValueError("indexed properties_json must contain an object")
        return cls(
            corpus=str(row["corpus"]),
            event_id=str(row["event_id"]),
            timestamp_ms=int(row["timestamp_ms"]),
            hostname=str(row["hostname"]),
            object_id=str(row["object_id"]),
            object_type=str(row["object_type"]),
            action=str(row["action"]),
            actor_id=str(row["actor_id"]),
            pid=None if row["pid"] is None else int(row["pid"]),
            ppid=None if row["ppid"] is None else int(row["ppid"]),
            principal=None if row["principal"] is None else str(row["principal"]),
            properties=properties,
            source_path=str(row["source_path"]),
            source_line=int(row["source_line"]),
        )


def _stable_rank(seed: int, value: str) -> int:
    digest = hashlib.sha256(f"{seed}:{value}".encode("utf-8")).digest()
    return int.from_bytes(digest[:8], "big")


def _discover_source_files(path: Path) -> list[Path]:
    if path.is_file():
        return [path]
    if not path.is_dir():
        raise FileNotFoundError(f"OpTC source path does not exist: {path}")
    files = [
        candidate
        for candidate in path.rglob("*")
        if candidate.is_file()
        and any(candidate.name.casefold().endswith(suffix) for suffix in _SUPPORTED_SUFFIXES)
    ]
    if not files:
        raise FileNotFoundError(f"no supported OpTC files found under {path}")
    return sorted(files)


def _source_inventory(paths: Iterable[Path]) -> list[dict[str, object]]:
    inventory: list[dict[str, object]] = []
    for path in paths:
        stat = path.stat()
        inventory.append(
            {
                "path": str(path.resolve()),
                "size": stat.st_size,
                "mtime_ns": stat.st_mtime_ns,
            }
        )
    return inventory


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_properties(properties: dict[str, Any]) -> dict[str, object]:
    safe: dict[str, object] = {}
    for key in sorted(_PROPERTY_ALLOWLIST.intersection(properties)):
        value = properties[key]
        if value is None or isinstance(value, (bool, int, float)):
            safe[key] = value
        elif isinstance(value, str):
            safe[key] = value[:500]
        else:
            encoded = json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)
            safe[key] = encoded[:500]
    return safe


def _event_row(corpus: str, event: OptcEvent) -> tuple[object, ...]:
    return (
        corpus,
        event.event_id,
        event.timestamp_ms,
        event.hostname,
        event.object_id,
        event.object_type,
        event.action,
        event.actor_id,
        event.pid,
        event.ppid,
        event.principal,
        json.dumps(
            _safe_properties(event.properties),
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        ),
        event.source_path,
        event.source_line,
    )


def _open_stage(path: Path) -> sqlite3.Connection:
    path.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(path)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA journal_mode=WAL")
    connection.execute("PRAGMA synchronous=NORMAL")
    connection.executescript(
        """
        CREATE TABLE IF NOT EXISTS metadata (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS events (
            corpus TEXT NOT NULL,
            event_id TEXT NOT NULL,
            timestamp_ms INTEGER NOT NULL,
            hostname TEXT NOT NULL,
            object_id TEXT NOT NULL,
            object_type TEXT NOT NULL,
            action TEXT NOT NULL,
            actor_id TEXT NOT NULL,
            pid INTEGER,
            ppid INTEGER,
            principal TEXT,
            properties_json TEXT NOT NULL,
            source_path TEXT NOT NULL,
            source_line INTEGER NOT NULL,
            PRIMARY KEY (corpus, event_id)
        );
        """
    )
    return connection


def _metadata(connection: sqlite3.Connection, key: str) -> str | None:
    row = connection.execute("SELECT value FROM metadata WHERE key = ?", (key,)).fetchone()
    return None if row is None else str(row["value"])


def _set_metadata(connection: sqlite3.Connection, key: str, value: object) -> None:
    encoded = (
        value
        if isinstance(value, str)
        else json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    )
    connection.execute(
        "INSERT OR REPLACE INTO metadata(key, value) VALUES (?, ?)",
        (key, encoded),
    )


def _stage_signature(
    config: OptcChainBuildConfig,
    *,
    hosts: tuple[str, ...],
    attack_start_ms: int,
    attack_end_ms: int,
    attack_files: list[Path],
    benign_files: list[Path],
) -> str:
    payload = {
        "schema": 1,
        "attack": _source_inventory(attack_files),
        "benign": _source_inventory(benign_files),
        "hosts": hosts,
        "attack_start_ms": attack_start_ms,
        "attack_end_ms": attack_end_ms,
        "history_minutes": config.history_minutes,
        "property_allowlist": sorted(_PROPERTY_ALLOWLIST),
        "scenario_id": config.scenario_id,
    }
    encoded = json.dumps(
        payload,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def _insert_events(
    connection: sqlite3.Connection,
    *,
    corpus: str,
    events: Iterator[OptcEvent],
    progress_every: int = 100_000,
) -> dict[str, int]:
    statement = """
        INSERT OR IGNORE INTO events(
            corpus, event_id, timestamp_ms, hostname, object_id, object_type,
            action, actor_id, pid, ppid, principal, properties_json,
            source_path, source_line
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """
    batch: list[tuple[object, ...]] = []
    seen = 0
    before = connection.total_changes
    for event in events:
        batch.append(_event_row(corpus, event))
        seen += 1
        if len(batch) >= 2_000:
            connection.executemany(statement, batch)
            connection.commit()
            batch.clear()
        if progress_every and seen % progress_every == 0:
            inserted = connection.total_changes - before
            print(f"stage corpus={corpus} seen={seen} inserted={inserted}", flush=True)
    if batch:
        connection.executemany(statement, batch)
        connection.commit()
    return {"seen": seen, "inserted": connection.total_changes - before}


def _prepare_stage(
    connection: sqlite3.Connection,
    config: OptcChainBuildConfig,
    *,
    hosts: tuple[str, ...],
    attack_start_ms: int,
    attack_end_ms: int,
    signature: str,
    attack_files: list[Path],
    benign_files: list[Path],
) -> dict[str, object]:
    if (
        not config.rebuild_stage
        and _metadata(connection, "complete") == "true"
        and _metadata(connection, "signature") == signature
    ):
        raw_stats = _metadata(connection, "stats")
        return {
            "reused": True,
            "signature": signature,
            "stats": {} if raw_stats is None else json.loads(raw_stats),
        }

    existing_signature = _metadata(connection, "signature")
    if config.rebuild_stage or existing_signature != signature:
        connection.executescript(
            """
            DROP INDEX IF EXISTS idx_events_time;
            DROP INDEX IF EXISTS idx_events_actor_time;
            DROP INDEX IF EXISTS idx_events_object_time;
            DROP INDEX IF EXISTS idx_events_pair;
            DELETE FROM events;
            DELETE FROM metadata;
            """
        )
        _set_metadata(connection, "signature", signature)
        connection.commit()

    history_ms = config.history_minutes * 60 * 1_000
    file_stats: dict[str, dict[str, int]] = {}
    for corpus, files in (("attack", attack_files), ("benign", benign_files)):
        for source_path in files:
            resolved = str(source_path.resolve())
            metadata_key = "file:" + hashlib.sha256(
                f"{corpus}:{resolved}".encode("utf-8")
            ).hexdigest()
            raw_completed = _metadata(connection, metadata_key)
            if raw_completed is not None:
                file_stats[f"{corpus}:{resolved}"] = json.loads(raw_completed)
                continue
            # A prior process can stop mid-file. Preserve all completed shards,
            # discard only this shard's partial rows, then replay it atomically.
            connection.execute(
                "DELETE FROM events WHERE corpus = ? AND source_path IN (?, ?)",
                (corpus, str(source_path), resolved),
            )
            connection.commit()
            kwargs: dict[str, object] = {
                "hostnames": hosts,
                "strict": False,
            }
            if corpus == "attack":
                kwargs.update(
                    {
                        "start_ms": max(0, attack_start_ms - history_ms),
                        "end_ms": attack_end_ms,
                    }
                )
            stats = _insert_events(
                connection,
                corpus=corpus,
                events=iter_optc_events(source_path, **kwargs),
            )
            _set_metadata(connection, metadata_key, stats)
            connection.commit()
            file_stats[f"{corpus}:{resolved}"] = stats

    connection.executescript(
        """
        CREATE INDEX IF NOT EXISTS idx_events_time
            ON events(corpus, timestamp_ms);
        CREATE INDEX IF NOT EXISTS idx_events_actor_time
            ON events(corpus, actor_id, timestamp_ms);
        CREATE INDEX IF NOT EXISTS idx_events_object_time
            ON events(corpus, object_id, timestamp_ms);
        CREATE INDEX IF NOT EXISTS idx_events_pair
            ON events(corpus, object_type, action);
        """
    )
    stats = {
        "attack": {
            "seen": sum(
                value["seen"]
                for key, value in file_stats.items()
                if key.startswith("attack:")
            ),
            "inserted": sum(
                value["inserted"]
                for key, value in file_stats.items()
                if key.startswith("attack:")
            ),
        },
        "benign": {
            "seen": sum(
                value["seen"]
                for key, value in file_stats.items()
                if key.startswith("benign:")
            ),
            "inserted": sum(
                value["inserted"]
                for key, value in file_stats.items()
                if key.startswith("benign:")
            ),
        },
        "files": file_stats,
    }
    _set_metadata(connection, "signature", signature)
    _set_metadata(connection, "stats", stats)
    _set_metadata(connection, "complete", "true")
    connection.commit()
    return {"reused": False, "signature": signature, "stats": stats}


def _fetch_event(
    connection: sqlite3.Connection,
    corpus: str,
    event_id: str,
) -> _IndexedEvent | None:
    row = connection.execute(
        "SELECT * FROM events WHERE corpus = ? AND event_id = ?",
        (corpus, event_id),
    ).fetchone()
    return None if row is None else _IndexedEvent.from_row(row)


def _bottom_k_events(
    rows: Iterable[sqlite3.Row],
    *,
    count: int,
    seed: int,
    excluded_ids: set[str] | None = None,
) -> list[_IndexedEvent]:
    if count <= 0:
        return []
    excluded = excluded_ids or set()
    heap: list[tuple[int, str, _IndexedEvent]] = []
    for row in rows:
        event = _IndexedEvent.from_row(row)
        if event.event_id in excluded:
            continue
        rank = _stable_rank(seed, event.event_id)
        entry = (-rank, event.event_id, event)
        if len(heap) < count:
            heapq.heappush(heap, entry)
        elif rank < -heap[0][0]:
            heapq.heapreplace(heap, entry)
    return sorted(
        (entry[2] for entry in heap),
        key=lambda event: (_stable_rank(seed, event.event_id), event.event_id),
    )


def _pair_quotas(
    anchors: list[_IndexedEvent],
    target: int,
) -> dict[tuple[str, str], int]:
    counts = Counter((event.object_type, event.action) for event in anchors)
    total = sum(counts.values())
    exact = {pair: target * count / total for pair, count in counts.items()}
    quotas = {pair: math.floor(value) for pair, value in exact.items()}
    remaining = target - sum(quotas.values())
    for pair in sorted(
        exact,
        key=lambda value: (-(exact[value] - quotas[value]), value),
    )[:remaining]:
        quotas[pair] += 1
    return {pair: quota for pair, quota in quotas.items() if quota > 0}


def _select_anchors(
    connection: sqlite3.Connection,
    labels: tuple[OptcAttackLabel, ...],
    *,
    target_malicious: int,
    target_matched: int,
    target_hard: int,
    seed: int,
) -> tuple[list[_IndexedEvent], list[_IndexedEvent], list[_IndexedEvent]]:
    present: list[_IndexedEvent] = []
    for label in labels:
        event = _fetch_event(connection, "attack", label.event_id)
        if event is not None:
            present.append(event)
    malicious = sorted(
        present,
        key=lambda event: (_stable_rank(seed, event.event_id), event.event_id),
    )[:target_malicious]
    if len(malicious) < target_malicious:
        raise ValueError(
            f"only {len(malicious)} labeled malicious anchors are present in attack shards; "
            f"need {target_malicious}"
        )

    matched: list[_IndexedEvent] = []
    used: set[str] = set()
    for pair, quota in sorted(_pair_quotas(malicious, target_matched).items()):
        rows = connection.execute(
            """
            SELECT * FROM events
            WHERE corpus = 'benign' AND object_type = ? AND action = ?
            """,
            pair,
        )
        selected = _bottom_k_events(
            rows,
            count=quota,
            seed=seed + 101 + _stable_rank(seed, ":".join(pair)) % 10_000,
            excluded_ids=used,
        )
        matched.extend(selected)
        used.update(event.event_id for event in selected)
    if len(matched) < target_matched:
        raise ValueError(
            f"only {len(matched)} exact object/action-matched benign anchors are available; "
            f"need {target_matched}"
        )

    pair_clauses = " OR ".join("(object_type = ? AND action = ?)" for _ in _HARD_NEGATIVE_PAIRS)
    parameters = [
        member
        for pair in sorted(_HARD_NEGATIVE_PAIRS)
        for member in pair
    ]
    hard_rows = connection.execute(
        f"SELECT * FROM events WHERE corpus = 'benign' AND ({pair_clauses})",
        parameters,
    )
    hard = _bottom_k_events(
        hard_rows,
        count=target_hard,
        seed=seed + 201,
        excluded_ids=used,
    )
    if len(hard) < target_hard:
        raise ValueError(
            f"only {len(hard)} attack-like hard-negative anchors are available; "
            f"need {target_hard}"
        )
    return malicious, matched[:target_matched], hard[:target_hard]


def _query_related_events(
    connection: sqlite3.Connection,
    *,
    corpus: str,
    entity_ids: set[str],
    start_ms: int,
    end_ms: int,
) -> list[_IndexedEvent]:
    if not entity_ids:
        return []
    output: dict[str, _IndexedEvent] = {}
    ordered = sorted(entity_ids)
    for offset in range(0, len(ordered), 300):
        chunk = ordered[offset : offset + 300]
        placeholders = ",".join("?" for _ in chunk)
        parameters: list[object] = [corpus, start_ms, end_ms, *chunk, *chunk]
        rows = connection.execute(
            f"""
            SELECT * FROM events
            WHERE corpus = ? AND timestamp_ms BETWEEN ? AND ?
              AND (actor_id IN ({placeholders}) OR object_id IN ({placeholders}))
            """,
            parameters,
        )
        for row in rows:
            event = _IndexedEvent.from_row(row)
            output[event.event_id] = event
    return list(output.values())


def _event_attributes(event: _IndexedEvent) -> dict[str, object]:
    attributes: dict[str, object] = dict(event.properties)
    if event.pid is not None:
        attributes["pid"] = event.pid
    if event.ppid is not None:
        attributes["ppid"] = event.ppid
    if event.principal:
        attributes["principal"] = event.principal[:256]
    return attributes


def _entity_label(event: _IndexedEvent, *, actor: bool) -> str:
    properties = event.properties
    preferred = (
        ("image_path", "command_line", "path")
        if actor
        else (
            "target_path",
            "file_path",
            "module_path",
            "key",
            "reg_key",
            "dest_ip",
            "path",
            "image_path",
        )
    )
    for key in preferred:
        value = properties.get(key)
        if value not in (None, ""):
            return str(value)[:500]
    if actor and event.principal:
        return event.principal[:500]
    raw_id = event.actor_id if actor else event.object_id
    return raw_id


def _build_subgraph(
    connection: sqlite3.Connection,
    anchor: _IndexedEvent,
    *,
    history_minutes: int,
    hops: int,
    max_nodes: int,
    max_edges: int,
) -> tuple[list[dict[str, object]], list[dict[str, object]], list[str]]:
    start_ms = max(0, anchor.timestamp_ms - history_minutes * 60 * 1_000)
    selected: dict[str, tuple[int, _IndexedEvent]] = {anchor.event_id: (0, anchor)}
    frontier = {anchor.actor_id, anchor.object_id}
    seen_entities = set(frontier)
    for distance in range(1, hops + 1):
        candidates = _query_related_events(
            connection,
            corpus=anchor.corpus,
            entity_ids=frontier,
            start_ms=start_ms,
            end_ms=anchor.timestamp_ms,
        )
        next_frontier: set[str] = set()
        for event in candidates:
            existing = selected.get(event.event_id)
            if existing is None or distance < existing[0]:
                selected[event.event_id] = (distance, event)
            for entity_id in (event.actor_id, event.object_id):
                if entity_id not in seen_entities:
                    next_frontier.add(entity_id)
                    seen_entities.add(entity_id)
        frontier = next_frontier
        if not frontier:
            break

    ordered = sorted(
        selected.values(),
        key=lambda pair: (
            pair[0],
            0 if pair[1].event_id == anchor.event_id else 1,
            -pair[1].timestamp_ms,
            pair[1].event_id,
        ),
    )
    kept: list[tuple[int, _IndexedEvent]] = []
    kept_entities: set[str] = set()
    for distance, event in ordered:
        new_entities = {event.actor_id, event.object_id}.difference(kept_entities)
        if kept and (
            len(kept) >= max_edges
            or len(kept_entities) + len(new_entities) > max_nodes
        ):
            continue
        kept.append((distance, event))
        kept_entities.update((event.actor_id, event.object_id))

    node_candidates: dict[str, dict[str, object]] = {}
    edges: list[dict[str, object]] = []
    for priority, (distance, event) in enumerate(kept):
        source_id = f"entity:{event.actor_id}"
        target_id = f"entity:{event.object_id}"
        node_candidates.setdefault(
            source_id,
            {
                "node_id": source_id,
                "node_type": "PROCESS_ACTOR",
                "label": _entity_label(event, actor=True),
                "hostname": event.hostname,
                "attributes": {},
            },
        )
        target = node_candidates.setdefault(
            target_id,
            {
                "node_id": target_id,
                "node_type": event.object_type,
                "label": _entity_label(event, actor=False),
                "hostname": event.hostname,
                "attributes": {},
            },
        )
        if target["node_type"] == "PROCESS_ACTOR" and event.object_type:
            target["node_type"] = event.object_type
        edges.append(
            {
                "edge_id": event.event_id,
                "timestamp_ms": event.timestamp_ms,
                "source_node_id": source_id,
                "target_node_id": target_id,
                "action": event.action,
                "hostname": event.hostname,
                "attributes": _event_attributes(event),
                "_priority": priority,
                "_distance": distance,
            }
        )
    nodes = sorted(
        node_candidates.values(),
        key=lambda node: (str(node["node_type"]), str(node["node_id"])),
    )
    edges.sort(
        key=lambda edge: (
            int(edge["timestamp_ms"]),
            str(edge["action"]),
            str(edge["source_node_id"]),
            str(edge["target_node_id"]),
            str(edge["edge_id"]),
        )
    )
    missing: list[str] = []
    if len(selected) > len(kept):
        missing.append(
            f"Deterministic node/edge caps pruned {len(selected) - len(kept)} related events."
        )
    return nodes, edges, missing


def _fit_record_to_token_budget(
    record: dict[str, Any],
    *,
    max_estimated_tokens: int,
) -> None:
    raw_edges = record["edges"]
    raw_nodes = record["nodes"]
    if not isinstance(raw_edges, list) or not isinstance(raw_nodes, list):
        raise TypeError("record nodes and edges must be lists")
    prioritized = sorted(raw_edges, key=lambda edge: int(edge["_priority"]))
    nodes_by_id = {str(node["node_id"]): node for node in raw_nodes}
    original_edge_count = len(prioritized)

    def apply_count(count: int) -> int:
        selected = prioritized[:count]
        referenced = {
            str(edge[field])
            for edge in selected
            for field in ("source_node_id", "target_node_id")
        }
        record["nodes"] = [
            nodes_by_id[node_id]
            for node_id in sorted(
                referenced,
                key=lambda value: (
                    str(nodes_by_id[value]["node_type"]),
                    value,
                ),
            )
        ]
        record["edges"] = sorted(
            selected,
            key=lambda edge: (
                int(edge["timestamp_ms"]),
                str(edge["action"]),
                str(edge["source_node_id"]),
                str(edge["target_node_id"]),
                str(edge["edge_id"]),
            ),
        )
        return estimate_optc_chain_record_tokens(record)

    safe_token_budget = max(1, max_estimated_tokens - 64)
    current_count = original_edge_count
    estimated = apply_count(current_count)
    while estimated > safe_token_budget and current_count > 1:
        ratio = safe_token_budget / estimated
        next_count = max(1, min(current_count - 1, math.floor(current_count * ratio * 0.96)))
        current_count = next_count
        estimated = apply_count(current_count)
    if estimated > safe_token_budget:
        raise ValueError(
            "anchor-only OpTC evidence exceeds max_estimated_tokens; "
            "reduce the source property contract"
        )
    if current_count < original_edge_count:
        missing = record.get("missing_evidence")
        if isinstance(missing, list):
            missing.append(
                "Token-budget pruning removed "
                f"{original_edge_count - current_count} lower-priority related events."
            )
            # The explanatory line itself consumes tokens. Remove another
            # lowest-priority edge if it pushes the record over the boundary.
            while (
                estimate_optc_chain_record_tokens(record) > safe_token_budget
                and current_count > 1
            ):
                current_count -= 1
                apply_count(current_count)
            if estimate_optc_chain_record_tokens(record) > safe_token_budget:
                raise ValueError(
                    "anchor-only OpTC evidence plus pruning audit exceeds "
                    "max_estimated_tokens"
                )
    for edge in record["edges"]:
        edge.pop("_priority", None)
        edge.pop("_distance", None)


def _split_by_group(
    records: list[dict[str, Any]],
    *,
    seed: int,
) -> None:
    by_corpus: dict[str, set[str]] = defaultdict(set)
    for record in records:
        by_corpus[str(record["_corpus"])].add(str(record["scenario_group_id"]))
    assignments: dict[str, str] = {}
    for corpus, groups in sorted(by_corpus.items()):
        ordered = sorted(
            groups,
            key=lambda group: (_stable_rank(seed + 301, group), group),
        )
        count = len(ordered)
        if count == 1:
            calibration_count = validation_count = 0
        elif count == 2:
            calibration_count, validation_count = 1, 0
        else:
            calibration_count = max(1, round(count * 0.20))
            validation_count = max(1, round(count * 0.10))
            if calibration_count + validation_count >= count:
                validation_count = max(0, count - calibration_count - 1)
        for index, group in enumerate(ordered):
            if index < calibration_count:
                split = "calibration"
            elif index < calibration_count + validation_count:
                split = "validation"
            else:
                split = "test"
            assignments[group] = split
    for record in records:
        record["split"] = assignments[str(record["scenario_group_id"])]


def _interleaved_rank(records: list[dict[str, Any]], *, seed: int) -> None:
    by_kind: dict[str, list[dict[str, Any]]] = defaultdict(list)
    for record in records:
        by_kind[str(record["sample_kind"])].append(record)
    for kind, values in by_kind.items():
        values.sort(
            key=lambda record: (
                _stable_rank(seed + 401, f"{kind}:{record['sample_id']}"),
                str(record["sample_id"]),
            )
        )
    order = ("malicious", "matched_benign", "hard_negative")
    position = 0
    rank = 1
    while any(position < len(by_kind[kind]) for kind in order):
        for kind in order:
            values = by_kind[kind]
            if position < len(values):
                values[position]["collection_rank"] = rank
                rank += 1
        position += 1


def _source_reference(
    path_value: str | Path,
    *,
    source: str,
    digests: dict[str, str],
) -> dict[str, str]:
    path = Path(path_value).resolve()
    reference = {"source": source, "reference": _portable_path(path)}
    digest = digests.get(str(path))
    if digest:
        reference["sha256"] = digest
    return reference


def _portable_path(path_value: str | Path) -> str:
    path = Path(path_value).resolve()
    try:
        return str(path.relative_to(Path.cwd().resolve()))
    except ValueError:
        return str(path)


def _record_for_anchor(
    connection: sqlite3.Connection,
    anchor: _IndexedEvent,
    *,
    sample_kind: str,
    config: OptcChainBuildConfig,
    source_digests: dict[str, str],
) -> dict[str, Any]:
    malicious = sample_kind == "malicious"
    block_ms = config.group_minutes * 60 * 1_000
    block_start = (anchor.timestamp_ms // block_ms) * block_ms
    nodes, edges, missing = _build_subgraph(
        connection,
        anchor,
        history_minutes=config.history_minutes,
        hops=config.hops,
        max_nodes=config.max_nodes,
        max_edges=config.max_edges,
    )
    sample_prefix = {
        "malicious": "mal",
        "matched_benign": "matched",
        "hard_negative": "hard",
    }[sample_kind]
    if malicious:
        provenance = {
            "source": "Community best-effort OpTC exact event-ID labels",
            "reference": f"{_portable_path(config.labels_path)}#{anchor.event_id}",
            "review_status": "curated",
        }
    else:
        provenance = {
            "source": "Official OpTC benign-period eCAR collection",
            "reference": f"{_portable_path(anchor.source_path)}:{anchor.source_line}",
            "review_status": "curated",
        }
    source_refs = [
        _source_reference(
            anchor.source_path,
            source=f"OpTC {anchor.corpus} eCAR shard",
            digests=source_digests,
        ),
        _source_reference(
            config.scenario_manifest,
            source="Frozen OpTC scenario manifest",
            digests=source_digests,
        ),
    ]
    if malicious:
        source_refs.append(
            _source_reference(
                config.labels_path,
                source="OpTC exact event-ID label CSV",
                digests=source_digests,
            )
        )
    record = {
        "schema_version": 1,
        "dataset_id": "optc_chain_v1",
        "manifest_version": config.manifest_version,
        "sample_id": f"{sample_prefix}-{anchor.event_id}",
        "scenario_group_id": (
            f"{anchor.corpus}:{anchor.hostname}:{block_start}:{config.group_minutes}m"
        ),
        "split": "test",
        "collection_rank": 0,
        "gold_label": "malicious" if malicious else "benign",
        "sample_kind": sample_kind,
        "label_provenance": provenance,
        "anchor": {
            "event_id": anchor.event_id,
            "timestamp_ms": anchor.timestamp_ms,
            "hostname": anchor.hostname,
            "object_type": anchor.object_type,
            "action": anchor.action,
        },
        "nodes": nodes,
        "edges": edges,
        "known_history": {
            "confirmed_entities": [],
            "attack_stages": [],
            "prior_anchor_ids": [],
        },
        "missing_evidence": [
            (
                f"Only past events within {config.history_minutes} minutes and "
                f"{config.hops} entity hops are visible."
            ),
            *missing,
        ],
        "source_refs": source_refs,
        "_corpus": anchor.corpus,
    }
    _fit_record_to_token_budget(
        record,
        max_estimated_tokens=config.max_estimated_tokens,
    )
    return record


def _atomic_json(path: Path, payload: object) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(
        json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    temporary.replace(path)


def build_optc_chain_manifest(config: OptcChainBuildConfig) -> dict[str, object]:
    """Build, validate, and freeze a formal OpTC chain manifest."""

    if config.output_path.exists() and not config.overwrite:
        raise FileExistsError(
            f"output manifest already exists (use --overwrite): {config.output_path}"
        )
    scenario = load_optc_scenarios(config.scenario_manifest)[config.scenario_id]
    attack_start_ms, attack_end_ms = scenario.epoch_window(
        utc_offset_minutes=config.utc_offset_minutes,
        padding_minutes=config.padding_minutes,
    )
    label_index = load_optc_attack_labels(
        config.labels_path,
        hostnames=scenario.hosts,
        start_ms=attack_start_ms,
        end_ms=attack_end_ms,
        strict=True,
    )
    malicious_target = config.target_items // 3
    if len(label_index.labels) < malicious_target:
        raise ValueError(
            f"scenario has only {len(label_index.labels)} candidate malicious labels; "
            f"need at least {malicious_target}"
        )
    attack_files = _discover_source_files(config.attack_path)
    benign_files = _discover_source_files(config.benign_path)
    signature = _stage_signature(
        config,
        hosts=scenario.hosts,
        attack_start_ms=attack_start_ms,
        attack_end_ms=attack_end_ms,
        attack_files=attack_files,
        benign_files=benign_files,
    )

    started = time.time()
    connection = _open_stage(config.stage_db_path)
    try:
        stage = _prepare_stage(
            connection,
            config,
            hosts=scenario.hosts,
            attack_start_ms=attack_start_ms,
            attack_end_ms=attack_end_ms,
            signature=signature,
            attack_files=attack_files,
            benign_files=benign_files,
        )
        matched_target = (config.target_items - malicious_target) // 2
        hard_target = config.target_items - malicious_target - matched_target
        malicious, matched, hard = _select_anchors(
            connection,
            label_index.labels,
            target_malicious=malicious_target,
            target_matched=matched_target,
            target_hard=hard_target,
            seed=config.seed,
        )

        checksum_files = [
            *attack_files,
            *benign_files,
            config.labels_path,
            config.scenario_manifest,
        ]
        expected_digest_paths = {
            str(path.resolve())
            for path in checksum_files
        }
        cached_digests_raw = _metadata(connection, "source_digests")
        cached_digests = (
            {}
            if cached_digests_raw is None
            else json.loads(cached_digests_raw)
        )
        source_digests: dict[str, str] = {
            str(key): str(value)
            for key, value in cached_digests.items()
            if str(key) in expected_digest_paths
        }
        if config.checksum_mode == "full":
            for path in checksum_files:
                resolved = str(path.resolve())
                if resolved not in source_digests:
                    print(f"sha256 {resolved}", flush=True)
                    source_digests[resolved] = _sha256(path)
                    _set_metadata(connection, "source_digests", source_digests)
                    connection.commit()

        records: list[dict[str, Any]] = []
        for kind, anchors in (
            ("malicious", malicious),
            ("matched_benign", matched),
            ("hard_negative", hard),
        ):
            for anchor in anchors:
                records.append(
                    _record_for_anchor(
                        connection,
                        anchor,
                        sample_kind=kind,
                        config=config,
                        source_digests=source_digests,
                    )
                )
        _split_by_group(records, seed=config.seed)
        _interleaved_rank(records, seed=config.seed)
        for record in records:
            record.pop("_corpus", None)
        records.sort(key=lambda record: int(record["collection_rank"]))
    finally:
        connection.close()

    config.output_path.parent.mkdir(parents=True, exist_ok=True)
    temporary = config.output_path.with_suffix(config.output_path.suffix + ".tmp")
    with temporary.open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(
                json.dumps(
                    record,
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                )
                + "\n"
            )
    validated = load_optc_chain_dataset(
        temporary,
        max_nodes=config.max_nodes,
        max_edges=config.max_edges,
        max_estimated_tokens=config.max_estimated_tokens,
    )
    temporary.replace(config.output_path)

    manifest_sha256 = _sha256(config.output_path)
    if manifest_sha256 != validated.manifest_sha256:
        raise RuntimeError("manifest checksum changed during atomic finalization")
    metadata_path = config.output_path.with_suffix(".meta.json")
    checksums_path = config.output_path.with_suffix(".sha256")
    summary: dict[str, object] = {
        "schema_version": 1,
        "complete": True,
        "manifest_path": str(config.output_path.resolve()),
        "manifest_sha256": manifest_sha256,
        "metadata_path": str(metadata_path.resolve()),
        "checksums_path": str(checksums_path.resolve()),
        "stage_db_path": str(config.stage_db_path.resolve()),
        "stage": stage,
        "scenario_id": config.scenario_id,
        "scenario_hosts": list(scenario.hosts),
        "attack_window_ms": [attack_start_ms, attack_end_ms],
        "label_stats": asdict(label_index.stats),
        "build_config": {
            key: str(value) if isinstance(value, Path) else value
            for key, value in asdict(config).items()
        },
        "source_digests": source_digests,
        "dataset_stats": validated.stats,
        "elapsed_seconds": time.time() - started,
    }
    _atomic_json(metadata_path, summary)
    checksums_path.write_text(
        f"{manifest_sha256}  {config.output_path.name}\n"
        f"{_sha256(metadata_path)}  {metadata_path.name}\n",
        encoding="utf-8",
    )
    return summary
