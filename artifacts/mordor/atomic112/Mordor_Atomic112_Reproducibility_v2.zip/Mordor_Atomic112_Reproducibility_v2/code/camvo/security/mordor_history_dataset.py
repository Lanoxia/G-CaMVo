"""Past-only Mordor dataset with online-style historical evidence retrieval.

The original Mordor binary dataset presents only records sharing an exact
timestamp.  This module keeps the same balanced anchors and hidden labels, but
replays *all* source telemetry in chronological order.  Before an anchor group
is indexed, it retrieves earlier groups using observable telemetry entities.
Consequently, a prompt can contain inferred historical links without using
attack-chain annotations or future records.
"""

from __future__ import annotations

import hashlib
import json
import math
import os
from collections import Counter, defaultdict, deque
from collections.abc import Iterable
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from camvo.security.mordor_dataset import (
    MORDOR_BINARY_LABELS,
    _group_logs,
    _load_payload,
    _matched_negatives,
    _stable_rank,
)
from camvo.types import AnnotationItem

MORDOR_HISTORY_SPLITS = frozenset({"calibration", "validation", "test"})

_PROMPT_FIELDS = (
    "TimeCreated",
    "UtcTime",
    "Hostname",
    "EventID",
    "Channel",
    "SourceName",
    "Image",
    "CommandLine",
    "ParentImage",
    "ParentCommandLine",
    "ProcessGuid",
    "ParentProcessGuid",
    "ProcessId",
    "ProcessID",
    "SourceProcessGUID",
    "TargetProcessGUID",
    "SourceImage",
    "TargetImage",
    "SourceProcessId",
    "TargetProcessId",
    "User",
    "SubjectUserName",
    "TargetUserName",
    "SubjectLogonId",
    "TargetLogonId",
    "LogonGuid",
    "LogonId",
    "SourceAddress",
    "SourceIp",
    "SourcePort",
    "DestinationAddress",
    "DestinationIp",
    "DestinationPort",
    "DestAddress",
    "DestPort",
    "Protocol",
    "TargetFilename",
    "TargetObject",
    "ObjectName",
    "Details",
    "QueryName",
    "ServiceName",
    "Service",
    "Task",
)

_MESSAGE_KEYS = frozenset(
    {
        "account name",
        "commandline",
        "destinationhostname",
        "destinationip",
        "destinationport",
        "image",
        "logon id",
        "logonguid",
        "object name",
        "parentcommandline",
        "parentimage",
        "parentprocessguid",
        "process name",
        "processguid",
        "queryname",
        "service name",
        "sourcehostname",
        "sourceip",
        "sourceport",
        "targetfilename",
        "user",
    }
)

_ENTITY_FIELDS: dict[str, tuple[str, ...]] = {
    "process": (
        "ProcessGuid",
        "ParentProcessGuid",
        "SourceProcessGUID",
        "TargetProcessGUID",
    ),
    "file_or_object": ("TargetFilename", "TargetObject", "ObjectName", "QueryName"),
    "session": (
        "LogonGuid",
        "LogonId",
        "SubjectLogonId",
        "TargetLogonId",
        "ActivityID",
    ),
    "network": (
        "SourceAddress",
        "SourceIp",
        "DestinationAddress",
        "DestinationIp",
        "DestAddress",
    ),
    "user": ("User", "SubjectUserName", "TargetUserName", "AccountName"),
}

_RELATION_BASE_WEIGHT = {
    "parent_process": 1.00,
    "same_process": 0.92,
    "same_file_or_object": 0.68,
    "same_session": 0.62,
    "same_network_endpoint": 0.45,
    "same_user": 0.28,
    "same_host_recent": 0.06,
}


class MordorHistoryManifestError(ValueError):
    """Raised when a history manifest violates its online evidence contract."""


@dataclass(frozen=True, slots=True)
class MordorHistoryDataset:
    items: tuple[AnnotationItem, ...]
    manifest_path: str
    manifest_sha256: str
    stats: dict[str, object]

    def __post_init__(self) -> None:
        if not self.items:
            raise ValueError("Mordor history dataset must not be empty")
        if any(item.labels != MORDOR_BINARY_LABELS for item in self.items):
            raise ValueError("Mordor history item has unexpected labels")


@dataclass(slots=True)
class _ReplayGroup:
    group_id: str
    timestamp: str
    timestamp_ms: int
    records: list[dict[str, Any]]
    hosts: tuple[str, ...]
    entities: dict[str, frozenset[str]]
    created_processes: frozenset[str]
    parent_processes: frozenset[str]


@dataclass(slots=True)
class _Candidate:
    group: _ReplayGroup
    score: float
    relations: set[str]
    matched_entities: set[str]
    hop: int = 1
    via_group_id: str | None = None


@dataclass(slots=True)
class _OnlineHistoryIndex:
    by_entity: dict[tuple[str, str], deque[_ReplayGroup]]
    by_host: dict[str, deque[_ReplayGroup]]

    @classmethod
    def create(cls) -> _OnlineHistoryIndex:
        return cls(defaultdict(deque), defaultdict(deque))

    def add(self, group: _ReplayGroup) -> None:
        for kind, values in group.entities.items():
            for value in values:
                self.by_entity[(kind, value)].append(group)
        for host in group.hosts:
            normalized = _normalize(host)
            if normalized:
                self.by_host[normalized].append(group)

    @staticmethod
    def _recent(
        queue: deque[_ReplayGroup],
        *,
        cutoff_ms: int,
        before_ms: int,
        limit: int | None = None,
    ) -> list[_ReplayGroup]:
        while queue and queue[0].timestamp_ms < cutoff_ms:
            queue.popleft()
        output: list[_ReplayGroup] = []
        for group in reversed(queue):
            if group.timestamp_ms >= before_ms:
                continue
            output.append(group)
            if limit is not None and len(output) >= limit:
                break
        return output

    def candidates(
        self,
        later: _ReplayGroup,
        *,
        history_window_ms: int,
        include_host: bool,
        max_host_background: int,
    ) -> list[_ReplayGroup]:
        cutoff = later.timestamp_ms - history_window_ms
        found: dict[str, _ReplayGroup] = {}
        entity_limits = {
            "process": 50,
            "file_or_object": 30,
            "session": 20,
            "network": 20,
            "user": 10,
        }
        for kind, values in later.entities.items():
            for value in values:
                queue = self.by_entity.get((kind, value))
                if queue is None:
                    continue
                for group in self._recent(
                    queue,
                    cutoff_ms=cutoff,
                    before_ms=later.timestamp_ms,
                    limit=entity_limits[kind],
                ):
                    found[group.group_id] = group
        if include_host:
            for host in later.hosts:
                queue = self.by_host.get(_normalize(host))
                if queue is None:
                    continue
                for group in self._recent(
                    queue,
                    cutoff_ms=cutoff,
                    before_ms=later.timestamp_ms,
                    limit=max_host_background,
                ):
                    found[group.group_id] = group
        return list(found.values())


def _normalize(value: object) -> str:
    text = str(value or "").strip().casefold()
    if text in {"", "-", "{}", "0x0", "0.0.0.0", "::", "unknown"}:
        return ""
    return text


def _values(records: Iterable[dict[str, Any]], fields: Iterable[str]) -> frozenset[str]:
    output: set[str] = set()
    for record in records:
        for field in fields:
            value = _normalize(record.get(field))
            if value:
                output.add(value)
    return frozenset(output)


def _replay_group(group: Any) -> _ReplayGroup:
    return _replay_group_from_records(
        group_id=group.group_id,
        timestamp=group.timestamp,
        timestamp_ms=group.timestamp_ms,
        records=group.records,
        hosts=group.hosts,
    )


def _replay_group_from_records(
    *,
    group_id: str,
    timestamp: str,
    timestamp_ms: int,
    records: list[dict[str, Any]],
    hosts: tuple[str, ...],
) -> _ReplayGroup:
    entities = {
        kind: _values(records, fields) for kind, fields in _ENTITY_FIELDS.items()
    }
    return _ReplayGroup(
        group_id=group_id,
        timestamp=timestamp,
        timestamp_ms=timestamp_ms,
        records=records,
        hosts=hosts,
        entities=entities,
        created_processes=_values(records, ("ProcessGuid",)),
        parent_processes=_values(records, ("ParentProcessGuid",)),
    )


def _history_groups_by_host(group: Any) -> list[_ReplayGroup]:
    records_by_host: dict[str, list[dict[str, Any]]] = defaultdict(list)
    display_host: dict[str, str] = {}
    for record in group.records:
        raw_host = str(record.get("Hostname") or record.get("Computer") or "unknown").strip()
        normalized_host = _normalize(raw_host) or "unknown"
        display_host.setdefault(normalized_host, raw_host or "unknown")
        records_by_host[normalized_host].append(record)
    output: list[_ReplayGroup] = []
    for normalized_host, records in sorted(records_by_host.items()):
        digest = hashlib.sha256(
            f"{group.timestamp}|{normalized_host}".encode()
        ).hexdigest()[:20]
        output.append(
            _replay_group_from_records(
                group_id=f"mordor-history-{digest}",
                timestamp=group.timestamp,
                timestamp_ms=group.timestamp_ms,
                records=records,
                hosts=(display_host[normalized_host],),
            )
        )
    return output


def _message_evidence(message: object) -> dict[str, str]:
    text = str(message or "").strip()
    if not text:
        return {}
    output: dict[str, str] = {}
    first_line = next((line.strip() for line in text.splitlines() if line.strip()), "")
    if first_line:
        output["summary"] = first_line
    for raw_line in text.splitlines():
        if ":" not in raw_line:
            continue
        key, value = raw_line.split(":", 1)
        normalized_key = key.strip().casefold()
        normalized_value = value.strip()
        if normalized_key in _MESSAGE_KEYS and normalized_value:
            output[key.strip()] = normalized_value
    return output


def _compact_record(record: dict[str, Any]) -> dict[str, object]:
    compact: dict[str, object] = {
        field: record[field]
        for field in _PROMPT_FIELDS
        if record.get(field) not in (None, "")
    }
    message = _message_evidence(record.get("Message"))
    if message:
        compact["message_evidence"] = message
    return compact


def _select_compact_records(
    records: Iterable[dict[str, Any]],
    limit: int,
) -> list[dict[str, object]]:
    selected: list[dict[str, object]] = []
    seen: set[str] = set()
    for record in records:
        compact = _compact_record(record)
        fingerprint = json.dumps(
            compact,
            ensure_ascii=False,
            sort_keys=True,
            separators=(",", ":"),
        )
        if fingerprint in seen:
            continue
        seen.add(fingerprint)
        selected.append(compact)
        if len(selected) >= limit:
            break
    return selected


def _relation_evidence(
    earlier: _ReplayGroup,
    later: _ReplayGroup,
    *,
    history_window_ms: int,
) -> tuple[set[str], set[str], float]:
    gap = later.timestamp_ms - earlier.timestamp_ms
    if gap <= 0 or gap > history_window_ms:
        return set(), set(), 0.0
    relations: set[str] = set()
    matched: set[str] = set()

    parent_matches = later.parent_processes.intersection(earlier.created_processes)
    if parent_matches:
        relations.add("parent_process")
        matched.update(f"process:{value}" for value in parent_matches)

    process_matches = later.entities["process"].intersection(earlier.entities["process"])
    if process_matches:
        relations.add("same_process")
        matched.update(f"process:{value}" for value in process_matches)

    for kind, relation in (
        ("file_or_object", "same_file_or_object"),
        ("session", "same_session"),
        ("network", "same_network_endpoint"),
        ("user", "same_user"),
    ):
        overlap = later.entities[kind].intersection(earlier.entities[kind])
        if overlap:
            relations.add(relation)
            matched.update(f"{kind}:{value}" for value in overlap)

    if set(later.hosts).intersection(earlier.hosts):
        relations.add("same_host_recent")
        matched.update(
            f"host:{value.casefold()}"
            for value in set(later.hosts).intersection(earlier.hosts)
        )

    if not relations:
        return set(), set(), 0.0
    decay = math.exp(-gap / history_window_ms)
    strongest = max(_RELATION_BASE_WEIGHT[relation] for relation in relations)
    supporting = sum(_RELATION_BASE_WEIGHT[relation] for relation in relations) - strongest
    score = min(1.0, (strongest + 0.15 * supporting) * decay)
    return relations, matched, score


def _candidate_pool(
    anchor: _ReplayGroup,
    *,
    index: _OnlineHistoryIndex,
    history_window_ms: int,
    max_host_background: int,
) -> dict[str, _Candidate]:
    candidates: dict[str, _Candidate] = {}
    for earlier in index.candidates(
        anchor,
        history_window_ms=history_window_ms,
        include_host=True,
        max_host_background=max_host_background,
    ):
        relations, matched, score = _relation_evidence(
            earlier,
            anchor,
            history_window_ms=history_window_ms,
        )
        if not relations:
            continue
        candidates[earlier.group_id] = _Candidate(
            group=earlier,
            score=score,
            relations=relations,
            matched_entities=matched,
        )
    return candidates


def _expand_one_hop(
    direct: dict[str, _Candidate],
    *,
    index: _OnlineHistoryIndex,
    history_window_ms: int,
    minimum_direct_score: float,
) -> None:
    if not direct:
        return
    strongest_children = sorted(
        direct.values(),
        key=lambda candidate: (-candidate.score, candidate.group.group_id),
    )[:8]
    for child_candidate in strongest_children:
        if child_candidate.score < minimum_direct_score:
            continue
        child = child_candidate.group
        for ancestor in index.candidates(
            child,
            history_window_ms=history_window_ms,
            include_host=False,
            max_host_background=0,
        ):
            relations, matched, score = _relation_evidence(
                ancestor,
                child,
                history_window_ms=history_window_ms,
            )
            strong = relations.difference({"same_host_recent", "same_user"})
            if not strong:
                continue
            propagated = score * child_candidate.score * 0.80
            current = direct.get(ancestor.group_id)
            if current is None:
                direct[ancestor.group_id] = _Candidate(
                    group=ancestor,
                    score=propagated,
                    relations={f"predecessor:{relation}" for relation in strong},
                    matched_entities=matched,
                    hop=2,
                    via_group_id=child.group_id,
                )
            elif propagated > current.score:
                current.score = propagated
                current.relations.update(
                    f"predecessor:{relation}" for relation in strong
                )
                current.matched_entities.update(matched)


def _render_prompt(record: dict[str, Any], manifest_sha256: str) -> str:
    lines = [
        "[DATASET_CONTRACT]",
        f"dataset_id={record['dataset_id']}",
        f"manifest_version={record['manifest_version']}",
        f"manifest_sha256={manifest_sha256}",
        f"sample_id={record['sample_id']}",
        "visibility=past_only",
        "historical_links=inferred_from_observable_telemetry_not_ground_truth",
        "previous_predictions_included=false",
        "",
        "[CURRENT_EVENT]",
        json.dumps(record["anchor"], ensure_ascii=False, sort_keys=True),
        "",
        "[RETRIEVED_PAST_EVENTS]",
    ]
    history = record["history"]
    if not history:
        lines.append("none")
    else:
        lines.extend(
            json.dumps(event, ensure_ascii=False, sort_keys=True) for event in history
        )
    lines.extend(["", "[MISSING_EVIDENCE]"])
    lines.extend(record["missing_evidence"] or ["none"])
    return "\n".join(lines)


def _load_split_map(path: str | Path | None) -> dict[str, str]:
    if path is None:
        return {}
    payload = json.loads(Path(path).read_text(encoding="utf-8"))
    output: dict[str, str] = {}
    for split, item_ids in payload.items():
        if split not in MORDOR_HISTORY_SPLITS or not isinstance(item_ids, list):
            continue
        for item_id in item_ids:
            output[str(item_id)] = split
    return output


def _select_anchors(
    groups_by_timestamp: dict[str, Any],
    flags_payload: dict[str, Any],
    *,
    max_positive_items: int | None,
    seed: int,
) -> dict[str, dict[str, object]]:
    flag_rows = flags_payload["flags"]
    flag_timestamps = {str(flag.get("value", "")).strip() for flag in flag_rows}
    flag_timestamps.discard("")
    missing = flag_timestamps.difference(groups_by_timestamp)
    if missing:
        raise ValueError(f"{len(missing)} flag timestamps do not join the public log sample")

    positives = [groups_by_timestamp[timestamp] for timestamp in sorted(flag_timestamps)]
    if max_positive_items is not None and len(positives) > max_positive_items:
        positives = sorted(
            positives,
            key=lambda group: _stable_rank(seed, group.timestamp),
        )[:max_positive_items]
    negative_candidates = [
        group
        for timestamp, group in groups_by_timestamp.items()
        if timestamp not in flag_timestamps
    ]
    negatives = _matched_negatives(
        negative_candidates,
        positives,
        count=len(positives),
        seed=seed + 1,
    )

    step_tactics: dict[tuple[int, int], tuple[str, ...]] = {}
    for chain in flags_payload.get("chains", []):
        chain_idx = int(chain["chain_idx"])
        for step in chain.get("steps", []):
            step_tactics[(chain_idx, int(step["step_idx"]))] = tuple(
                step.get("tactics", [])
            )
    flag_metadata: dict[str, dict[str, object]] = defaultdict(
        lambda: {"flag_records": 0, "chain_steps": set(), "tactics": set()}
    )
    for flag in flag_rows:
        timestamp = str(flag["value"])
        key = (int(flag["chain_idx"]), int(flag["step_idx"]))
        entry = flag_metadata[timestamp]
        entry["flag_records"] = int(entry["flag_records"]) + 1
        chain_steps = entry["chain_steps"]
        tactics = entry["tactics"]
        assert isinstance(chain_steps, set) and isinstance(tactics, set)
        chain_steps.add(f"{key[0]}:{key[1]}")
        tactics.update(step_tactics.get(key, ()))

    selected: dict[str, dict[str, object]] = {}
    for group, label in [
        *((group, "benign") for group in negatives),
        *((group, "malicious") for group in positives),
    ]:
        metadata: dict[str, object] = {
            "item_id": group.group_id,
            "gold_label": label,
        }
        if label == "malicious":
            entry = flag_metadata[group.timestamp]
            metadata.update(
                {
                    "flag_records": entry["flag_records"],
                    "chain_steps": sorted(entry["chain_steps"]),
                    "tactics": sorted(entry["tactics"]),
                }
            )
        selected[group.timestamp] = metadata
    return selected


def build_mordor_history_manifest(
    data_path: str | Path,
    flags_path: str | Path,
    output_path: str | Path,
    *,
    splits_path: str | Path | None = None,
    history_minutes: int = 2,
    max_history_groups: int = 15,
    max_anchor_records: int = 8,
    max_records_per_history_group: int = 2,
    max_host_background: int = 5,
    max_estimated_tokens: int = 10_000,
    max_positive_items: int | None = None,
    seed: int = 17,
    manifest_version: str = "mordor-history-v1",
    overwrite: bool = False,
) -> dict[str, object]:
    """Build a deterministic JSONL manifest by chronological online replay."""

    if history_minutes <= 0:
        raise ValueError("history_minutes must be positive")
    if min(
        max_history_groups,
        max_anchor_records,
        max_records_per_history_group,
        max_host_background,
        max_estimated_tokens,
    ) <= 0:
        raise ValueError("history limits must be positive")
    output = Path(output_path)
    if output.exists() and not overwrite:
        raise FileExistsError(f"refusing to overwrite existing manifest: {output}")

    split_map = _load_split_map(splits_path)
    data = _load_payload(data_path, "logs")
    flags = _load_payload(flags_path, "flags")
    groups_by_timestamp = _group_logs(data["logs"])
    anchor_by_timestamp = _select_anchors(
        groups_by_timestamp,
        flags,
        max_positive_items=max_positive_items,
        seed=seed,
    )
    ordered_groups = sorted(
        groups_by_timestamp.values(),
        key=lambda group: (group.timestamp_ms, group.group_id),
    )
    history_window_ms = history_minutes * 60 * 1_000
    history_index = _OnlineHistoryIndex.create()
    retrieval_relations: Counter[str] = Counter()
    history_counts: list[int] = []
    item_count = 0

    output.parent.mkdir(parents=True, exist_ok=True)
    temporary_output = output.with_name(f".{output.name}.{os.getpid()}.tmp")
    with temporary_output.open("w", encoding="utf-8") as handle:
        for raw_group in ordered_groups:
            group = _replay_group(raw_group)
            host_history_groups = _history_groups_by_host(raw_group)
            anchor_metadata = anchor_by_timestamp.get(group.timestamp)
            if anchor_metadata is None:
                for host_group in host_history_groups:
                    history_index.add(host_group)
                continue

            candidates = _candidate_pool(
                group,
                index=history_index,
                history_window_ms=history_window_ms,
                max_host_background=max_host_background,
            )
            _expand_one_hop(
                candidates,
                index=history_index,
                history_window_ms=history_window_ms,
                minimum_direct_score=0.25,
            )
            ranked = sorted(
                candidates.values(),
                key=lambda candidate: (
                    -candidate.score,
                    -candidate.group.timestamp_ms,
                    candidate.group.group_id,
                ),
            )
            anchor_payload = {
                "event_group_id": group.group_id,
                "timestamp": group.timestamp,
                "timestamp_ms": group.timestamp_ms,
                "hosts": list(group.hosts),
                "records": _select_compact_records(
                    group.records,
                    max_anchor_records,
                ),
            }
            # Reserve space for the prompt contract and missing-evidence section.
            estimated_tokens = (
                len(json.dumps(anchor_payload, ensure_ascii=False).encode("utf-8")) + 3
            ) // 4 + 600
            selected: list[_Candidate] = []
            selected_payloads: dict[str, dict[str, object]] = {}
            for candidate in ranked:
                payload: dict[str, object] = {
                    "event_group_id": candidate.group.group_id,
                    "timestamp": candidate.group.timestamp,
                    "timestamp_ms": candidate.group.timestamp_ms,
                    "milliseconds_before_anchor": (
                        group.timestamp_ms - candidate.group.timestamp_ms
                    ),
                    "hosts": list(candidate.group.hosts),
                    "relations": sorted(candidate.relations),
                    "matched_entities": sorted(candidate.matched_entities),
                    "retrieval_score": round(candidate.score, 6),
                    "hop": candidate.hop,
                    "via_event_group_id": candidate.via_group_id,
                    "records": _select_compact_records(
                        candidate.group.records,
                        max_records_per_history_group,
                    ),
                }
                candidate_tokens = (
                    len(json.dumps(payload, ensure_ascii=False).encode("utf-8")) + 3
                ) // 4
                if estimated_tokens + candidate_tokens > max_estimated_tokens:
                    continue
                selected.append(candidate)
                selected_payloads[candidate.group.group_id] = payload
                estimated_tokens += candidate_tokens
                if len(selected) >= max_history_groups:
                    break
            selected.sort(
                key=lambda candidate: (
                    candidate.group.timestamp_ms,
                    candidate.group.group_id,
                )
            )
            history_events: list[dict[str, object]] = []
            for candidate in selected:
                relations = sorted(candidate.relations)
                retrieval_relations.update(relations)
                history_events.append(selected_payloads[candidate.group.group_id])

            item_id = str(anchor_metadata["item_id"])
            missing_evidence: list[str] = []
            if not history_events:
                missing_evidence.append(
                    "No earlier telemetry group was linked within the configured window."
                )
            if not group.entities["process"]:
                missing_evidence.append("Current event has no process GUID linkage field.")
            if not group.entities["session"]:
                missing_evidence.append("Current event has no session/logon linkage field.")
            item_count += 1
            history_counts.append(len(history_events))
            record = {
                "schema_version": 1,
                "dataset_id": "mordor_history_v1",
                "manifest_version": manifest_version,
                "sample_id": item_id,
                "collection_rank": item_count,
                "split": split_map.get(item_id, "test"),
                "gold_label": anchor_metadata["gold_label"],
                "sample_kind": (
                    "malicious"
                    if anchor_metadata["gold_label"] == "malicious"
                    else "matched_benign"
                ),
                "label_provenance": {
                    "source": "Cyber Defense benchmark exact timestamp flags",
                    "reference": group.timestamp,
                    "visibility_to_model": False,
                },
                "anchor": anchor_payload,
                "history": history_events,
                "missing_evidence": missing_evidence,
                "retrieval_contract": {
                    "visibility": "past_only",
                    "history_window_ms": history_window_ms,
                    "max_history_groups": max_history_groups,
                    "max_estimated_tokens": max_estimated_tokens,
                    "max_hops": 2,
                    "uses_gold_label_for_retrieval": False,
                    "uses_attack_chain_for_retrieval": False,
                    "uses_previous_prediction": False,
                },
                "evaluation_metadata": {
                    key: anchor_metadata[key]
                    for key in ("chain_steps", "tactics", "flag_records")
                    if key in anchor_metadata
                },
            }
            handle.write(
                json.dumps(
                    record,
                    ensure_ascii=False,
                    sort_keys=True,
                    separators=(",", ":"),
                )
                + "\n"
            )
            for host_group in host_history_groups:
                history_index.add(host_group)
    temporary_output.replace(output)

    digest = hashlib.sha256(output.read_bytes()).hexdigest()
    summary: dict[str, object] = {
        "dataset_id": "mordor_history_v1",
        "manifest_version": manifest_version,
        "manifest_path": str(output),
        "manifest_sha256": digest,
        "source_log_rows": len(data["logs"]),
        "source_timestamp_groups": len(ordered_groups),
        "items": item_count,
        "history_minutes": history_minutes,
        "max_history_groups": max_history_groups,
        "max_estimated_tokens": max_estimated_tokens,
        "items_with_history": sum(count > 0 for count in history_counts),
        "items_without_history": sum(count == 0 for count in history_counts),
        "mean_history_groups": (
            sum(history_counts) / len(history_counts) if history_counts else 0.0
        ),
        "max_observed_history_groups": max(history_counts, default=0),
        "retrieval_relations": dict(retrieval_relations.most_common()),
        "past_only_by_construction": True,
        "gold_or_chain_used_for_retrieval": False,
        "previous_predictions_included": False,
    }
    meta_path = output.with_suffix(".meta.json")
    meta_path.write_text(
        json.dumps(summary, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
    )
    return summary


def load_mordor_history_dataset(
    manifest_path: str | Path,
    *,
    split: str = "all",
    limit: int | None = None,
    max_estimated_tokens: int = 16_000,
) -> MordorHistoryDataset:
    """Load a history manifest and reject future or label-bearing prompt evidence."""

    path = Path(manifest_path)
    raw_bytes = path.read_bytes()
    manifest_sha256 = hashlib.sha256(raw_bytes).hexdigest()
    requested_split = split.casefold()
    if requested_split != "all" and requested_split not in MORDOR_HISTORY_SPLITS:
        raise ValueError("split must be all, calibration, validation, or test")
    if limit is not None and limit <= 0:
        raise ValueError("limit must be positive")

    parsed: list[dict[str, Any]] = []
    for line_number, line in enumerate(raw_bytes.decode("utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            record = json.loads(line)
        except json.JSONDecodeError as exc:
            raise MordorHistoryManifestError(
                f"line {line_number} is invalid JSON: {exc.msg}"
            ) from exc
        anchor_time = int(record["anchor"]["timestamp_ms"])
        for event in record.get("history", []):
            history_time = int(event["timestamp_ms"])
            if history_time >= anchor_time:
                raise MordorHistoryManifestError(
                    f"line {line_number} contains non-past history "
                    f"({history_time} >= {anchor_time})"
                )
        contract = record.get("retrieval_contract", {})
        if contract.get("uses_gold_label_for_retrieval") is not False:
            raise MordorHistoryManifestError(
                f"line {line_number} does not deny gold-label retrieval"
            )
        if contract.get("uses_attack_chain_for_retrieval") is not False:
            raise MordorHistoryManifestError(
                f"line {line_number} does not deny attack-chain retrieval"
            )
        parsed.append(record)

    parsed.sort(key=lambda record: int(record["collection_rank"]))
    selected = [
        record
        for record in parsed
        if requested_split == "all" or record["split"] == requested_split
    ]
    if limit is not None:
        selected = selected[:limit]
    if not selected:
        raise MordorHistoryManifestError("no records selected from manifest")

    items: list[AnnotationItem] = []
    token_counts: list[int] = []
    for record in selected:
        text = _render_prompt(record, manifest_sha256)
        forbidden = (
            '"gold_label"',
            '"chain_steps"',
            '"tactics"',
            "visibility_to_model",
        )
        if any(marker in text for marker in forbidden):
            raise MordorHistoryManifestError(
                f"sample {record['sample_id']} leaks evaluation metadata into prompt"
            )
        estimated_tokens = max(1, (len(text.encode("utf-8")) + 3) // 4)
        if estimated_tokens > max_estimated_tokens:
            raise MordorHistoryManifestError(
                f"sample {record['sample_id']} is estimated at {estimated_tokens} tokens"
            )
        token_counts.append(estimated_tokens)
        items.append(
            AnnotationItem(
                item_id=f"mordor-history:{record['sample_id']}",
                text=text,
                labels=MORDOR_BINARY_LABELS,
                metadata={
                    "gold_label": record["gold_label"],
                    "sample_id": record["sample_id"],
                    "split": record["split"],
                    "collection_rank": record["collection_rank"],
                    "timestamp_ms": record["anchor"]["timestamp_ms"],
                    "hostname": (record["anchor"].get("hosts") or ["unknown"])[0],
                    "history_group_count": len(record["history"]),
                    "estimated_input_tokens": estimated_tokens,
                    "manifest_sha256": manifest_sha256,
                    "evaluation_metadata": record.get("evaluation_metadata", {}),
                },
            )
        )

    return MordorHistoryDataset(
        items=tuple(items),
        manifest_path=str(path),
        manifest_sha256=manifest_sha256,
        stats={
            "manifest_items": len(parsed),
            "selected_items": len(items),
            "items_with_history": sum(
                int(item.metadata["history_group_count"]) > 0 for item in items
            ),
            "max_estimated_tokens": max(token_counts),
            "mean_estimated_tokens": sum(token_counts) / len(token_counts),
            "past_only_validated": True,
        },
    )
