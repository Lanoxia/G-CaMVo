"""Frozen, past-only OpTC provenance-subgraph dataset contracts.

The online model experiment must consume a pre-curated JSONL manifest rather
than scanning raw OpTC telemetry while provider calls are in flight.  This
module validates that manifest, rejects common leakage modes, and renders a
deterministic text representation for every model arm.
"""

from __future__ import annotations

import hashlib
import json
from collections import Counter, defaultdict
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from camvo.types import AnnotationItem

OPTC_CHAIN_LABELS: tuple[str, ...] = ("benign", "malicious")
OPTC_CHAIN_SPLITS = frozenset({"calibration", "validation", "test"})
OPTC_CHAIN_SAMPLE_KINDS = frozenset({"malicious", "matched_benign", "hard_negative"})


class OptcChainManifestError(ValueError):
    """Raised when a frozen OpTC chain manifest is unsafe or inconsistent."""


@dataclass(frozen=True, slots=True)
class OptcChainDataset:
    items: tuple[AnnotationItem, ...]
    manifest_path: str
    manifest_sha256: str
    dataset_id: str
    manifest_version: str
    stats: dict[str, object]

    def __post_init__(self) -> None:
        if not self.items:
            raise ValueError("OpTC chain dataset must not be empty")
        if any(item.labels != OPTC_CHAIN_LABELS for item in self.items):
            raise ValueError("OpTC chain item has unexpected labels")


def _require_mapping(value: object, location: str) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise OptcChainManifestError(f"{location} must be a JSON object")
    return value


def _require_list(value: object, location: str) -> list[Any]:
    if not isinstance(value, list):
        raise OptcChainManifestError(f"{location} must be a JSON array")
    return value


def _require_text(value: object, location: str) -> str:
    if not isinstance(value, str) or not value.strip():
        raise OptcChainManifestError(f"{location} must be a non-empty string")
    return value.strip()


def _require_int(value: object, location: str, *, minimum: int | None = None) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise OptcChainManifestError(f"{location} must be an integer")
    if minimum is not None and value < minimum:
        raise OptcChainManifestError(f"{location} must be >= {minimum}")
    return value


def _string_list(value: object, location: str) -> list[str]:
    values = _require_list(value, location)
    output: list[str] = []
    for index, member in enumerate(values):
        output.append(_require_text(member, f"{location}[{index}]"))
    return output


def _stable_json(value: object) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"))


def _safe_attributes(value: object, location: str) -> dict[str, object]:
    if value is None:
        return {}
    attributes = _require_mapping(value, location)
    try:
        encoded = _stable_json(attributes)
    except (TypeError, ValueError) as exc:
        raise OptcChainManifestError(f"{location} must contain JSON values") from exc
    if len(encoded.encode("utf-8")) > 4_000:
        raise OptcChainManifestError(f"{location} is unexpectedly large")
    return dict(attributes)


def _node_line(node: dict[str, Any]) -> str:
    payload = {
        "node_id": node["node_id"],
        "node_type": node["node_type"],
        "label": node.get("label", ""),
        "hostname": node.get("hostname", ""),
        "attributes": node.get("attributes", {}),
    }
    return _stable_json(payload)


def _edge_line(edge: dict[str, Any]) -> str:
    payload = {
        "edge_id": edge["edge_id"],
        "timestamp_ms": edge["timestamp_ms"],
        "source_node_id": edge["source_node_id"],
        "action": edge["action"],
        "target_node_id": edge["target_node_id"],
        "hostname": edge.get("hostname", ""),
        "attributes": edge.get("attributes", {}),
    }
    return _stable_json(payload)


def _render_item_text(
    record: dict[str, Any],
    *,
    manifest_sha256: str,
    nodes: list[dict[str, Any]],
    edges: list[dict[str, Any]],
) -> str:
    anchor = record["anchor"]
    known_history = record["known_history"]
    source_refs = record["source_refs"]
    missing_evidence = record["missing_evidence"]
    lines = [
        "[DATASET_CONTRACT]",
        f"dataset_id={record['dataset_id']}",
        f"manifest_version={record['manifest_version']}",
        f"manifest_sha256={manifest_sha256}",
        f"sample_id={record['sample_id']}",
        f"scenario_group_id={record['scenario_group_id']}",
        f"split={record['split']}",
        "visibility=past_only",
        "",
        "[ANCHOR]",
        _stable_json(anchor),
        "",
        "[KNOWN_HISTORY]",
        _stable_json(known_history),
        "",
        "[KEY_ENTITIES]",
        *(_node_line(node) for node in nodes),
        "",
        "[PROVENANCE_EDGES_SORTED_BY_TIME]",
        *(_edge_line(edge) for edge in edges),
        "",
        "[MISSING_EVIDENCE]",
        *missing_evidence,
        "",
        "[SOURCE_REFERENCES]",
        *(_stable_json(reference) for reference in source_refs),
    ]
    return "\n".join(lines).strip()


def estimate_optc_chain_record_tokens(
    record: dict[str, Any],
    *,
    manifest_sha256: str = "0" * 64,
) -> int:
    """Estimate the exact evidence-text tokens used by the manifest loader."""

    nodes = _require_list(record.get("nodes"), "record.nodes")
    edges = _require_list(record.get("edges"), "record.edges")
    text = _render_item_text(
        record,
        manifest_sha256=manifest_sha256,
        nodes=[_require_mapping(node, "record.nodes[]") for node in nodes],
        edges=[_require_mapping(edge, "record.edges[]") for edge in edges],
    )
    return max(1, (len(text.encode("utf-8")) + 3) // 4)


def _validate_record(
    raw_record: object,
    *,
    line_number: int,
    manifest_sha256: str,
    max_nodes: int,
    max_edges: int,
    max_estimated_tokens: int,
) -> tuple[dict[str, Any], AnnotationItem]:
    location = f"line {line_number}"
    record = _require_mapping(raw_record, location)
    schema_version = _require_int(record.get("schema_version"), f"{location}.schema_version")
    if schema_version != 1:
        raise OptcChainManifestError(
            f"{location}.schema_version must be 1, got {schema_version}"
        )

    dataset_id = _require_text(record.get("dataset_id"), f"{location}.dataset_id")
    manifest_version = _require_text(
        record.get("manifest_version"), f"{location}.manifest_version"
    )
    sample_id = _require_text(record.get("sample_id"), f"{location}.sample_id")
    scenario_group_id = _require_text(
        record.get("scenario_group_id"), f"{location}.scenario_group_id"
    )
    split = _require_text(record.get("split"), f"{location}.split").casefold()
    if split not in OPTC_CHAIN_SPLITS:
        raise OptcChainManifestError(
            f"{location}.split must be one of {sorted(OPTC_CHAIN_SPLITS)}"
        )
    collection_rank = _require_int(
        record.get("collection_rank"), f"{location}.collection_rank", minimum=1
    )
    gold_label = _require_text(record.get("gold_label"), f"{location}.gold_label").casefold()
    if gold_label not in OPTC_CHAIN_LABELS:
        raise OptcChainManifestError(
            f"{location}.gold_label must be one of {list(OPTC_CHAIN_LABELS)}"
        )
    sample_kind = _require_text(
        record.get("sample_kind"), f"{location}.sample_kind"
    ).casefold()
    if sample_kind not in OPTC_CHAIN_SAMPLE_KINDS:
        raise OptcChainManifestError(
            f"{location}.sample_kind must be one of {sorted(OPTC_CHAIN_SAMPLE_KINDS)}"
        )
    if (sample_kind == "malicious") != (gold_label == "malicious"):
        raise OptcChainManifestError(
            f"{location} has inconsistent sample_kind={sample_kind!r} "
            f"and gold_label={gold_label!r}"
        )

    label_provenance = _require_mapping(
        record.get("label_provenance"), f"{location}.label_provenance"
    )
    _require_text(label_provenance.get("source"), f"{location}.label_provenance.source")
    _require_text(
        label_provenance.get("reference"), f"{location}.label_provenance.reference"
    )
    review_status = _require_text(
        label_provenance.get("review_status"),
        f"{location}.label_provenance.review_status",
    ).casefold()
    if review_status not in {"official", "curated", "verified"}:
        raise OptcChainManifestError(
            f"{location}.label_provenance.review_status must be official, curated, or verified"
        )

    anchor = _require_mapping(record.get("anchor"), f"{location}.anchor")
    for field in ("event_id", "hostname", "object_type", "action"):
        anchor[field] = _require_text(anchor.get(field), f"{location}.anchor.{field}")
    anchor["timestamp_ms"] = _require_int(
        anchor.get("timestamp_ms"), f"{location}.anchor.timestamp_ms", minimum=0
    )
    anchor["object_type"] = anchor["object_type"].upper()
    anchor["action"] = anchor["action"].upper()
    anchor_timestamp = anchor["timestamp_ms"]

    raw_nodes = _require_list(record.get("nodes"), f"{location}.nodes")
    if not raw_nodes:
        raise OptcChainManifestError(f"{location}.nodes must not be empty")
    if len(raw_nodes) > max_nodes:
        raise OptcChainManifestError(
            f"{location} contains {len(raw_nodes)} nodes; maximum is {max_nodes}"
        )
    nodes: list[dict[str, Any]] = []
    node_ids: set[str] = set()
    for index, raw_node in enumerate(raw_nodes):
        node_location = f"{location}.nodes[{index}]"
        node = _require_mapping(raw_node, node_location)
        node_id = _require_text(node.get("node_id"), f"{node_location}.node_id")
        if node_id in node_ids:
            raise OptcChainManifestError(f"{location} contains duplicate node_id {node_id!r}")
        node_ids.add(node_id)
        normalized_node = {
            "node_id": node_id,
            "node_type": _require_text(
                node.get("node_type"), f"{node_location}.node_type"
            ).upper(),
            "label": str(node.get("label", "")).strip(),
            "hostname": str(node.get("hostname", "")).strip(),
            "attributes": _safe_attributes(
                node.get("attributes", {}), f"{node_location}.attributes"
            ),
        }
        nodes.append(normalized_node)

    raw_edges = _require_list(record.get("edges"), f"{location}.edges")
    if not raw_edges:
        raise OptcChainManifestError(f"{location}.edges must not be empty")
    if len(raw_edges) > max_edges:
        raise OptcChainManifestError(
            f"{location} contains {len(raw_edges)} edges; maximum is {max_edges}"
        )
    edges: list[dict[str, Any]] = []
    edge_ids: set[str] = set()
    for index, raw_edge in enumerate(raw_edges):
        edge_location = f"{location}.edges[{index}]"
        edge = _require_mapping(raw_edge, edge_location)
        edge_id = _require_text(edge.get("edge_id"), f"{edge_location}.edge_id")
        if edge_id in edge_ids:
            raise OptcChainManifestError(f"{location} contains duplicate edge_id {edge_id!r}")
        edge_ids.add(edge_id)
        source = _require_text(
            edge.get("source_node_id"), f"{edge_location}.source_node_id"
        )
        target = _require_text(
            edge.get("target_node_id"), f"{edge_location}.target_node_id"
        )
        if source not in node_ids or target not in node_ids:
            raise OptcChainManifestError(
                f"{edge_location} references a node missing from this sample"
            )
        timestamp_ms = _require_int(
            edge.get("timestamp_ms"), f"{edge_location}.timestamp_ms", minimum=0
        )
        if timestamp_ms > anchor_timestamp:
            raise OptcChainManifestError(
                f"{edge_location} leaks a future event "
                f"({timestamp_ms} > anchor {anchor_timestamp})"
            )
        normalized_edge = {
            "edge_id": edge_id,
            "timestamp_ms": timestamp_ms,
            "source_node_id": source,
            "target_node_id": target,
            "action": _require_text(edge.get("action"), f"{edge_location}.action").upper(),
            "hostname": str(edge.get("hostname", "")).strip(),
            "attributes": _safe_attributes(
                edge.get("attributes", {}), f"{edge_location}.attributes"
            ),
        }
        edges.append(normalized_edge)

    known_history = _require_mapping(
        record.get("known_history", {}), f"{location}.known_history"
    )
    normalized_history = {
        "confirmed_entities": _string_list(
            known_history.get("confirmed_entities", []),
            f"{location}.known_history.confirmed_entities",
        ),
        "attack_stages": _string_list(
            known_history.get("attack_stages", []),
            f"{location}.known_history.attack_stages",
        ),
        "prior_anchor_ids": _string_list(
            known_history.get("prior_anchor_ids", []),
            f"{location}.known_history.prior_anchor_ids",
        ),
    }
    missing_evidence = _string_list(
        record.get("missing_evidence", []), f"{location}.missing_evidence"
    )
    source_refs = _require_list(record.get("source_refs"), f"{location}.source_refs")
    if not source_refs:
        raise OptcChainManifestError(f"{location}.source_refs must not be empty")
    normalized_refs: list[dict[str, Any]] = []
    for index, raw_reference in enumerate(source_refs):
        reference_location = f"{location}.source_refs[{index}]"
        reference = _require_mapping(raw_reference, reference_location)
        normalized = {
            "source": _require_text(
                reference.get("source"), f"{reference_location}.source"
            ),
            "reference": _require_text(
                reference.get("reference"), f"{reference_location}.reference"
            ),
        }
        if "sha256" in reference:
            digest = _require_text(reference["sha256"], f"{reference_location}.sha256")
            invalid_hex = any(
                character not in "0123456789abcdefABCDEF" for character in digest
            )
            if len(digest) != 64 or invalid_hex:
                raise OptcChainManifestError(
                    f"{reference_location}.sha256 must be a 64-character hex digest"
                )
            normalized["sha256"] = digest.casefold()
        normalized_refs.append(normalized)

    nodes.sort(key=lambda node: (node["node_type"], node["node_id"]))
    edges.sort(
        key=lambda edge: (
            edge["timestamp_ms"],
            edge["action"],
            edge["source_node_id"],
            edge["target_node_id"],
            edge["edge_id"],
        )
    )
    normalized_record = {
        "schema_version": schema_version,
        "dataset_id": dataset_id,
        "manifest_version": manifest_version,
        "sample_id": sample_id,
        "scenario_group_id": scenario_group_id,
        "split": split,
        "collection_rank": collection_rank,
        "gold_label": gold_label,
        "sample_kind": sample_kind,
        "label_provenance": dict(label_provenance),
        "anchor": anchor,
        "nodes": nodes,
        "edges": edges,
        "known_history": normalized_history,
        "missing_evidence": missing_evidence,
        "source_refs": normalized_refs,
    }
    text = _render_item_text(
        normalized_record,
        manifest_sha256=manifest_sha256,
        nodes=nodes,
        edges=edges,
    )
    estimated_tokens = max(1, (len(text.encode("utf-8")) + 3) // 4)
    if estimated_tokens > max_estimated_tokens:
        raise OptcChainManifestError(
            f"{location} is estimated at {estimated_tokens} tokens; "
            f"maximum is {max_estimated_tokens}"
        )
    item = AnnotationItem(
        item_id=f"optc-chain:{dataset_id}:{sample_id}",
        text=text,
        labels=OPTC_CHAIN_LABELS,
        metadata={
            "dataset_id": dataset_id,
            "manifest_version": manifest_version,
            "manifest_sha256": manifest_sha256,
            "sample_id": sample_id,
            "scenario_group_id": scenario_group_id,
            "split": split,
            "collection_rank": collection_rank,
            "gold_label": gold_label,
            "sample_kind": sample_kind,
            "label_provenance": dict(label_provenance),
            "timestamp": anchor_timestamp,
            "hostname": anchor["hostname"],
            "anchor_event_id": anchor["event_id"],
            "event_ids": [edge["edge_id"] for edge in edges],
            "edge_ids": [edge["edge_id"] for edge in edges],
            "node_count": len(nodes),
            "edge_count": len(edges),
            "estimated_input_tokens": estimated_tokens,
        },
    )
    return normalized_record, item


def load_optc_chain_dataset(
    manifest_path: str | Path,
    *,
    split: str = "all",
    limit: int | None = None,
    max_nodes: int = 100,
    max_edges: int = 250,
    max_estimated_tokens: int = 12_000,
) -> OptcChainDataset:
    """Load and validate a frozen JSONL OpTC chain manifest.

    ``limit`` is applied after deterministic ``collection_rank`` ordering.  A
    full Main manifest must therefore be frozen before Smoke so cached answers
    remain valid when the limit is increased.
    """

    path = Path(manifest_path).expanduser()
    if not path.is_file():
        raise FileNotFoundError(f"OpTC chain manifest does not exist: {path}")
    if max_nodes <= 0 or max_edges <= 0 or max_estimated_tokens <= 0:
        raise ValueError("manifest limits must be positive")
    requested_split = split.strip().casefold()
    if requested_split != "all" and requested_split not in OPTC_CHAIN_SPLITS:
        raise ValueError(f"split must be 'all' or one of {sorted(OPTC_CHAIN_SPLITS)}")
    if limit is not None and limit <= 0:
        raise ValueError("limit must be positive when provided")

    raw_bytes = path.read_bytes()
    manifest_sha256 = hashlib.sha256(raw_bytes).hexdigest()
    parsed: list[tuple[dict[str, Any], AnnotationItem]] = []
    for line_number, raw_line in enumerate(raw_bytes.decode("utf-8").splitlines(), start=1):
        line = raw_line.strip()
        if not line:
            continue
        try:
            raw_record = json.loads(line)
        except json.JSONDecodeError as exc:
            raise OptcChainManifestError(
                f"line {line_number} is not valid JSON: {exc.msg}"
            ) from exc
        parsed.append(
            _validate_record(
                raw_record,
                line_number=line_number,
                manifest_sha256=manifest_sha256,
                max_nodes=max_nodes,
                max_edges=max_edges,
                max_estimated_tokens=max_estimated_tokens,
            )
        )
    if not parsed:
        raise OptcChainManifestError("OpTC chain manifest contains no samples")

    dataset_ids = {record["dataset_id"] for record, _item in parsed}
    manifest_versions = {record["manifest_version"] for record, _item in parsed}
    if len(dataset_ids) != 1:
        raise OptcChainManifestError("all records must use the same dataset_id")
    if len(manifest_versions) != 1:
        raise OptcChainManifestError("all records must use the same manifest_version")

    sample_ids = [record["sample_id"] for record, _item in parsed]
    if len(sample_ids) != len(set(sample_ids)):
        raise OptcChainManifestError("manifest contains duplicate sample_id values")
    ranks = [record["collection_rank"] for record, _item in parsed]
    if len(ranks) != len(set(ranks)):
        raise OptcChainManifestError("manifest contains duplicate collection_rank values")
    expected_ranks = set(range(1, len(ranks) + 1))
    if set(ranks) != expected_ranks:
        raise OptcChainManifestError(
            "collection_rank values must be contiguous from 1 through the manifest size"
        )

    group_splits: dict[str, set[str]] = defaultdict(set)
    for record, _item in parsed:
        group_splits[record["scenario_group_id"]].add(record["split"])
    leaked_groups = sorted(group for group, splits in group_splits.items() if len(splits) > 1)
    if leaked_groups:
        raise OptcChainManifestError(
            "scenario groups cross calibration/validation/test splits: "
            + ", ".join(leaked_groups[:10])
        )

    parsed.sort(key=lambda pair: pair[0]["collection_rank"])
    selected = [
        (record, item)
        for record, item in parsed
        if requested_split == "all" or record["split"] == requested_split
    ]
    if limit is not None:
        selected = selected[:limit]
    if not selected:
        raise OptcChainManifestError(
            f"manifest has no samples after split={requested_split!r} and limit={limit!r}"
        )

    selected_records = [record for record, _item in selected]
    selected_items = tuple(item for _record, item in selected)
    token_counts = sorted(
        int(item.metadata["estimated_input_tokens"]) for item in selected_items
    )

    def percentile(fraction: float) -> int:
        index = min(len(token_counts) - 1, round((len(token_counts) - 1) * fraction))
        return token_counts[index]

    stats: dict[str, object] = {
        "dataset_id": next(iter(dataset_ids)),
        "manifest_version": next(iter(manifest_versions)),
        "manifest_sha256": manifest_sha256,
        "manifest_total_items": len(parsed),
        "selected_items": len(selected_items),
        "selected_scenario_groups": len(
            {record["scenario_group_id"] for record in selected_records}
        ),
        "split_filter": requested_split,
        "limit": limit,
        "gold_counts": dict(Counter(record["gold_label"] for record in selected_records)),
        "sample_kind_counts": dict(
            Counter(record["sample_kind"] for record in selected_records)
        ),
        "split_counts": dict(Counter(record["split"] for record in selected_records)),
        "node_count_min": min(int(item.metadata["node_count"]) for item in selected_items),
        "node_count_max": max(int(item.metadata["node_count"]) for item in selected_items),
        "edge_count_min": min(int(item.metadata["edge_count"]) for item in selected_items),
        "edge_count_max": max(int(item.metadata["edge_count"]) for item in selected_items),
        "estimated_tokens_min": token_counts[0],
        "estimated_tokens_p50": percentile(0.50),
        "estimated_tokens_p95": percentile(0.95),
        "estimated_tokens_max": token_counts[-1],
        "past_only_validated": True,
        "scenario_group_split_leakage": False,
    }
    return OptcChainDataset(
        items=selected_items,
        manifest_path=str(path),
        manifest_sha256=manifest_sha256,
        dataset_id=next(iter(dataset_ids)),
        manifest_version=next(iter(manifest_versions)),
        stats=stats,
    )
