# Mordor Atomic112 self-contained reproducibility bundle

This package freezes the complete local record needed to audit and replay the
Atomic112 evaluation without new provider calls.

## Contents

- `protocol/`: preregistration, all 171 decisions, calibration/validation/test
  splits, the separate compound stress set, exclusions, and protocol hashes.
- `model_inputs/`: the exact 171 model-visible prompt instances. These contain
  no evaluator labels.
- `evaluator/`: evaluator-only labels, physically separated from model inputs.
- `responses/`: the exact 171 responses from each of the five models.
- `pricing/`: the frozen price snapshot used for cost calculations.
- `taxonomy/`: the frozen Enterprise ATT&CK 8.2 taxonomy used for scoring.
- `provenance/`: upstream OTRF commit record and source-file SHA-256 inventory.
- `code/`: CaMVo implementation, replay script, and dependencies.
- `results/`: reported tables, figures, traces, uncertainty, and machine-readable results.

## Reproduce

From the extracted package root:

```bash
python -m venv .venv
.venv/bin/pip install -r code/requirements.txt
PYTHONPATH=code .venv/bin/python code/analyze_atomic112_reproducible.py
```

The sentence encoder is `sentence-transformers/all-MiniLM-L6-v2`. If it is not
already cached, installing/running it requires network access once. No LLM API
calls are made by the replay.

## Frozen scope

- 171 decision anchors from 54 official source groups: 29 calibration, 30
  validation, and 112 test decisions.
- Headline Atomic112 test: 112 chronological decisions from 32 source groups.
- Five frozen model-response files, 171 rows each (855 response cells total).
- Primary operating point: CaMVo `delta=0.80`, `k_min=3`.

The raw OTRF payloads are not duplicated. The official source repository,
commit, paths, and SHA-256 identities are recorded in `provenance/`.

## Integrity and claim boundary

`SHA256SUMS.txt` covers every package file except itself. Atomic112 is a
source-grouped decision-level replay, not 112 independent official source
scenarios and not a prospective source-unseen holdout.
