# Mordor Atomic-112 tactic replay

This directory contains the frozen results for a chronological, tactic-level replay over 112 decision anchors from 32 official Mordor source groups.

## Headline result

- Online full vote: 81/112 (72.3%), estimated cost $13.18 per 1,000 decisions.
- CaMVo (`delta=0.80`, `k_min=3`): 80/112 (71.4%), estimated cost $5.75 per 1,000 decisions.
- Strongest single model (GLM 5.2): 79/112 (70.5%), estimated cost $6.31 per 1,000 decisions.
- CaMVo uses 3.32 models per decision and saves 56.4% relative to online full vote.

## Reading order

1. `REPORT_EN.md`: paper-facing protocol, results, and interpretation.
2. `01_atomic112_tactic_accuracy_cost_table.*`: principal accuracy-cost table.
3. `02_atomic112_online_trajectory.*`: chronological accuracy and cost trajectory.
4. `atomic112_tactic_results.csv`: exact table values.
5. `summary.json`: complete machine-readable result, uncertainty, and paired tests.
6. `camvo_trace.jsonl` and `online_full_vote_trace.jsonl`: decision-level traces.
7. `ATOMIC112_TACTIC_ACCURACY_COST_TABLE.tex`: LaTeX three-line table.

## Claim boundary

The 112 records are chronological decision anchors derived from 32 official source groups. They improve decision-level coverage, but they are not 112 newly independent official scenarios and are not a prospective source-unseen holdout. Source-group bootstrap intervals and paired exact tests are retained for this reason.

The primary claim supported here is that CaMVo approximately preserves online full-vote tactic accuracy at substantially lower estimated cost. The one-case differences among CaMVo, online full vote, and the strongest single model are not statistically significant at this scale.
