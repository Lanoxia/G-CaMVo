# Mordor Atomic-112 tactic-level online replay

## Protocol

The evaluation replays 112 chronological decisions from 32 official Mordor source groups. Each decision is scored by whether its predicted ATT&CK technique maps to an official tactic for that decision under frozen Enterprise ATT&CK 8.2. The test stream starts from a cold state. Subset selection occurs before the current model responses are revealed, and neither online full vote nor CaMVo receives evaluator labels.

## Main results

| Method | Correct / 112 | Top-1 tactic accuracy | Source-group 95% CI | Cost / 1K decisions | Saving vs. online full vote | Avg. models |
|---|---:|---:|---:|---:|---:|---:|
| DeepSeek V4 Flash | 70/112 | 62.5% | 49.2%–79.1% | $0.58 | 95.6% | 1.00 |
| DeepSeek V4 Pro | 76/112 | 67.9% | 54.1%–85.0% | $1.82 | 86.2% | 1.00 |
| Gemini 3.5 Flash-Lite | 71/112 | 63.4% | 44.5%–85.9% | $2.61 | 80.2% | 1.00 |
| GLM 5.2 | 79/112 | 70.5% | 55.9%–87.0% | $6.31 | 52.1% | 1.00 |
| MiniMax M3 | 76/112 | 67.9% | 53.8%–83.3% | $1.86 | 85.9% | 1.00 |
| Full vote (uniform) | 81/112 | 72.3% | 58.6%–89.0% | $13.18 | 0.0% | 5.00 |
| Full vote (calibration weighted) | 82/112 | 73.2% | 59.2%–90.3% | $13.18 | 0.0% | 5.00 |
| Full vote (online learned) | 81/112 | 72.3% | 58.4%–89.2% | $13.18 | 0.0% | 5.00 |
| CaMVo (δ=0.80, kmin=3) | 80/112 | 71.4% | 57.6%–88.5% | $5.75 | 56.4% | 3.32 |

## Interpretation

At the preregistered operating point (δ=0.80, k_min=3), CaMVo obtains 80/112 (71.4%) while using 3.32 models per decision and reducing estimated cost by 56.4% relative to online full vote. Online full vote obtains 81/112 (72.3%), and the strongest individual model obtains 79/112 (70.5%).

The paired differences are small and are not statistically significant at this scale. Confidence intervals are therefore clustered by official source group, rather than treating all derived decisions as independent. This result supports an accuracy–cost trade-off claim; it does not support a claim that CaMVo is significantly more accurate than either comparator.

The 112 decisions are decision-level anchors derived from 32 official source groups already represented in the earlier Mordor benchmark. They increase chronological decision coverage but are not 112 newly independent official scenarios or a prospective untouched holdout.
