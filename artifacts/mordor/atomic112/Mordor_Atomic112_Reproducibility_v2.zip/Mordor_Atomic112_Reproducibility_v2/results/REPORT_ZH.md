# Mordor Atomic-112 冻结 tactic 实验

性质：完全离线回放；新增模型调用 0。

## 主结果

| 方法 | 正确/112 | Top-1 tactic accuracy | Source-group 95% CI | Cost/1K | 相对在线全量节省 | 平均模型数 |
|---|---:|---:|---:|---:|---:|---:|
| DeepSeek V4 Flash | 70/112 | 62.5% | 49.2%–79.1% | $0.58 | 95.6% | 1.00 |
| DeepSeek V4 Pro | 76/112 | 67.9% | 54.1%–85.0% | $1.82 | 86.2% | 1.00 |
| Gemini 3.5 Flash-Lite | 71/112 | 63.4% | 44.5%–85.9% | $2.61 | 80.2% | 1.00 |
| GLM 5.2 | 79/112 | 70.5% | 55.9%–87.0% | $6.31 | 52.1% | 1.00 |
| MiniMax M3 | 76/112 | 67.9% | 53.8%–83.3% | $1.86 | 85.9% | 1.00 |
| Full vote (uniform) | 81/112 | 72.3% | 58.6%–89.0% | $13.18 | 0.0% | 5.00 |
| Full vote (calibration weighted) | 82/112 | 73.2% | 59.2%–90.3% | $13.18 | 0.0% | 5.00 |
| Full vote (online learned) | 81/112 | 72.3% | 58.4%–89.2% | $13.18 | 0.0% | 5.00 |
| CaMVo (δ=0.80, kmin=3) | 80/112 | 71.4% | 57.6%–88.5% | $5.75 | 56.4% | 3.32 |

## 解释边界

CaMVo 的目标为 0.80 × online full vote = 57.9%，实际为 71.4%，target_met=True。
该实验扩大了在线决策次数，但 112 个决策来自 32 个已存在于 Primary101 的官方源组；因此是 source-grouped decision-level replay，不表述为 112 个全新官方场景或 prospective untouched holdout。
固定权重 full vote 使用 calibration gold；online full vote 与 CaMVo 均不读取 gold，并在 test 首轮冷启动。
