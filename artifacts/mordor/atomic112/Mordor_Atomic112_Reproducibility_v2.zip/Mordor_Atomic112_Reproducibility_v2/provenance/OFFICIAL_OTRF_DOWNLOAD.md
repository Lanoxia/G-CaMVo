# Official OTRF Security-Datasets Download Record

## Source

- Upstream: `https://github.com/OTRF/Security-Datasets.git`
- Frozen commit: `d9d40ef123d2c87d5d3df28c96bcab4f0faccc87`
- Download date: `2026-07-31`
- Local root: `OTRF/Security-Datasets@d9d40ef123d2c87d5d3df28c96bcab4f0faccc87`
- Upstream license: see the downloaded repository `LICENSE`

## Scope

- Dataset files in working tree: 493
- Payload-like files (`zip/json/jsonl/pcap/pcapng/evtx`): 211
- ZIP files: 205
- Official payload paths identified from repository tree: 209
  - Atomic: 161
  - Compound: 48
- Checked-out dataset size: approximately 578 MiB
- Full repository including Git history: approximately 1.4 GiB

The repository contains compressed JSON/host telemetry, network captures, Zeek logs, atomic technique datasets, and compound campaigns. APT29 Day 1 and Day 2 are included in this frozen official snapshot.

## Integrity checks

- `git fsck --no-dangling`: passed.
- 197 ordinary ZIP files passed `unzip -tq`.
- 8 APT29 PCAP ZIP files are intentionally password protected according to their official README (`infected`). All 8 passed `unzip -P infected -tq`.
- SHA-256 was calculated for all 493 files under `datasets/`.
- Hash manifest: `provenance/OFFICIAL_OTRF_SHA256SUMS.txt`
- SHA-256 of the hash manifest itself: `8c649d82a006917ecada38c11c43b2572f935ab6728aa52800ce6cffe5f8fa4a`

## Isolation rule

The new experiment must not read the old 7,538 timestamp-derived dataset, its manifests, prompts, labels, cached responses, or derived metrics. Those files remain historical archives only.

Allowed primary input root:

```text
OTRF/Security-Datasets@d9d40ef123d2c87d5d3df28c96bcab4f0faccc87/datasets
```

Disallowed legacy input families include, but are not limited to:

```text
experiments/mordor_online_4models_7538/
data/derived/mordor_offline_bundle_full_7538/
data/processed/mordor_history_v1/
outputs/mordor_history_prompt_iterations/
```

Future official datasets may be added only under a separately versioned official-source directory with their URL, commit/release identifier, file hashes, license and coverage record documented before use.
