# Mordor Atomic-171 扩展实验冻结协议

冻结日期：2026-08-11  
新增模型调用：0

## 结论先说

当前官方快照可以形成 **171 个可复现的 atomic 在线决策锚点**，来自 **54 个官方源场景**。
其中 calibration/validation/test 分别为 **29/30/112** 个锚点，来自 **11/11/32** 个互不交叉的源组。
另有 **61 个 compound 攻击链步骤**，来自 4 个 campaign，只作为单独压力测试。

这不是 171 个全新的官方源场景，也不是尚未接触过的 prospective holdout。它是对同一官方日志快照进行的、更细粒度且 source-grouped 的 decision-level replay。论文必须同时报告“决策数”和“独立源组数”。

## 数据进入规则

1. 每个 anchor 只保留一个 `context_06` 视图；确实没有历史时才允许 `anchor_only`；
2. 每条可见事件时间不晚于当前 `decision_time`；
3. Prompt 不含官方场景名、官方命令、ATT&CK 标签或 evaluator gold；
4. Atomic anchor 必须有人工复核的可观察证据，并能在 Enterprise ATT&CK 8.2 下映射到兼容 tactic；
5. 同一个 `source_case_id` 不得跨 calibration、validation、test；
6. 不得根据模型正确率、成本、投票结果或 CaMVo 表现挑选、删除样本；
7. 1,121 个多视图不能被称作 1,121 个独立样本；
8. 47 个无法可靠产生子锚点的 primary sources 保留在排除账本中，不强行继承标签。

## 正式主实验

- 主表：Atomic test，112 次决策、32 个独立源组；
- 顺序：严格按 `decision_time`；
- 任务：模型预测 technique，按冻结的 ATT&CK 8.2 映射为 Top-1 tactic；
- 主 CaMVo 运行点：`delta=0.80, k_min=3`，在查看本次 test 结果前固定；
- 对照：五个单模型、未加权 full vote、固定权重 full vote、与 CaMVo 使用同类在线可靠性更新的 online full vote；
- 在线约束：test 首轮冷启动，当前回答出现前完成子集选择；更新只使用系统分配的 consensus，不使用 gold；
- 指标：Top-1 tactic accuracy、成本、平均模型数、延迟、按 source group 聚类的 95% CI，以及配对差异；
- Compound-61 独立成表，不与 Atomic accuracy 合并。

## 为什么这套规则能经受审稿

它扩大的是在线决策次数，但不夸大独立性；分组能避免同源泄漏；历史严格 past-only；gold 与 Prompt 分离；主运行点和排除规则在结果分析前固定；无论结果是否漂亮都不能事后改样本。

## 机器可读文件

- `atomic171_all.jsonl`
- `atomic_calibration.jsonl`
- `atomic_validation.jsonl`
- `atomic_test.jsonl`
- `compound61_stress.jsonl`
- `excluded_primary_sources.csv`
- `PREREGISTRATION.json`
- `MANIFEST_SHA256.txt`
